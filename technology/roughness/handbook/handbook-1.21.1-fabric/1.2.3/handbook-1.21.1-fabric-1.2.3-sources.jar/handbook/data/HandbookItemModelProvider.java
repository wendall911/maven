package handbook.data;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import handbook.common.item.HandbookItems;


public class HandbookItemModelProvider extends FabricModelProvider {

    public HandbookItemModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        addBookModel(itemModelGenerator, HandbookItems.BOOK_ID, HandbookItems.BOOK_BROWN_ID);
        addBookModel(itemModelGenerator, HandbookItems.BOOK_BLUE_ID, HandbookItems.BOOK_BLUE_ID);
        addBookModel(itemModelGenerator, HandbookItems.BOOK_BROWN_ID, HandbookItems.BOOK_BROWN_ID);
        addBookModel(itemModelGenerator, HandbookItems.BOOK_CYAN_ID, HandbookItems.BOOK_CYAN_ID);
        addBookModel(itemModelGenerator, HandbookItems.BOOK_GRAY_ID, HandbookItems.BOOK_GRAY_ID);
        addBookModel(itemModelGenerator, HandbookItems.BOOK_GREEN_ID, HandbookItems.BOOK_GREEN_ID);
        addBookModel(itemModelGenerator, HandbookItems.BOOK_PURPLE_ID, HandbookItems.BOOK_PURPLE_ID);
        addBookModel(itemModelGenerator, HandbookItems.BOOK_RED_ID, HandbookItems.BOOK_RED_ID);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
        // NO-OP
    }

    public void addBookModel(class_4915 itemModelGenerator, class_2960 book, class_2960 bookTexture) {
        class_2960 bookModel = class_2960.method_60655(book.method_12836(), "item/" + book.method_12832());
        class_2960 bookTextureModel = class_2960.method_60655(bookTexture.method_12836(), "item/" + bookTexture.method_12832());

        class_4943.field_22938.method_25852(bookModel, class_4944.method_25895(bookTextureModel), itemModelGenerator.field_22844);
    }

}
