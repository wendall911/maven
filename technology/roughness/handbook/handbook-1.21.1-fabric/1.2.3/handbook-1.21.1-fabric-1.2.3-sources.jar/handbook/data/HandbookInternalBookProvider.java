package handbook.data;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_7225.class_7874;
import net.minecraft.class_7784;
import handbook.api.HandbookAPI;
import handbook.api.data.BookBuilder;
import handbook.common.item.HandbookItems;

public class HandbookInternalBookProvider extends handbook.api.data.HandbookBookProvider {

    public static final String INTRO_BOOK_TRANSLATION_KEY = "book." + HandbookAPI.MODID + ".intro_book";
    private int categorySortNum = -1;
    private int entrySortNum = -1;

    public HandbookInternalBookProvider(class_7784 packOutput, CompletableFuture<class_7874> registries) {
        super(packOutput, HandbookAPI.MODID, "en_us", registries);
    }

    @Override
    protected void addBooks(Consumer<BookBuilder> consumer, class_7874 provider) {
        class_1799 book = new class_1799(HandbookItems.BOOK);
        class_1799 writeableBook = new class_1799(class_1802.field_8674);

        BookBuilder bookBuilder = createBookBuilder(HandbookItems.BOOK, INTRO_BOOK_TRANSLATION_KEY, prefix("landing"), provider)
            .setSubtitle(prefix("subtitle"))
            .setCreativeTab("minecraft:tools_and_utilities")
            .setShowProgress(true)
            .setI18n(true)
            .addCategory(
                "introduction",
                prefix("introduction.name"),
                prefix("introduction.description"),
                book
            )
            .setSortnum(categorySortNum++)
            .addEntry(
                "introduction/welcome",
                prefix("introduction.welcome.name"),
                writeableBook
            ).setSortnum(entrySortNum++)
            .addTextPage(prefix("introduction.welcome.intro"))
            .build().build().build();

        bookBuilder.build(consumer);
    }

    private String prefix(String name) {
        return INTRO_BOOK_TRANSLATION_KEY + "." + name;
    }

}
