package handbook.data;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2248;
import net.minecraft.class_3489;
import net.minecraft.class_7225.class_7874;
import net.minecraft.class_7784;
import net.minecraft.class_7805;
import org.jetbrains.annotations.NotNull;
import handbook.common.item.HandbookItems;

public class HandbookItemTagsProvider extends class_7805 {

    public HandbookItemTagsProvider(class_7784 output, CompletableFuture<class_7874> lookupProvider, CompletableFuture<class_8211<class_2248>> blockTags) {
        super(output, lookupProvider, blockTags);
    }

    @Override
    protected void method_10514(@NotNull class_7874 provider) {
        this.method_46827(class_3489.field_40109).method_46829(HandbookItems.BOOK);
        this.method_46827(class_3489.field_21465).method_46829(HandbookItems.BOOK);
    }

}
