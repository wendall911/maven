package handbook.platform.services;

import java.util.Collection;

import org.jetbrains.annotations.Nullable;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.server.MinecraftServer;
import handbook.common.CommonModContainer;

/**
 * Cross-modloader abstracted calls
 */
public interface IBookHelper {

    // Events
    void fireDrawBookScreen(class_2960 book, class_437 gui, int mouseX, int mouseY, float partialTicks, class_332 graphics);

    // Networking
    void sendReloadContentsMessage(MinecraftServer server);
    void sendOpenBookGui(class_3222 player, class_2960 book, @Nullable class_2960 entry, int page);

    // FML/FabricLoader-related
    Collection<CommonModContainer> getAllMods();
    CommonModContainer getModContainer(String modId);

    boolean isDevEnvironment();

    // Needed because of Forge
    default void signalBooksLoaded() {}

    // JEI/REI compat
    boolean handleRecipeKeybind(int keyCode, int scanCode, class_1799 stack);

}
