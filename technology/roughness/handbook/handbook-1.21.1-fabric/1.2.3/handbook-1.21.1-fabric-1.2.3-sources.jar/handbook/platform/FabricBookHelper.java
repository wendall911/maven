package handbook.platform;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.jetbrains.annotations.Nullable;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.server.MinecraftServer;
import handbook.common.CommonModContainer;
import handbook.common.FabricModContainer;
import handbook.event.BookDrawScreenCallback;
import handbook.integration.rei.ReiCompat;
import handbook.network.FabricMessageOpenBookGui;
import handbook.network.FabricMessageReloadBookContents;
import handbook.platform.services.IBookHelper;

public class FabricBookHelper implements IBookHelper {

    @Override
    public void fireDrawBookScreen(class_2960 book, class_437 gui, int mouseX, int mouseY, float partialTicks, class_332 graphics) {
        BookDrawScreenCallback.EVENT.invoker().trigger(book, gui, mouseX, mouseY, partialTicks, graphics);
    }

    @Override
    public void sendReloadContentsMessage(MinecraftServer server) {
        FabricMessageReloadBookContents.sendToAll(server);
    }

    @Override
    public void sendOpenBookGui(class_3222 player, class_2960 book, @Nullable class_2960 entry, int page) {
        FabricMessageOpenBookGui.send(player, book, entry, page);
    }

    @Override
    public Collection<CommonModContainer> getAllMods() {
        List<CommonModContainer> ret = new ArrayList<>();
        for (var mod : FabricLoader.getInstance().getAllMods()) {
            ret.add(new FabricModContainer(mod));
        }
        return ret;
    }

    @Override
    public CommonModContainer getModContainer(String modId) {
        return new FabricModContainer(FabricLoader.getInstance().getModContainer(modId).get());
    }

    @Override
    public boolean isDevEnvironment() {
        return FabricLoader.getInstance().isDevelopmentEnvironment();
    }

    @Override
    public boolean handleRecipeKeybind(int keyCode, int scanCode, @Nullable class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        else if (FabricLoader.getInstance().isModLoaded("roughlyenoughitems")) {
            return ReiCompat.handleRecipeKeybind(keyCode, scanCode, stack);
        }

        return false;
    }

}
