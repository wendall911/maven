package handbook;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_5272;
import handbook.api.HandbookAPI;
import handbook.client.base.BookModel;
import handbook.client.base.ClientTicker;
import handbook.client.base.PersistentData;
import handbook.client.book.BookContentResourceListenerLoader;
import handbook.client.book.ClientBookRegistry;
import handbook.client.handler.BookRightClickHandler;
import handbook.common.book.Book;
import handbook.common.book.BookRegistry;
import handbook.common.item.HandbookBook;
import handbook.common.item.HandbookItems;
import handbook.network.FabricMessageOpenBookGui;
import handbook.network.FabricMessageReloadBookContents;
import handbook.network.MessageOpenBookGui;
import handbook.network.MessageReloadBookContents;

public class HandbookClientFabric implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ClientBookRegistry.INSTANCE.init();
        PersistentData.setup();
        ClientTickEvents.END_CLIENT_TICK.register(ClientTicker::endClientTick);
        HudRenderCallback.EVENT.register(BookRightClickHandler::onRenderHUD);
        UseBlockCallback.EVENT.register(BookRightClickHandler::onRightClick);
        ClientPlayNetworking.registerGlobalReceiver(MessageOpenBookGui.TYPE, FabricMessageOpenBookGui::handle);
        ClientPlayNetworking.registerGlobalReceiver(MessageReloadBookContents.TYPE, FabricMessageReloadBookContents::handle);

        ModelLoadingPlugin.register(pluginContext -> {
            for (Book book : BookRegistry.INSTANCE.books.values()) {
                HandbookAPI.LOGGER.info("Adding model {}", book.model);
                pluginContext.addModels(book.model);
            }

            pluginContext.modifyModelAfterBake().register(
                    (oldModel, ctx) -> {
                        if (ctx.topLevelId() != null &&
                                HandbookItems.BOOK_ID.equals(ctx.topLevelId().comp_2875()) // checks namespace and path
                                && ctx.topLevelId().method_4740().equals("inventory")
                                && oldModel != null) {
                            return new BookModel(oldModel, (model) -> class_310.method_1551().method_1554().getModel(model));
                        }
                        return oldModel;
                    }
            );
        });

        class_5272.method_27879(HandbookItems.BOOK,
                HandbookAPI.prefix("completion"),
                (stack, world, entity, seed) -> HandbookBook.getCompletion(stack));

        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new IdentifiableResourceReloadListener() {
            private static final class_2960 id = HandbookAPI.prefix("resource_pack_books");

            @Override
            public CompletableFuture<Void> method_25931(class_4045 barrier, class_3300 manager, class_3695 preparationsProfiler, class_3695 reloadProfiler, Executor backgroundExecutor, Executor gameExecutor) {
                return BookContentResourceListenerLoader.INSTANCE.method_25931(barrier, manager, preparationsProfiler, reloadProfiler, backgroundExecutor, gameExecutor);
            }

            @Override
            public class_2960 getFabricId() {
                return id;
            }
        });
        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
            private static final class_2960 id = HandbookAPI.prefix("reload_hook");

            @Override
            public class_2960 getFabricId() {
                return id;
            }

            @Override
            public void method_14491(class_3300 manager) {
                if (class_310.method_1551().field_1687 != null) {
                    HandbookAPI.LOGGER.info("Reloading resource pack-based books");
                    ClientBookRegistry.INSTANCE.reload();
                } else {
                    HandbookAPI.LOGGER.debug("Not reloading resource pack-based books as client world is missing");
                }
            }
        });
    }

}
