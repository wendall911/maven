package handbook.network;

import org.jetbrains.annotations.Nullable;
import handbook.api.HandbookAPI;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record MessageOpenBookGui(class_2960 book, @Nullable class_2960 entry, int page) implements class_8710 {

    public static final class_2960 ID = class_2960.method_60655(HandbookAPI.MODID, "open_book");
    public static final class_9139<class_2540, MessageOpenBookGui> CODEC = class_9139.method_56436(
        class_2960.field_48267,
        MessageOpenBookGui::book,
        class_9135.field_48554.method_56432(
            entry -> entry.isEmpty() ? null :
                class_2960.method_12829(entry), entry -> entry == null ? "" : entry.toString()
        ),
        MessageOpenBookGui::entry,
        class_9135.field_48550,
        MessageOpenBookGui::page,
        MessageOpenBookGui::new
    );
    public static final class_9154<MessageOpenBookGui> TYPE = new class_9154<>(ID);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

}
