package handbook.network;

import org.jetbrains.annotations.NotNull;
import handbook.api.HandbookAPI;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record MessageReloadBookContents() implements class_8710 {

    public static final class_2960 ID = HandbookAPI.prefix("reload_books");
    public static final class_9139<class_2540, MessageReloadBookContents> CODEC = class_9139.method_56431(
        new MessageReloadBookContents()
    );
    public static final class_9154<MessageReloadBookContents> TYPE = new class_9154<>(ID);

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

}
