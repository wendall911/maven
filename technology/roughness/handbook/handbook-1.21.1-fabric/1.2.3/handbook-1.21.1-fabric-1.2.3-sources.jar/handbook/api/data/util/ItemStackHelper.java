package handbook.api.data.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.class_1799;
import net.minecraft.class_2290;
import net.minecraft.class_7225;

public class ItemStackHelper {

	private static final Gson GSON = new GsonBuilder().create();

	public static String serializeStack(class_1799 stack, class_7225.class_7874 registries) {
		return new class_2290(stack.method_41409(), stack.method_57380())
            .method_9782(registries) + (stack.method_7947() == 1 ? "" :("#" + stack.method_7947()));
	}

}
