package handbook.api.data.page;

import handbook.api.data.EntryBuilder;
import net.minecraft.class_2960;

public class SmithingPageBuilder extends RecipePageBuilder<SmithingPageBuilder> {

    public SmithingPageBuilder(class_2960 recipe, EntryBuilder entryBuilder) {
        super("handbook:smithing", recipe, entryBuilder);
    }

}
