package handbook.api.data.page;

import handbook.api.data.EntryBuilder;
import net.minecraft.class_2960;

public class StonecuttingPageBuilder extends RecipePageBuilder<StonecuttingPageBuilder> {

    public StonecuttingPageBuilder(class_2960 recipe, EntryBuilder entryBuilder) {
        super("handbook:stonecutting", recipe, entryBuilder);
    }

}
