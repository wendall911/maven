package handbook.api;

import net.minecraft.class_7225;

/**
 * A provider of variables to a template. Probably a JSON.
 */
public interface IVariableProvider {

    /**
     * Gets the value assigned to the variable passed in.
     * May throw an exception if it doesn't exist.
     */
    IVariable get(String key, class_7225.class_7874 registries);

    /**
     * Returns if a variable exists or not.
     */
    boolean has(String key);

}
