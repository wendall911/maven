package handbook.api.data.page;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import handbook.api.data.AbstractPageBuilder;
import handbook.api.data.EntryBuilder;

public class ImagePageBuilder extends AbstractPageBuilder<ImagePageBuilder> {

    private final List<class_2960> images = new ArrayList<>();
    private String title;
    private Boolean border;
    private String text;

    public ImagePageBuilder(class_2960 image, EntryBuilder parent) {
        super("handbook:image", parent);
        this.images.add(image);
    }

    @Override
    protected void serialize(JsonObject json) {
        JsonArray images = new JsonArray();

        for (class_2960 image : this.images) {
            images.add(image.toString());
        }
        json.add("images", images);
        if (title != null) {
            json.addProperty("title", title);
        }
        if (border != null) {
            json.addProperty("border", border);
        }
        if (text != null) {
            json.addProperty("text", text);
        }
    }

    public ImagePageBuilder addImage(class_2960 image) {
        images.add(image);

        return this;
    }

    public ImagePageBuilder setTitle(String title) {
        this.title = title;

        return this;
    }

    public ImagePageBuilder setBorder(Boolean border) {
        this.border = border;

        return this;
    }

    public ImagePageBuilder setText(String text) {
        this.text = text;

        return this;
    }

}
