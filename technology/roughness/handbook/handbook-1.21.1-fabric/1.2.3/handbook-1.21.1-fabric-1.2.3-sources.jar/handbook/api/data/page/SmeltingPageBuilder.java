package handbook.api.data.page;

import handbook.api.data.EntryBuilder;
import net.minecraft.class_2960;

public class SmeltingPageBuilder extends RecipePageBuilder<SmeltingPageBuilder> {

    public SmeltingPageBuilder(class_2960 recipe, EntryBuilder entryBuilder) {
        super("handbook:smelting", recipe, entryBuilder);
    }

}
