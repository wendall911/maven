package handbook.api.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import handbook.api.data.page.BlastingPageBuilder;
import handbook.api.data.page.CampfirePageBuilder;
import handbook.api.data.page.CraftingPageBuilder;
import handbook.api.data.page.CustomPageBuilder;
import handbook.api.data.page.EmptyPageBuilder;
import handbook.api.data.page.EntityPageBuilder;
import handbook.api.data.page.FormattedTextPageBuilder;
import handbook.api.data.page.ImagePageBuilder;
import handbook.api.data.page.LinkPageBuilder;
import handbook.api.data.page.QuestPageBuilder;
import handbook.api.data.page.RelationsPageBuilder;
import handbook.api.data.page.SmeltingPageBuilder;
import handbook.api.data.page.SmithingPageBuilder;
import handbook.api.data.page.SmokingPageBuilder;
import handbook.api.data.page.SpotlightPageBuilder;
import handbook.api.data.page.StonecuttingPageBuilder;
import handbook.api.data.page.TextPageBuilder;
import handbook.api.data.util.ItemStackHelper;
import handbook.api.data.util.TagKeyHelper;

public class EntryBuilder {

    private final CategoryBuilder parent;
    private final class_2960 id;
    private final String name;
    private final String category;
    private final String icon;
    private final List<AbstractPageBuilder<?>> pages = new ArrayList<>();
    private String advancement;
    private String flag;
    private Boolean priority;
    private Boolean secret;
    private Boolean readByDefault;
    private Integer sortnum;
    private String turnin;
    private Map<class_1799, Integer> extraRecipeMappings;
    private Map<class_6862<class_1792>, Integer> extraRecipeMappingTags;
    private class_7225.class_7874 provider;

    protected EntryBuilder(String id, String name, String icon, CategoryBuilder parent,
            class_7225.class_7874 provider) {
        this.id = class_2960.method_60655(parent.getId().method_12836(), id);
        this.name = name;
        this.category = parent.getId().toString();
        this.icon = icon;
        this.parent = parent;
        this.provider = provider;
    }

    protected EntryBuilder(String id, String name, class_1799 icon, CategoryBuilder parent,
            class_7225.class_7874 provider) {
        this(id, name, ItemStackHelper.serializeStack(icon, provider), parent, provider);
    }

    JsonObject toJson() {
        JsonObject json = new JsonObject();
        json.addProperty("name", name);
        json.addProperty("category", category);
        json.addProperty("icon", icon);
        JsonArray pages = new JsonArray();

        for (AbstractPageBuilder<?> page : this.pages) {
            pages.add(page.toJson());
        }

        json.add("pages", pages);

        if (advancement != null) {
            json.addProperty("advancement", advancement);
        }
        if (flag != null) {
            json.addProperty("flag", flag);
        }
        if (priority != null) {
            json.addProperty("priority", priority);
        }
        if (secret != null) {
            json.addProperty("secret", secret);
        }
        if (readByDefault != null) {
            json.addProperty("read_by_default", readByDefault);
        }
        if (sortnum != null) {
            json.addProperty("sortnum", sortnum);
        }
        if (turnin != null) {
            json.addProperty("turnin", turnin);
        }
        if (extraRecipeMappings != null || extraRecipeMappingTags != null) {
            JsonObject mappings = new JsonObject();

            if (extraRecipeMappingTags != null) {
                for (Map.Entry<class_6862<class_1792>, Integer> entry : extraRecipeMappingTags.entrySet()) {
                    mappings.addProperty(TagKeyHelper.serializeTagKey(entry.getKey()), entry.getValue());
                }
            }
            if (extraRecipeMappings != null) {
                for (Map.Entry<class_1799, Integer> entry : extraRecipeMappings.entrySet()) {
                    mappings.addProperty(ItemStackHelper.serializeStack(entry.getKey(), provider), entry.getValue());
                }
            }

            json.add("extra_recipe_mappings", mappings);
        }

        return json;
    }

    public CategoryBuilder build() {
        return parent;
    }

    public EntryBuilder addSimpleTextPage(String text) {
        return addPage(new TextPageBuilder(text, this)).build();
    }

    public EntryBuilder addSimpleTextPage(String text, String title) {
        return addPage(new TextPageBuilder(text, title, this)).build();
    }

    public TextPageBuilder addTextPage(String text) {
        return addPage(new TextPageBuilder(text, this));
    }

    public TextPageBuilder addTextPage(String text, String title) {
        return addPage(new TextPageBuilder(text, title, this));
    }

    public FormattedTextPageBuilder addFormattedTextPage(String translate) {
        return addPage(new FormattedTextPageBuilder(translate, this));
    }

    public CustomPageBuilder addCustomPage(String template) {
        return addPage(new CustomPageBuilder(template, this));
    }

    public ImagePageBuilder addImagePage(class_2960 image) {
        return addPage(new ImagePageBuilder(image, this));
    }

    public RelationsPageBuilder addRelationsPage() {
        return addPage(new RelationsPageBuilder(this));
    }

    public QuestPageBuilder addQuestPage() {
        return addPage(new QuestPageBuilder(this, null));
    }

    public QuestPageBuilder addQuestPage(class_2960 trigger) {
        return addPage(new QuestPageBuilder(this, trigger));
    }

    public CraftingPageBuilder addCraftingPage(class_2960 recipe) {
        return addPage(new CraftingPageBuilder(recipe, this));
    }

    public SmeltingPageBuilder addSmeltingPage(class_2960 recipe) {
        return addPage(new SmeltingPageBuilder(recipe, this));
    }

    public BlastingPageBuilder addBlastingPage(class_2960 recipe) {
        return addPage(new BlastingPageBuilder(recipe, this));
    }

    public SmokingPageBuilder addSmokingPage(class_2960 recipe) {
        return addPage(new SmokingPageBuilder(recipe, this));
    }

    public CampfirePageBuilder addCampfirePage(class_2960 recipe) {
        return addPage(new CampfirePageBuilder(recipe, this));
    }

    public SmithingPageBuilder addSmithingPage(class_2960 recipe) {
        return addPage(new SmithingPageBuilder(recipe, this));
    }

    public StonecuttingPageBuilder addStonecuttingPage(class_2960 recipe) {
        return addPage(new StonecuttingPageBuilder(recipe, this));
    }

    public EntityPageBuilder addEntityPage(String entity) {
        return addPage(new EntityPageBuilder(entity, this));
    }

    public EntityPageBuilder addEntityPage(class_2960 entity) {
        return addEntityPage(entity.toString());
    }

    public SpotlightPageBuilder addSpotlightPage(class_1799... stacks) {
        return addPage(new SpotlightPageBuilder(this, provider, stacks));
    }

    @SafeVarargs
    public final SpotlightPageBuilder addSpotlightPage(class_6862<class_1792>... tags) {
        return addPage(new SpotlightPageBuilder(this, provider, tags));
    }

    public LinkPageBuilder addLinkPage(String url, String linkText) {
        return addPage(new LinkPageBuilder(url, linkText, this));
    }

    public EmptyPageBuilder addEmptyPage() {
        return addPage(new EmptyPageBuilder(true, this));
    }

    public EmptyPageBuilder addEmptyPage(boolean drawFiller) {
        return addPage(new EmptyPageBuilder(drawFiller, this));
    }

    public <T extends AbstractPageBuilder<T>> T addPage(T builder) {
        pages.add(builder);

        return builder;
    }

    public EntryBuilder setAdvancement(String advancement) {
        this.advancement = advancement;

        return this;
    }

    public EntryBuilder setFlag(String flag) {
        this.flag = flag;

        return this;
    }

    public EntryBuilder setPriority(boolean priority) {
        this.priority = priority;

        return this;
    }

    public EntryBuilder setSecret(boolean secret) {
        this.secret = secret;

        return this;
    }

    public EntryBuilder setReadByDefault(boolean readByDefault) {
        this.readByDefault = readByDefault;

        return this;
    }

    public EntryBuilder setSortnum(int sortnum) {
        this.sortnum = sortnum;

        return this;
    }

    public EntryBuilder setTurnin(String turnin) {
        this.turnin = turnin;

        return this;
    }

    public EntryBuilder addExtraRecipeMapping(class_1799 stack, int index) {
        if (this.extraRecipeMappings == null) {
            this.extraRecipeMappings = new HashMap<>();
        }
        this.extraRecipeMappings.put(stack, index);

        return this;
    }

    public EntryBuilder addExtraRecipeMapping(class_6862<class_1792> tag, int index) {
        if (this.extraRecipeMappingTags == null) {
            this.extraRecipeMappingTags = new HashMap<>();
        }
        this.extraRecipeMappingTags.put(tag, index);

        return this;
    }

    protected class_2960 getId() {
        return id;
    }

}
