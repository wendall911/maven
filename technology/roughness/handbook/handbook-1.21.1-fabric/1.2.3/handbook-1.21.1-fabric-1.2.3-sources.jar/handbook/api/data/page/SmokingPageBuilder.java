package handbook.api.data.page;

import handbook.api.data.EntryBuilder;
import net.minecraft.class_2960;

public class SmokingPageBuilder extends RecipePageBuilder<SmokingPageBuilder> {

    public SmokingPageBuilder(class_2960 recipe, EntryBuilder entryBuilder) {
        super("handbook:smoking", recipe, entryBuilder);
    }

}
