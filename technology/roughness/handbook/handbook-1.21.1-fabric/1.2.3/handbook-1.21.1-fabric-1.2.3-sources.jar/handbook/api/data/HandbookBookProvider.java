package handbook.api.data;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import org.jetbrains.annotations.NotNull;

import com.google.gson.JsonObject;
import technology.roughness.whitenoise.util.ResourceLocationHelper;

public abstract class HandbookBookProvider implements class_2405 {

    protected final class_7784.class_7489 datapackProvider;
    protected final class_7784.class_7489 assetsProvider;

    private final String locale;
    private final String modid;
    private final CompletableFuture<class_7225.class_7874> registries;

    public HandbookBookProvider(class_7784 packOutput, String modid, String locale, CompletableFuture<class_7225.class_7874> registries) {
        this.datapackProvider = packOutput.method_45973(class_7784.class_7490.field_39367, "handbook_books");
        this.assetsProvider = packOutput.method_45973(class_7784.class_7490.field_39368, "handbook_books");
        this.modid = modid;
        this.locale = locale;
        this.registries = registries;
    }

    /**
     * Performs this provider's action.
     *
     * @param cache the cache
     * @return the completable future
     */
    @Override
    public @NotNull CompletableFuture<?> method_10319(@NotNull class_7403 cache) {
        return this.registries.thenCompose(provider -> {
            List<CompletableFuture<?>> list = new ArrayList<>();

            this.addBooks(book -> {
                list.add(saveBook(cache, book.toJson(), book.getId()));

                for (CategoryBuilder category : book.getCategories()) {
                    list.add(saveCategory(cache, category.toJson(), book.getId(), category.getId()));

                    for (EntryBuilder entry : category.getEntries()) {
                        list.add(saveEntry(cache, entry.toJson(), book.getId(), entry.getId()));
                    }
                }
                for (TemplateBuilder template : book.getTemplates()) {
                    list.add(saveTemplate(cache, template.toJson(), book.getId(), template.getId()));
                }
            }, provider);

            return CompletableFuture.allOf(list.toArray(CompletableFuture[]::new));
        });
    }

    protected abstract void addBooks(Consumer<BookBuilder> consumer, class_7225.class_7874 provider);

    private CompletableFuture<?> saveEntry(class_7403 cache, JsonObject json, class_2960 bookId, class_2960 id) {
        String pathSuffix = bookId.method_12832() + "/" + locale + "/entries/" + id.method_12832();

        return class_2405.method_10320(cache, json, assetsProvider.method_44107(class_2960.method_60655(bookId.method_12836(), pathSuffix)));
    }

    private CompletableFuture<?> saveCategory(class_7403 cache, JsonObject json, class_2960 bookId, class_2960 id) {
        String pathSuffix = bookId.method_12832() + "/" + locale + "/categories/" + id.method_12832();

        return class_2405.method_10320(cache, json, assetsProvider.method_44107(class_2960.method_60655(bookId.method_12836(), pathSuffix)));
    }

    private CompletableFuture<?> saveTemplate(class_7403 cache, JsonObject json, class_2960 bookId, class_2960 id) {
        String pathSuffix = bookId.method_12832() + "/" + locale + "/templates/" + id.method_12832();

        return class_2405.method_10320(cache, json, assetsProvider.method_44107(class_2960.method_60655(bookId.method_12836(), pathSuffix)));
    }

    private CompletableFuture<?> saveBook(class_7403 cache, JsonObject json, class_2960 bookId) {
        String pathSuffix = bookId.method_12832() + "/book";

        return class_2405.method_10320(cache, json, datapackProvider.method_44107(class_2960.method_60655(bookId.method_12836(), pathSuffix)));
    }

    public BookBuilder createBookBuilder(String id, String name, String landingText, class_7225.class_7874 provider) {
        return new BookBuilder(modid, id, name, landingText, provider);
    }

    /**
     * Creates a BookBuilder for a book with the given item.
     * The item is used both as the book item and to derive the book ID and model.
     */
    public BookBuilder createBookBuilder(class_1792 item, String name, String landingText, class_7225.class_7874 provider) {
        class_1799 bookItem = new class_1799(item);
        class_2960 itemId = ResourceLocationHelper.getItemStackId(bookItem);

        return new BookBuilder(itemId, name, landingText, provider)
            .setModel(itemId)
            .setCustomBookItem(bookItem);
    }

    /**
     * Gets a name for this provider, to use in logging.
     */
    @NotNull
    @Override
    public String method_10321() {
        return "Handbook Book Provider";
    }

}
