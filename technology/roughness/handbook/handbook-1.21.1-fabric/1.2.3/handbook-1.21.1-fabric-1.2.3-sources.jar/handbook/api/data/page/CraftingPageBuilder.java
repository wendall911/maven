package handbook.api.data.page;

import handbook.api.data.EntryBuilder;
import net.minecraft.class_2960;

public class CraftingPageBuilder extends RecipePageBuilder<CraftingPageBuilder> {

    public CraftingPageBuilder(class_2960 recipe, EntryBuilder entryBuilder) {
        super("handbook:crafting", recipe, entryBuilder);
    }

}
