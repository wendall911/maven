package handbook.api.data.util;

import net.minecraft.class_6862;

public class TagKeyHelper {

    public static String serializeTagKey(class_6862<?> tag) {
        return "tag:" + tag.comp_327();
    }

}
