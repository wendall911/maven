package handbook.api.data.page;

import handbook.api.data.EntryBuilder;
import net.minecraft.class_2960;

public class CampfirePageBuilder extends RecipePageBuilder<CampfirePageBuilder> {

    public CampfirePageBuilder(class_2960 recipe, EntryBuilder entryBuilder) {
        super("handbook:campfire", recipe, entryBuilder);
    }

}
