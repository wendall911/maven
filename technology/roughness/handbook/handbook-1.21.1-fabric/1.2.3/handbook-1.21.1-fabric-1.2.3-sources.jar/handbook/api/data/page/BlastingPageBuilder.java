package handbook.api.data.page;

import handbook.api.data.EntryBuilder;
import net.minecraft.class_2960;

public class BlastingPageBuilder extends RecipePageBuilder<BlastingPageBuilder> {

    public BlastingPageBuilder(class_2960 recipe, EntryBuilder entryBuilder) {
        super("handbook:blasting", recipe, entryBuilder);
    }

}
