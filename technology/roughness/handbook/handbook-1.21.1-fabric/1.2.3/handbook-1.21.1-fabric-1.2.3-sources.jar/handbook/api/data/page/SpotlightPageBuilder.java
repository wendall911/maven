package handbook.api.data.page;

import com.google.gson.JsonObject;
import handbook.api.data.AbstractPageBuilder;
import handbook.api.data.EntryBuilder;
import handbook.api.data.util.ItemStackHelper;
import handbook.api.data.util.TagKeyHelper;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_6862;
import net.minecraft.class_7225;

public class SpotlightPageBuilder extends AbstractPageBuilder<SpotlightPageBuilder> {

    private String item;
    private String title;
    private Boolean linkRecipe;
    private String text;
    private class_7225.class_7874 provider;

    public SpotlightPageBuilder(EntryBuilder parent, class_7225.class_7874 provider, class_1799... stacks) {
        super("handbook:spotlight", parent);
        this.item = serializeStacks(stacks, provider);
        this.provider = provider;
    }

    @SafeVarargs
    public SpotlightPageBuilder(EntryBuilder parent, class_7225.class_7874 provider, class_6862<class_1792>... tag) {
        super("handbook:spotlight", parent);
        this.item = serializeTagKeys(tag);
        this.provider = provider;
    }

    private String serializeStacks(class_1799[] stacks, class_7225.class_7874 provider) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < stacks.length; i++) {
            sb.append(ItemStackHelper.serializeStack(stacks[i], provider));
            if (i < stacks.length - 1) {
                sb.append(",");
            }
        }
        return sb.toString();
    }

    private String serializeTagKeys(class_6862<class_1792>[] tags) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < tags.length; i++) {
            sb.append(TagKeyHelper.serializeTagKey(tags[i]));
            if (i < tags.length - 1) {
                sb.append(",");
            }
        }
        return sb.toString();
    }


    @Override
    protected void serialize(JsonObject json) {
        json.addProperty("item", item);

        if (title != null) {
            json.addProperty("title", title);
        }
        if (linkRecipe != null) {
            json.addProperty("link_recipe", linkRecipe);
        }
        if (text != null) {
            json.addProperty("text", text);
        }
    }

    public SpotlightPageBuilder setTitle(String title) {
        this.title = title;

        return this;
    }

    public SpotlightPageBuilder setLinkRecipe(Boolean linkRecipe) {
        this.linkRecipe = linkRecipe;

        return this;
    }

    public SpotlightPageBuilder setText(String text) {
        this.text = text;

        return this;
    }

    @SafeVarargs
    public final SpotlightPageBuilder addTag(class_6862<class_1792>... tags) {
        this.item = this.item + "," + serializeTagKeys(tags);

        return this;
    }

    public final SpotlightPageBuilder addItem(class_1799... stacks) {
        this.item = this.item + "," + serializeStacks(stacks, provider);

        return this;
    }

}
