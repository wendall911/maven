package handbook.api.stub;

import java.io.InputStream;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import handbook.api.IStyleStack;
import handbook.api.HandbookAPI.IHandbookAPI;

public class StubHandbookAPI implements IHandbookAPI {

    public static final StubHandbookAPI INSTANCE = new StubHandbookAPI();

    private StubHandbookAPI() {}

    @Override
    public void setConfigFlag(String flag, boolean value) {
        // NO-OP
    }

    @Override
    public boolean getConfigFlag(String flag) {
        return false;
    }

    @Override
    public void openBookGUI(class_3222 player, class_2960 book) {
        // NO-OP
    }

    @Override
    public void openBookEntry(class_3222 player, class_2960 book, class_2960 entry, int page) {

    }

    @Override
    public void openBookGUI(class_2960 book) {
        // NO-OP
    }

    @Override
    public void openBookEntry(class_2960 book, class_2960 entry, int page) {}

    @Override
    public class_2960 getOpenBookGui() {
        return null;
    }

    @Override
    public class_2561 getSubtitle(class_2960 bookId) {
        throw new IllegalArgumentException("Handbook is not loaded");
    }

    @Override
    public void registerCommand(String name, Function<IStyleStack, String> command) {
        // NO-OP
    }

    @Override
    public void registerFunction(String name, BiFunction<String, IStyleStack, String> function) {
        // NO-OP
    }

    @Override
    public class_1799 getBookStack(class_2960 book) {
        return class_1799.field_8037;
    }

    @Override
    public void registerTemplateAsBuiltin(class_2960 res, Supplier<InputStream> streamProvider) {
        // NO-OP
    }

}
