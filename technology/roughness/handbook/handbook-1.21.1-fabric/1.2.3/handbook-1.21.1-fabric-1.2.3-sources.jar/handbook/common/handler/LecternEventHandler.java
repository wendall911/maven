package handbook.common.handler;

import handbook.api.HandbookAPI;
import handbook.common.book.Book;
import handbook.common.util.ItemStackUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3715;
import net.minecraft.class_3722;
import net.minecraft.class_3965;

public class LecternEventHandler {

    public static class_1269 rightClick(class_1657 player, class_1937 world, class_1268 hand, class_3965 hit) {
        class_2338 pos = hit.method_17777();
        class_2680 state = world.method_8320(pos);
        class_2586 tileEntity = world.method_8321(pos);

        if (tileEntity instanceof class_3722 lectern) {
            if (state.method_11654(class_3715.field_17366)) {
                if (player.method_21823()) {
                    takeBook(player, lectern);
                }
                else {
                    Book book = ItemStackUtil.getBookFromStack(lectern.method_17520());

                    if (book != null) {
                        if (!world.field_9236) {
                            HandbookAPI.get().openBookGUI((class_3222) player, book.id);
                        }
                        return class_1269.field_5812;
                    }
                }
            }
            else {
                class_1799 stack = player.method_5998(hand);

                if (ItemStackUtil.getBookFromStack(stack) != null) {
                    if (class_3715.method_17472(player, world, pos, state, stack)) {
                        return class_1269.field_5812;
                    }
                }
            }
        }

        return class_1269.field_5811;
    }

    private static void takeBook(class_1657 player, class_3722 tileEntity) {
        class_1799 itemstack = tileEntity.method_17520();
        tileEntity.method_17513(class_1799.field_8037);
        class_3715.method_17473(player, tileEntity.method_10997(), tileEntity.method_11016(), tileEntity.method_11010(), false);

        if (!player.method_31548().method_7394(itemstack)) {
            player.method_7328(itemstack, false);
        }
    }

}
