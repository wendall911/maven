package handbook.common.advancement;

import java.util.function.BiConsumer;
import net.minecraft.class_179;
import net.minecraft.class_2960;

public class HandbookCriteriaTriggers {

    public static final BookOpenTrigger BOOK_OPEN = new BookOpenTrigger();

    public static void submitTriggerRegistrations(BiConsumer<class_2960, class_179<?>> consumer) {
        consumer.accept(BookOpenTrigger.ID, BOOK_OPEN);
    }

}
