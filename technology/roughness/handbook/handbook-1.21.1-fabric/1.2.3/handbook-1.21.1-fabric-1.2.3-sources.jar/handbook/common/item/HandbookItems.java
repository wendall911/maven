package handbook.common.item;

import java.util.function.BiConsumer;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import handbook.api.HandbookAPI;

public class HandbookItems {

    public static final class_2960 BOOK_ID = HandbookAPI.prefix("handbook_book");
    public static final class_2960 BOOK_BLUE_ID = HandbookAPI.prefix("book_blue");
    public static final class_2960 BOOK_BROWN_ID = HandbookAPI.prefix("book_brown");
    public static final class_2960 BOOK_CYAN_ID = HandbookAPI.prefix("book_cyan");
    public static final class_2960 BOOK_GRAY_ID = HandbookAPI.prefix("book_gray");
    public static final class_2960 BOOK_GREEN_ID = HandbookAPI.prefix("book_green");
    public static final class_2960 BOOK_PURPLE_ID = HandbookAPI.prefix("book_purple");
    public static final class_2960 BOOK_RED_ID = HandbookAPI.prefix("book_red");
    public static final class_1792 BOOK = new HandbookBook();

    public static void submitItemRegistrations(BiConsumer<class_2960, class_1792> consumer) {
        consumer.accept(BOOK_ID, BOOK);
    }

}
