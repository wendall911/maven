package handbook.common.base;

import java.util.function.BiConsumer;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;
import handbook.api.HandbookAPI;

public class HandbookSounds {

    public static final class_3414 BOOK_OPEN = class_3414.method_47908(HandbookAPI.prefix("book_open"));
    public static final class_3414 BOOK_FLIP = class_3414.method_47908(HandbookAPI.prefix("book_flip"));

    public static void submitRegistrations(BiConsumer<class_2960, class_3414> e) {
        e.accept(BOOK_OPEN.method_14833(), BOOK_OPEN);
        e.accept(BOOK_FLIP.method_14833(), BOOK_FLIP);
    }

    public static class_3414 getSound(class_2960 key, class_3414 fallback) {
        return class_7923.field_41172.method_17966(key).orElse(fallback);
    }

}
