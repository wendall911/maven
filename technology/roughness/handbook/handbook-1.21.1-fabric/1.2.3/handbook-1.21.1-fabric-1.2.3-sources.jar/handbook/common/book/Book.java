package handbook.common.book;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3518;
import net.minecraft.class_5250;
import net.minecraft.class_7887;
import org.jetbrains.annotations.Nullable;

import com.google.common.base.Suppliers;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import handbook.api.HandbookAPI;
import handbook.client.base.ClientAdvancements;
import handbook.client.book.BookContents;
import handbook.client.book.BookContentsBuilder;
import handbook.client.book.BookEntry;
import handbook.client.book.BookIcon;
import handbook.common.base.HandbookSounds;
import handbook.common.item.HandbookBook;
import handbook.common.util.ColorHelper;
import handbook.common.util.ColorHelper.HandbookColors;
import handbook.common.util.ItemStackUtil;
import handbook.common.util.SerializationUtil;
import handbook.common.CommonModContainer;
import handbook.config.HandbookConfig;

public class Book {

    private static final String[] ORDINAL_SUFFIXES = new String[] { "th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th" };
    private static final class_2960 DEFAULT_MODEL = HandbookAPI.prefix("book_brown");
    private static final class_2960 DEFAULT_FILLER_TEXTURE = HandbookAPI.prefix("textures/gui/page_filler.png");
    private static final class_2960 DEFAULT_CRAFTING_TEXTURE = HandbookAPI.prefix("textures/gui/crafting.png");

    private static final Map<String, String> DEFAULT_MACROS = class_156.method_656(() -> {
        Map<String, String> ret = new HashMap<>();
        ret.put("$(list", "$(li"); //  The lack of ) is intended
        ret.put("/$", "$()");
        ret.put("<br>", "$(br)");

        ret.put("$(item)", "$(#b0b)");
        ret.put("$(thing)", "$(#490)");
        return ret;
    });

    private BookContents contents;

    private boolean wasUpdated = false;

    public final CommonModContainer owner;
    public final class_2960 id;
    private Supplier<class_1799> bookItem;

    public final int textColor, headerColor, nameplateColor, linkColor, linkHoverColor, progressBarColor, progressBarBackground;

    // JSON Loaded properties

    public final String name;
    public final String landingText;

    public final class_2960 bookTexture, fillerTexture, craftingTexture;

    public final class_2960 model;

    public final boolean useBlockyFont;

    public final class_2960 openSound, flipSound;

    public final boolean showProgress;

    public final String indexIconRaw;

    public final String version;
    public final String subtitle;

    @Nullable public final class_2960 creativeTab;

    @Nullable public final class_2960 advancementsTab;

    public final boolean noBook;

    public final boolean showToasts;

    public final boolean pauseGame;

    public final boolean isPamphlet;

    public final boolean i18n;
    @Nullable public final HandbookConfig.TextOverflowMode overflowMode;

    public final Map<String, String> macros = new HashMap<>();

    private static int parseColor(JsonObject root, String key, String defaultColor) {
        return ColorHelper.getHandbookColor(class_3518.method_15253(root, key, defaultColor));
    }

    public Book(JsonObject root, CommonModContainer owner, class_2960 id) {
        this.name = class_3518.method_15265(root, "name");
        this.landingText = class_3518.method_15253(root, "landing_text", "handbook.gui.lexicon.landing_info");
        this.bookTexture = SerializationUtil.getAsResourceLocation(root, "book_texture", BookLayoutTexture.DEFAULT.texture());
        this.fillerTexture = SerializationUtil.getAsResourceLocation(root, "filler_texture", DEFAULT_FILLER_TEXTURE);
        this.craftingTexture = SerializationUtil.getAsResourceLocation(root, "crafting_texture", DEFAULT_CRAFTING_TEXTURE);
        this.model = SerializationUtil.getAsResourceLocation(root, "model", DEFAULT_MODEL).method_45138("item/");
        this.useBlockyFont = class_3518.method_15258(root, "use_blocky_font", false);

        this.owner = owner;
        this.id = id;
        this.textColor = parseColor(root, "text_color", HandbookColors.TEXT.getHex());
        this.headerColor = parseColor(root, "header_color", HandbookColors.HEADER.getHex());
        this.nameplateColor = parseColor(root, "nameplate_color", HandbookColors.NAMEPLATE.getHex());
        this.linkColor = parseColor(root, "link_color", HandbookColors.LINK.getHex());
        this.linkHoverColor = parseColor(root, "link_hover_color", HandbookColors.LINK_HOVER.getHex());
        this.progressBarColor = parseColor(root, "progress_bar_color", HandbookColors.PROGRESS_BAR.getHex());
        this.progressBarBackground = parseColor(root, "progress_bar_background", HandbookColors.PROGRESS_BAR_BACKGROUND.getHex());
        this.openSound = SerializationUtil.getAsResourceLocation(root, "open_sound", HandbookSounds.BOOK_OPEN.method_14833());
        this.flipSound = SerializationUtil.getAsResourceLocation(root, "flip_sound", HandbookSounds.BOOK_FLIP.method_14833());
        this.showProgress = class_3518.method_15258(root, "show_progress", true);
        this.indexIconRaw = class_3518.method_15253(root, "index_icon", "");
        this.version = class_3518.method_15253(root, "version", "0");
        this.subtitle = class_3518.method_15253(root, "subtitle", "");
        this.creativeTab = SerializationUtil.getAsResourceLocation(root, "creative_tab", null);
        this.advancementsTab = SerializationUtil.getAsResourceLocation(root, "advancements_tab", null);
        this.noBook = class_3518.method_15258(root, "dont_generate_book", false);
        this.showToasts = class_3518.method_15258(root, "show_toasts", true);
        this.pauseGame = class_3518.method_15258(root, "pause_game", false);
        this.isPamphlet = class_3518.method_15258(root, "pamphlet", false);
        this.i18n = class_3518.method_15258(root, "i18n", false);
        this.overflowMode = SerializationUtil.getAsEnum(root, "text_overflow_mode", HandbookConfig.TextOverflowMode.class, null);

        String customBookItem = class_3518.method_15253(root, "custom_book_item", "");

        if (noBook) {
            // Need lazy parsing for mods that load after Handbook, as parser looks up item and components
            // in registries; wrap in try-catch in case of faulty item definition
            bookItem = Suppliers.memoize(() -> {
                try {
                    return ItemStackUtil.loadFromParsed(
                            ItemStackUtil.deserializeStack(customBookItem, class_7887.method_46817()));
                }
                catch (Exception e) {
                    HandbookAPI.LOGGER.warn("Failed to parse item \"{}\" for book {} defined by mod {}, skipping",
                        customBookItem, id, owner.getId(), e);

                    return class_1799.field_8037;
                }
            });
        }
        else {
            bookItem = Suppliers.memoize(() -> HandbookBook.forBook(id));
        }

        macros.putAll(DEFAULT_MACROS);

        for (Map.Entry<String, JsonElement> e : class_3518.method_15281(root, "macros", new JsonObject()).entrySet()) {
            macros.put(e.getKey(), class_3518.method_15287(e.getValue(), "macro value"));
        }
    }

    public class_1799 getBookItem() {
        return this.bookItem.get();
    }

    public void markUpdated() {
        wasUpdated = true;
    }

    public boolean popUpdated() {
        boolean updated = wasUpdated;
        wasUpdated = false;
        return updated;
    }

    /**
     * Must only be called on client
     * 
     * @param singleBook Hint that the book was reloaded through the button on the main page
     */
    public void reloadContents(class_1937 level, boolean singleBook) {
        try {
            contents = BookContentsBuilder.loadAndBuildFor(level, this, singleBook);
        }
        catch (Exception e) {
            HandbookAPI.LOGGER.error("Error loading and compiling book {}, using empty contents", id, e);
            contents = BookContents.empty(this, e);
        }
    }

    public final boolean advancementsEnabled() {
        return !HandbookConfig.Client.disableAdvancementLocking()
                && !HandbookConfig.Client.noAdvancementBooks().contains(id.toString());
    }

    public void reloadLocks(boolean suppressToasts) {
        getContents().entries.values().forEach(BookEntry::updateLockStatus);
        getContents().categories.values().forEach(c -> c.updateLockStatus(true));

        boolean updated = popUpdated();

        if (updated && !suppressToasts && advancementsEnabled() && showToasts) {
            ClientAdvancements.sendBookToast(this);
        }
    }

    public String getOwnerName() {
        return owner.getName();
    }

    public class_2583 getFontStyle() {
        if (useBlockyFont) {
            return class_2583.field_24360;
        } else {
            return class_2583.field_24360.method_27704(class_310.field_24211);
        }
    }

    public class_5250 getSubtitle() {
        class_2561 editionStr;

        try {
            int ver = Integer.parseInt(version);
            if (ver == 0) {
                return class_2561.method_43471(subtitle);
            }

            editionStr = class_2561.method_43470(numberToOrdinal(ver));
        }
        catch (NumberFormatException e) {
            editionStr = class_2561.method_43471("handbook.gui.lexicon.dev_edition");
        }

        return class_2561.method_43469("handbook.gui.lexicon.edition_str", editionStr);
    }

    public BookIcon getIcon() {
        if (indexIconRaw == null || indexIconRaw.isEmpty()) {
            return new BookIcon.StackIcon(getBookItem());
        } else {
            return BookIcon.from(indexIconRaw);
        }
    }

    private static String numberToOrdinal(int i) {
        return i % 100 == 11 || i % 100 == 12 || i % 100 == 13 ? i + "th" : i + ORDINAL_SUFFIXES[i % 10];
    }

    public BookContents getContents() {
        return contents != null ? contents : BookContents.empty(this, null);
    }

    public enum BookLayoutTexture {
        BLUE,
        BROWN,
        CYAN,
        GRAY,
        GREEN,
        PURPLE,
        RED,
        DEFAULT;

        @Override
        public String toString() {
            return switch (this) {
                case BLUE -> "book_blue";
                case BROWN -> "book_brown";
                case CYAN -> "book_cyan";
                case GRAY -> "book_gray";
                case GREEN -> "book_green";
                case PURPLE -> "book_purple";
                case RED -> "book_red";
                case DEFAULT -> "book_brown";
            };
        }

        public class_2960 texture() {
            return HandbookAPI.prefix("textures/gui/" + this + ".png");
        }
    }

}
