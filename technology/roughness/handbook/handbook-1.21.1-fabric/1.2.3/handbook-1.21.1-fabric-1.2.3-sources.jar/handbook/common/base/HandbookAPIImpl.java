package handbook.common.base;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_437;
import org.jetbrains.annotations.NotNull;

import com.google.common.base.Preconditions;
import org.apache.commons.io.IOUtils;

import handbook.api.HandbookAPI.IHandbookAPI;
import handbook.api.IStyleStack;
import handbook.client.book.BookContents;
import handbook.client.book.ClientBookRegistry;
import handbook.client.book.gui.GuiBook;
import handbook.client.book.template.BookTemplate;
import handbook.client.book.text.BookTextParser;
import handbook.common.advancement.BookOpenTrigger;
import handbook.common.book.Book;
import handbook.common.book.BookRegistry;
import handbook.common.item.HandbookBook;
import handbook.config.HandbookConfig;
import handbook.platform.Services;

import static technology.roughness.whitenoise.platform.Services.PLATFORM;

public class HandbookAPIImpl implements IHandbookAPI {

    private static void assertPhysicalClient() {
        Preconditions.checkState(
            PLATFORM.isPhysicalClient(),
            "Not on the physical client"
        );
    }

    @Override
    public void setConfigFlag(String flag, boolean value) {
        HandbookConfig.setFlag(flag, value);
    }

    @Override
    public boolean getConfigFlag(String flag) {
        return HandbookConfig.getConfigFlag(flag);
    }

    @Override
    public void openBookGUI(class_3222 player, class_2960 book) {
        BookOpenTrigger.INSTANCE.trigger(player, book);
        Services.BOOK_HELPER.sendOpenBookGui(player, book, null, 0);
    }

    @Override
    public void openBookEntry(class_3222 player, class_2960 book, class_2960 entry, int page) {
        BookOpenTrigger.INSTANCE.trigger(player, book, entry, page);
        Services.BOOK_HELPER.sendOpenBookGui(player, book, entry, page);
    }

    @Override
    public void openBookGUI(class_2960 book) {
        assertPhysicalClient();
        ClientBookRegistry.INSTANCE.displayBookGui(book, null, 0);
    }

    @Override
    public void openBookEntry(class_2960 book, class_2960 entry, int page) {
        assertPhysicalClient();
        ClientBookRegistry.INSTANCE.displayBookGui(book, entry, page);
    }

    @Override
    public class_2960 getOpenBookGui() {
        assertPhysicalClient();
        class_437 gui = class_310.method_1551().field_1755;
        if (gui instanceof GuiBook) {
            return ((GuiBook) gui).book.id;
        }
        return null;
    }

    @NotNull
    @Override
    public class_2561 getSubtitle(@NotNull class_2960 bookId) {
        Book book = BookRegistry.INSTANCE.books.get(bookId);
        if (book == null) {
            throw new IllegalArgumentException("Book not found: " + bookId);
        }
        return book.getSubtitle();
    }

    @Override
    public void registerCommand(String name, Function<IStyleStack, String> command) {
        assertPhysicalClient();
        BookTextParser.register(command::apply, name);
    }

    @Override
    public void registerFunction(String name, BiFunction<String, IStyleStack, String> function) {
        assertPhysicalClient();
        BookTextParser.register(function::apply, name);
    }

    @Override
    public class_1799 getBookStack(class_2960 book) {
        return HandbookBook.forBook(book);
    }

    @Override
    public void registerTemplateAsBuiltin(class_2960 res, Supplier<InputStream> streamProvider) {
        assertPhysicalClient();
        InputStream testStream = streamProvider.get();
        if (testStream == null) {
            throw new NullPointerException("Stream provider can't return a null stream");
        }
        IOUtils.closeQuietly(testStream);

        Supplier<BookTemplate> prev = BookContents.addonTemplates.put(res, () -> {
            InputStream stream = streamProvider.get();
            InputStreamReader reader = new InputStreamReader(stream);

            return ClientBookRegistry.INSTANCE.gson.fromJson(reader, BookTemplate.class);
        });

        if (prev != null) {
            throw new IllegalArgumentException("Template " + res + " is already registered");
        }
    }

}
