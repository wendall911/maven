package handbook.client.handler;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.datafixers.util.Pair;
import org.lwjgl.opengl.GL11;

import handbook.client.base.ClientTicker;
import handbook.client.book.BookEntry;
import handbook.client.book.ClientBookRegistry;
import handbook.client.book.gui.GuiBook;
import handbook.common.book.Book;
import handbook.common.util.ColorHelper;
import handbook.common.util.ColorHelper.HandbookColors;
import handbook.common.util.ItemStackUtil;
import handbook.config.HandbookConfig;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class TooltipHandler {

    private static float lexiconLookupTime = 0;

    public static void onTooltip(class_332 graphics, class_1799 stack, int mouseX, int mouseY) {
        class_310 mc = class_310.method_1551();
        int tooltipX = mouseX;
        int tooltipY = mouseY - 4;

        if (mc.field_1724 != null && !(mc.field_1755 instanceof GuiBook)) {
            int lexSlot = -1;
            class_1799 lexiconStack = class_1799.field_8037;
            Pair<BookEntry, Integer> lexiconEntry = null;

            for (int i = 0; i < class_1661.method_7368(); i++) {
                class_1799 stackAt = mc.field_1724.method_31548().method_5438(i);
                if (!stackAt.method_7960()) {
                    Book book = ItemStackUtil.getBookFromStack(stackAt);

                    if (book != null) {
                        Pair<BookEntry, Integer> entry = book.getContents().getEntryForStack(stack);

                        if (entry != null && !entry.getFirst().isLocked()) {
                            lexiconStack = stackAt;
                            lexSlot = i;
                            lexiconEntry = entry;
                            break;
                        }
                    }
                }
            }

            if (lexSlot > -1) {
                int x = tooltipX - 34;

                RenderSystem.disableDepthTest();

                graphics.method_25294(x - 4, tooltipY - 4, x + 20, tooltipY + 26, ColorHelper.fillBlack(0.17F));
                graphics.method_25294(x - 6, tooltipY - 6, x + 22, tooltipY + 28, ColorHelper.fillBlack(0.17F));

                if (HandbookConfig.Client.useShiftForQuickLookup() ? class_437.method_25442() : class_437.method_25441()) {
                    lexiconLookupTime += ClientTicker.delta;

                    int cx = x + 8;
                    int cy = tooltipY + 8;
                    float r = 12;
                    float requiredTime = HandbookConfig.Client.quickLookupTime();
                    float angles = lexiconLookupTime / requiredTime * 360F;

                    RenderSystem.enableBlend();
                    RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

                    class_287 buf = class_289.method_1348().method_60827(class_5596.field_27381, class_290.field_1576);

                    float a = 0.5F + 0.2F * ((float) Math.cos(ClientTicker.total / 10) * 0.5F + 0.5F);
                    buf.method_22912(cx, cy, 0).method_22915(0F, 0.5F, 0F, a);

                    for (float i = angles; i > 0; i--) {
                        double rad = (i - 90) / 180F * Math.PI;
                        buf.method_22912((float) (cx + Math.cos(rad) * r), (float) (cy + Math.sin(rad) * r), 0).method_22915(0F, 1F, 0F, 1F);
                    }

                    buf.method_22912(cx, cy, 0).method_22915(0F, 1F, 0F, 0F);
                    class_286.method_43433(buf.method_60800());

                    RenderSystem.disableBlend();

                    if (lexiconLookupTime >= requiredTime) {
                        int spread = lexiconEntry.getSecond();

                        mc.field_1724.method_31548().field_7545 = lexSlot;

                        ClientBookRegistry.INSTANCE.displayBookGui(lexiconEntry.getFirst().getBook().id, lexiconEntry.getFirst().getId(), spread * 2);
                    }
                }
                else {
                    lexiconLookupTime = 0F;
                }

                graphics.method_51448().method_22903();
                graphics.method_51448().method_46416(0, 0, 300);
                graphics.method_51427(lexiconStack, x, tooltipY);
                graphics.method_51431(mc.field_1772, lexiconStack, x, tooltipY);
                graphics.method_51448().method_22909();

                graphics.method_51448().method_22903();
                graphics.method_51448().method_46416(0, 0, 500);
                graphics.method_51433(mc.field_1772, "?", x + 10, tooltipY + 8, HandbookColors.WHITE.toColor(), true);

                graphics.method_51448().method_22905(0.5F, 0.5F, 1F);

                boolean mac = class_310.field_1703;
                class_2561 key = class_2561.method_43470(HandbookConfig.Client.useShiftForQuickLookup() ? "Shift" : mac ? "Cmd" : "Ctrl")
                    .method_27692(class_124.field_1067);

                graphics.method_51439(mc.field_1772, key, (x + 10) * 2 - 16, (tooltipY + 8) * 2 + 20, HandbookColors.WHITE.toColor(), true);
                graphics.method_51448().method_22909();

                RenderSystem.enableDepthTest();
            }
            else {
                lexiconLookupTime = 0F;
            }
        }
        else {
            lexiconLookupTime = 0F;
        }
    }

}
