package handbook.client.book.gui.button;

import handbook.client.book.gui.GuiBook;
import net.minecraft.class_2561;

public class GuiButtonBookArrow extends GuiButtonBook {

	public final boolean left;

	public GuiButtonBookArrow(GuiBook parent, int x, int y, boolean left) {
		super(parent, x, y, 272, left ? 10 : 0, 18, 10, () -> parent.canSeePageButton(left), parent::handleButtonArrow,
				class_2561.method_43471(left ? "handbook.gui.lexicon.button.prev_page" : "handbook.gui.lexicon.button.next_page"));
		this.left = left;
	}

}
