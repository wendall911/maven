package handbook.client.book.template.variable;

import com.google.gson.JsonElement;
import com.mojang.serialization.JsonOps;
import handbook.api.IVariableSerializer;
import handbook.common.util.ItemStackUtil;
import net.minecraft.class_1856;
import net.minecraft.class_7225;

public class IngredientVariableSerializer implements IVariableSerializer<class_1856> {

	@Override
	public class_1856 fromJson(JsonElement json, class_7225.class_7874 registries) {
		return (json.isJsonPrimitive()) ? ItemStackUtil.loadIngredientFromString(json.getAsString(), registries) : class_1856.field_46095.parse(registries.method_57093(JsonOps.INSTANCE), json).result().orElseThrow();
	}

	@Override
	public JsonElement toJson(class_1856 stack, class_7225.class_7874 registries) {
		return class_1856.field_46095.encodeStart(registries.method_57093(JsonOps.INSTANCE), stack).result().orElseThrow();
	}

}
