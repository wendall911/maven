package handbook.client.book;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import org.jetbrains.annotations.Nullable;

import com.google.gson.JsonElement;
import handbook.common.book.Book;
import handbook.common.book.BookRegistry;

public interface BookContentLoader {

    void findFiles(Book book, String dir, List<class_2960> list);

    @Nullable
    LoadResult loadJson(Book book, class_2960 file);

    /**
     * @param addedBy Opaque string to be shown to user in the book,
     *                indicates that the thing in question was added by a "foreign" entity such
     *                as a resource pack addon. Null if no message should be shown.
     */
    record LoadResult(JsonElement json, @Nullable String addedBy) {
    }

    static JsonElement streamToJson(InputStream stream) throws IOException {
        try (Reader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            return class_3518.method_15276(BookRegistry.GSON, reader, JsonElement.class);
        }
    }

}
