package handbook.client.gui;

import handbook.client.base.ClientAdvancements;
import net.minecraft.class_2960;
import net.minecraft.class_437;
import net.minecraft.class_457;
import net.minecraft.class_8779;

public class GuiAdvancementsExt extends class_457 {

    class_437 parent;

    public GuiAdvancementsExt(net.minecraft.class_632 manager, class_437 parent, class_2960 tab) {
        super(manager);
        this.parent = parent;

        class_8779 start = manager.method_53815(tab);

        if (start != null && ClientAdvancements.hasDone(start.comp_1919().toString())) {
            manager.method_2864(start, false);
        }
    }

    @Override
    public boolean method_25404(int key, int scanCode, int modifiers) {
        if (field_22787 != null && (field_22787.field_1690.field_1844.method_1417(key, scanCode) || scanCode == 1)) {
            field_22787.method_1507(parent);

            return true;
        }
        else {
            return super.method_25404(key, scanCode, modifiers);
        }
    }

}
