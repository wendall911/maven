package handbook.client.book.page;

import handbook.client.base.ClientAdvancements;
import handbook.client.base.PersistentData;
import handbook.client.base.PersistentData.BookData;
import handbook.client.book.BookContentsBuilder;
import handbook.client.book.BookEntry;
import handbook.client.book.gui.GuiBook;
import handbook.client.book.gui.GuiBookEntry;
import handbook.client.book.page.abstr.PageWithText;
import handbook.common.book.Book;
import handbook.common.util.ColorHelper.HandbookColors;
import net.minecraft.class_1074;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;

public class PageQuest extends PageWithText {

    class_2960 trigger;
    String title;

    transient boolean isManual;

    @Override
    public int getTextHeight() {
        return 22;
    }

    @Override
    public void build(class_1937 level, BookEntry entry, BookContentsBuilder builder, int pageNum) {
        super.build(level, entry, builder, pageNum);

        isManual = trigger == null;
    }

    public boolean isCompleted(Book book) {
        return isManual
                ? PersistentData.data.getBookData(book).completedManualQuests.contains(entry.getId())
                : trigger != null && ClientAdvancements.hasDone(trigger.toString());
    }

    @Override
    public void onDisplayed(GuiBookEntry parent, int left, int top) {
        super.onDisplayed(parent, left, top);

        if (isManual) {
            class_4185 button = class_4185.method_46430(class_2561.method_43473(), this::questButtonClicked).method_46433(GuiBook.PAGE_WIDTH / 2 - 50, GuiBook.PAGE_HEIGHT - 35).method_46437(100, 20).method_46431();
            addButton(button);
            updateButtonText(button);
        }
    }

    private void updateButtonText(class_4185 button) {
        boolean completed = isCompleted(parent.book);
        class_2561 s = class_2561.method_43471(completed ? "handbook.gui.lexicon.mark_incomplete" : "handbook.gui.lexicon.mark_complete");
        button.method_25355(s);
    }

    protected void questButtonClicked(class_4185 button) {
        class_2960 entryId = entry.getId();
        BookData data = PersistentData.data.getBookData(parent.book);

        if (data.completedManualQuests.contains(entryId)) {
            data.completedManualQuests.remove(entryId);
        }
        else {
            data.completedManualQuests.add(entryId);
        }
        PersistentData.save();

        updateButtonText(button);
        entry.markReadStateDirty();
    }

    @Override
    public void render(class_332 graphics, int mouseX, int mouseY, float pticks) {
        super.render(graphics, mouseX, mouseY, pticks);

        parent.drawCenteredStringNoShadow(graphics, title == null || title.isEmpty() ? class_1074.method_4662("handbook.gui.lexicon.objective") : i18n(title), GuiBook.PAGE_WIDTH / 2, 0, book.headerColor);
        GuiBook.drawSeparator(graphics, book, 0, 12);

        if (!isManual) {
            GuiBook.drawSeparator(graphics, book, 0, GuiBook.PAGE_HEIGHT - 25);

            boolean completed = isCompleted(parent.book);
            String s = class_1074.method_4662(completed ? "handbook.gui.lexicon.complete" : "handbook.gui.lexicon.incomplete");
            int color = completed ? HandbookColors.COMPLETE.toColor() : book.headerColor;

            parent.drawCenteredStringNoShadow(graphics, s, GuiBook.PAGE_WIDTH / 2, GuiBook.PAGE_HEIGHT - 17, color);
        }

    }

}
