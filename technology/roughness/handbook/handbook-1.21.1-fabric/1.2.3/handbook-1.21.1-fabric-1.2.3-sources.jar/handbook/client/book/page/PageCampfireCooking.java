package handbook.client.book.page;

import handbook.client.book.page.abstr.PageSimpleProcessingRecipe;
import net.minecraft.class_3920;
import net.minecraft.class_3956;

public class PageCampfireCooking extends PageSimpleProcessingRecipe<class_3920> {

    public PageCampfireCooking() {
        super(class_3956.field_17549);
    }

}
