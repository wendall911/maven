package handbook.client.book.page;

import com.google.gson.annotations.SerializedName;
import com.mojang.blaze3d.systems.RenderSystem;
import handbook.api.IVariable;
import handbook.client.book.BookContentsBuilder;
import handbook.client.book.BookEntry;
import handbook.client.book.gui.GuiBook;
import handbook.client.book.page.abstr.PageWithText;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_332;

public class PageSpotlight extends PageWithText {

    IVariable item;
    String title;
    @SerializedName("link_recipe") boolean linkRecipe;

    transient class_1799[] stacks;

    @Override
    public void build(class_1937 level, BookEntry entry, BookContentsBuilder builder, int pageNum) {
        super.build(level, entry, builder, pageNum);
        stacks = item.as(class_1799[].class);

        if (linkRecipe) {
            for (class_1799 stack : stacks) {
                entry.addRelevantStack(builder, stack, pageNum);
            }
        }
    }

    @Override
    public void render(class_332 graphics, int mouseX, int mouseY, float pticks) {
        int w = 66;
        int h = 26;

        RenderSystem.enableBlend();
        graphics.method_25290(book.craftingTexture, GuiBook.PAGE_WIDTH / 2 - w / 2, 10, 0, 128 - h, w, h, 128, 256);

        class_2561 toDraw;
        if (title != null && !title.isEmpty()) {
            toDraw = i18nText(title);
        } else {
            toDraw = stacks[0].method_7964();
        }

        parent.drawCenteredStringNoShadow(graphics, toDraw.method_30937(), GuiBook.PAGE_WIDTH / 2, 0, book.headerColor);
        if (stacks.length > 0) {
            parent.renderItemStack(graphics, GuiBook.PAGE_WIDTH / 2 - 8, 15, mouseX, mouseY, stacks[(parent.ticksInBook / 20) % stacks.length]);
        }

        super.render(graphics, mouseX, mouseY, pticks);
    }

    @Override
    public int getTextHeight() {
        return 40;
    }

}
