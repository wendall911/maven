package handbook.client.book.template.component;

import java.util.function.UnaryOperator;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_7225;
import com.google.gson.annotations.SerializedName;
import com.mojang.blaze3d.systems.RenderSystem;
import handbook.api.IVariable;
import handbook.client.book.BookContentsBuilder;
import handbook.client.book.BookEntry;
import handbook.client.book.BookPage;
import handbook.client.book.template.TemplateComponent;

public class ComponentItemStack extends TemplateComponent {

    public IVariable item;

    private boolean framed;
    @SerializedName("link_recipe") private boolean linkedRecipe;

    private transient class_1799[] items;

    @Override
    public void build(BookContentsBuilder builder, BookPage page, BookEntry entry, int pageNum) {
        if (linkedRecipe) {
            for (class_1799 stack : items) {
                entry.addRelevantStack(builder, stack, pageNum);
            }
        }
    }

    @Override
    public void onVariablesAvailable(UnaryOperator<IVariable> lookup, class_7225.class_7874 registries) {
        super.onVariablesAvailable(lookup, registries);
        items = lookup.apply(item).as(class_1799[].class);
    }

    @Override
    public void render(class_332 graphics, BookPage page, int mouseX, int mouseY, float pticks) {
        if (items.length == 0) {
            return;
        }

        if (framed) {
            RenderSystem.enableBlend();
            graphics.method_51422(1F, 1F, 1F, 1F);
            graphics.method_25290(page.book.craftingTexture, x - 5, y - 5, 20, 102, 26, 26, 128, 256);
        }

        page.parent.renderItemStack(graphics, x, y, mouseX, mouseY, items[(page.parent.ticksInBook / 20) % items.length]);
    }

}
