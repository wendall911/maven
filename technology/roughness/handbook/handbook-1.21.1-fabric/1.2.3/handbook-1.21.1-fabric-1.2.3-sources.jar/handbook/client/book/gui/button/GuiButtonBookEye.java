package handbook.client.book.gui.button;

import handbook.client.base.ClientTicker;
import handbook.client.base.PersistentData;
import handbook.client.book.gui.GuiBook;
import handbook.common.util.ColorHelper.HandbookColors;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;

public class GuiButtonBookEye extends GuiButtonBook {

	public GuiButtonBookEye(GuiBook parent, int x, int y, class_4185.class_4241 onPress) {
		super(parent, x, y, 308, 31, 11, 11, onPress,
				class_2561.method_43471("handbook.gui.lexicon.button.visualize"),
				class_2561.method_43471("handbook.gui.lexicon.button.visualize.info").method_27692(class_124.field_1080));
	}

	@Override
	public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		super.method_48579(graphics, mouseX, mouseY, partialTicks);

		if (!PersistentData.data.clickedVisualize && (ClientTicker.ticksInGame) % 20 < 10) {
            class_310 mc = parent.getMinecraft();

            if (mc != null) {
                graphics.method_51433(mc.field_1772, "!", method_46426(), method_46427(), HandbookColors.BOOK_EYE.toColor(), true);
            }
		}
	}

}
