package handbook.client.book.page;

import java.util.function.Function;
import net.minecraft.class_1074;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_898;
import com.google.gson.annotations.SerializedName;

import com.mojang.blaze3d.systems.RenderSystem;
import handbook.api.HandbookAPI;
import handbook.client.base.ClientTicker;
import handbook.client.book.BookContentsBuilder;
import handbook.client.book.BookEntry;
import handbook.client.book.gui.GuiBook;
import handbook.client.book.gui.GuiBookEntry;
import handbook.client.book.page.abstr.PageWithText;
import handbook.common.util.ColorHelper.HandbookColors;
import handbook.common.util.EntityUtil;

public class PageEntity extends PageWithText {

    @SerializedName("entity") public String entityId;

    float scale = 1F;
    @SerializedName("offset") float extraOffset = 0F;
    String name;

    boolean rotate = true;
    @SerializedName("default_rotation") float defaultRotation = -45f;

    transient boolean errored;
    transient class_1297 entity;
    transient Function<class_1937, class_1297> creator;
    transient float renderScale, offset;

    @Override
    public void build(class_1937 level, BookEntry entry, BookContentsBuilder builder, int pageNum) {
        super.build(level, entry, builder, pageNum);

        creator = EntityUtil.loadEntity(entityId);
    }

    @Override
    public void onDisplayed(GuiBookEntry parent, int left, int top) {
        super.onDisplayed(parent, left, top);
        class_310 mc = parent.getMinecraft();

        if (mc != null) {
            loadEntity(mc.field_1687);
        }
    }

    @Override
    public int getTextHeight() {
        return 115;
    }

    @Override
    public void render(class_332 graphics, int mouseX, int mouseY, float pticks) {
        int x = GuiBook.PAGE_WIDTH / 2 - 53;
        int y = 7;
        RenderSystem.enableBlend();
        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
        GuiBook.drawFromTexture(graphics, book, x, y, 405, 149, 106, 106);

        if (name == null || name.isEmpty()) {
            if (entity != null) {
                parent.drawCenteredStringNoShadow(graphics, entity.method_5477().method_30937(), GuiBook.PAGE_WIDTH / 2, 0, book.headerColor);
            }
        } else {
            parent.drawCenteredStringNoShadow(graphics, name, GuiBook.PAGE_WIDTH / 2, 0, book.headerColor);
        }

        if (errored) {
            graphics.method_51433(fontRenderer, class_1074.method_4662("handbook.gui.lexicon.loading_error"), 58, 60, HandbookColors.ERROR_RED.toColor(), true);
        }

        if (entity != null) {
            float rotation = rotate ? ClientTicker.total : defaultRotation;
            renderEntity(graphics, entity, 58, 60, rotation, renderScale, offset);
        }

        super.render(graphics, mouseX, mouseY, pticks);
    }

    public static void renderEntity(class_332 graphics, class_1297 entity, float x, float y, float rotation, float renderScale, float offset) {
        class_4587 ms = graphics.method_51448();
        ms.method_22903();
        ms.method_46416(x, y, 50);
        ms.method_22905(renderScale, renderScale, renderScale);
        ms.method_46416(0, offset, 0);
        ms.method_22907(class_7833.field_40718.rotationDegrees(180));
        ms.method_22907(class_7833.field_40716.rotationDegrees(rotation));
        class_898 erd = class_310.method_1551().method_1561();
        class_4597.class_4598 immediate = class_310.method_1551().method_22940().method_23000();
        erd.method_3948(false);
        erd.method_3954(entity, 0, 0, 0, 0, 1, ms, immediate, 0xF000F0);
        erd.method_3948(true);
        immediate.method_22993();
        ms.method_22909();
    }

    private void loadEntity(class_1937 world) {
        if (!errored && (entity == null || !entity.method_5805() || entity.method_37908() != world)) {
            try {
                entity = creator.apply(world);

                float width = entity.method_17681();
                float height = entity.method_17682();

                float entitySize = Math.max(1F, Math.max(width, height));

                renderScale = 100F / entitySize * 0.8F * scale;
                offset = Math.max(height, entitySize) * 0.5F + extraOffset;
            } catch (Exception e) {
                errored = true;
                HandbookAPI.LOGGER.error("Failed to load entity", e);
            }
        }
    }

}
