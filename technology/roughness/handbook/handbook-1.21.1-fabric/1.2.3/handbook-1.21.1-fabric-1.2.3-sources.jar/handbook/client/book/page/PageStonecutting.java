package handbook.client.book.page;

import handbook.client.book.page.abstr.PageSimpleProcessingRecipe;
import net.minecraft.class_3956;
import net.minecraft.class_3975;

public class PageStonecutting extends PageSimpleProcessingRecipe<class_3975> {

    public PageStonecutting() {
        super(class_3956.field_17641);
    }

}
