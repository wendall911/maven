package handbook.client.book.template.component;

import java.util.function.UnaryOperator;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_7225;
import com.google.gson.annotations.SerializedName;
import com.mojang.blaze3d.systems.RenderSystem;
import handbook.api.IVariable;
import handbook.client.book.BookContentsBuilder;
import handbook.client.book.BookEntry;
import handbook.client.book.BookPage;
import handbook.client.book.template.TemplateComponent;

public class ComponentImage extends TemplateComponent {

    public String image;

    public int u, v, width, height;

    @SerializedName("texture_width") public int textureWidth = 256;
    @SerializedName("texture_height") public int textureHeight = 256;

    public float scale = 1F;

    transient class_2960 resource;

    @Override
    public void build(BookContentsBuilder builder, BookPage page, BookEntry entry, int pageNum) {
        resource = class_2960.method_12829(image);
    }

    @Override
    public void onVariablesAvailable(UnaryOperator<IVariable> lookup, class_7225.class_7874 registries) {
        super.onVariablesAvailable(lookup, registries);
        image = lookup.apply(IVariable.wrap(image, registries)).asString();
    }

    @Override
    public void render(class_332 graphics, BookPage page, int mouseX, int mouseY, float pticks) {
        if (scale == 0F) {
            return;
        }

        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(x, y, 0);
        graphics.method_51448().method_22905(scale, scale, scale);
        graphics.method_51422(1F, 1F, 1F, 1F);
        RenderSystem.enableBlend();
        graphics.method_25290(resource, 0, 0, u, v, width, height, textureWidth, textureHeight);
        graphics.method_51448().method_22909();
    }

}
