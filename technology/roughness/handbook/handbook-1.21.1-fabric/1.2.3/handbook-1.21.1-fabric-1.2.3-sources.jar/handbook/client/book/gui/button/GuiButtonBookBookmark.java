package handbook.client.book.gui.button;

import com.mojang.blaze3d.systems.RenderSystem;
import handbook.client.base.PersistentData.Bookmark;
import handbook.client.book.BookEntry;
import handbook.client.book.gui.GuiBook;
import handbook.common.book.Book;
import handbook.common.util.ColorHelper.HandbookColors;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;

public class GuiButtonBookBookmark extends GuiButtonBook {

	private final Book book;

	public final Bookmark bookmark;

	public GuiButtonBookBookmark(GuiBook parent, int x, int y, Bookmark bookmark) {
		super(parent, x, y, 272, bookmark == null ? 170 : 160, 13, 10, parent::handleButtonBookmark, getTooltip(parent.book, bookmark));
		this.book = parent.book;
		this.bookmark = bookmark;
	}

	@Override
	public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		super.method_48579(graphics, mouseX, mouseY, partialTicks);

		BookEntry entry = bookmark == null ? null : bookmark.getEntry(book);
		if (bookmark != null && entry != null) {
			int px = method_46426() * 2 + (method_25367() ? 6 : 2);
			int py = method_46427() * 2 + 2;

			graphics.method_51448().method_22903();
			graphics.method_51448().method_22905(0.5F, 0.5F, 0.5F);
			entry.getIcon().render(graphics, px, py);
			graphics.method_51448().method_22909();
		}
	}

	private static class_2561[] getTooltip(Book book, Bookmark bookmark) {
		BookEntry entry = bookmark == null ? null : bookmark.getEntry(book);

		if (bookmark == null || entry == null) {
			return new class_2561[] {
                class_2561.method_43471("handbook.gui.lexicon.add_bookmark")
            };
		}

		return new class_2561[] {
            entry.getName(),
            class_2561.method_43471("handbook.gui.lexicon.remove_bookmark").method_27692(class_124.field_1080)
		};
	}

}
