package handbook.client.book.template.variable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_7225;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import handbook.common.util.ItemStackUtil;

public class ItemStackArrayVariableSerializer extends GenericArrayVariableSerializer<class_1799> {

	public ItemStackArrayVariableSerializer() {
		super(new ItemStackVariableSerializer(), class_1799.class);
	}

	@Override
	public class_1799[] fromJson(JsonElement json, class_7225.class_7874 registries) {
		if (json.isJsonArray()) {
			JsonArray array = json.getAsJsonArray();
			List<class_1799> stacks = new ArrayList<>();
			for (JsonElement e : array) {
				stacks.addAll(Arrays.asList(fromNonArray(e, registries)));
			}
			return stacks.toArray(empty);
		}
		return fromNonArray(json, registries);
	}

	public class_1799[] fromNonArray(JsonElement json, class_7225.class_7874 registries) {
		if (json.isJsonNull()) {
			return empty;
		}
		if (json.isJsonPrimitive()) {
			return ItemStackUtil.loadStackListFromString(json.getAsString(), registries).toArray(empty);
		}
		if (json.isJsonObject()) {
			return new class_1799[] { ItemStackUtil.loadStackFromJson(json.getAsJsonObject(), registries) };
		}
		throw new IllegalArgumentException("Can't make an ItemStack from an array!");
	}

}
