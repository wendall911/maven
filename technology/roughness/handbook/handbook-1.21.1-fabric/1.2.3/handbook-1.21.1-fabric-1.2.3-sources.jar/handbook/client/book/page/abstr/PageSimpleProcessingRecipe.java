package handbook.client.book.page.abstr;

import com.mojang.blaze3d.systems.RenderSystem;
import handbook.client.book.gui.GuiBook;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3956;

public abstract class PageSimpleProcessingRecipe<T extends class_1860<?>> extends PageDoubleRecipeRegistry<T> {

    public PageSimpleProcessingRecipe(class_3956<T> recipeType) {
        super(recipeType);
    }

    @Override
    protected void drawRecipe(class_332 graphics, T recipe, int recipeX, int recipeY, int mouseX, int mouseY, boolean second) {
        class_1937 level = class_310.method_1551().field_1687;
        if (level == null) {
            return;
        }

        RenderSystem.enableBlend();
        graphics.method_25290(book.craftingTexture, recipeX, recipeY, 11, 71, 96, 24, 128, 256);
        parent.drawCenteredStringNoShadow(graphics, getTitle(second).method_30937(), GuiBook.PAGE_WIDTH / 2, recipeY - 10, book.headerColor);

        parent.renderIngredient(graphics, recipeX + 4, recipeY + 4, mouseX, mouseY, recipe.method_8117().get(0));
        parent.renderItemStack(graphics, recipeX + 40, recipeY + 4, mouseX, mouseY, recipe.method_17447());
        parent.renderItemStack(graphics, recipeX + 76, recipeY + 4, mouseX, mouseY, recipe.method_8110(level.method_30349()));
    }

    @Override
    protected class_1799 getRecipeOutput(class_1937 level, T recipe) {
        if (recipe == null || level == null) {
            return class_1799.field_8037;
        }

        return recipe.method_8110(level.method_30349());
    }

    @Override
    protected int getRecipeHeight() {
        return 45;
    }

}
