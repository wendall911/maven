package handbook.client.book.page;

import handbook.client.book.page.abstr.PageSimpleProcessingRecipe;
import net.minecraft.class_3861;
import net.minecraft.class_3956;

public class PageSmelting extends PageSimpleProcessingRecipe<class_3861> {

    public PageSmelting() {
        super(class_3956.field_17546);
    }

}
