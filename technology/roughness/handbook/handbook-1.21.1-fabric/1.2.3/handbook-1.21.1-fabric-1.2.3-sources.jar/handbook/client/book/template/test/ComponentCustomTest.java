package handbook.client.book.template.test;

import java.util.function.UnaryOperator;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7225;
import handbook.api.IComponentRenderContext;
import handbook.api.ICustomComponent;
import handbook.api.IVariable;
import handbook.api.HandbookAPI;

public class ComponentCustomTest implements ICustomComponent {
    private transient int x, y;
    private transient String text = "";

    @Override
    public void build(int componentX, int componentY, int pageNum) {
        x = componentX;
        y = componentY;
        HandbookAPI.LOGGER.debug("Custom Component Test built at ({}, {}) page {}", componentX, componentY, pageNum);
    }

    @Override
    public void render(class_332 graphics, IComponentRenderContext context, float pticks, int mouseX, int mouseY) {
        class_2561 toRender = class_2561.method_43470(text).method_10862(context.getFont());

        graphics.method_51439(class_310.method_1551().field_1772, toRender, x, y, -1, true);
    }

    @Override
    public boolean mouseClicked(IComponentRenderContext context, double mouseX, double mouseY, int mouseButton) {
        HandbookAPI.LOGGER.debug("Custom Component Test clicked at ({}, {}) button {}", mouseX, mouseY, mouseButton);

        return false;
    }

    @Override
    public void onVariablesAvailable(UnaryOperator<IVariable> lookup, class_7225.class_7874 registries) {
        text = lookup.apply(IVariable.wrap("First we eat #spaghet#, then we drink #pop#", registries)).asString();
    }

}
