package handbook.client.book.template.test;

import technology.roughness.whitenoise.util.ResourceLocationHelper;

import handbook.api.IComponentProcessor;
import handbook.api.IVariable;
import handbook.api.IVariableProvider;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_1937;

public class RecipeTestProcessor implements IComponentProcessor {

    private class_1860<?> recipe;

    @Override
    public void setup(class_1937 level, IVariableProvider variables) {
        // TODO probably add a recipe serializer?
        String recipeId = variables.get("recipe", level.method_30349()).asString();
        class_1863 manager = level.method_8433();

        recipe = manager.method_8130(ResourceLocationHelper.tryParse(recipeId)).orElseThrow(IllegalArgumentException::new).comp_1933();
    }

    @Override
    public IVariable process(class_1937 level, String key) {
        if (key.startsWith("item")) {
            int index = Integer.parseInt(key.substring(4)) - 1;
            class_1856 ingredient = recipe.method_8117().get(index);
            class_1799[] stacks = ingredient.method_8105();
            class_1799 stack = stacks.length == 0 ? class_1799.field_8037 : stacks[0];

            return IVariable.from(stack, level.method_30349());
        }
        else if (key.equals("text")) {
            class_1799 out = recipe.method_8110(level.method_30349());
            return IVariable.wrap(out.method_7947() + "x$(br)" + out.method_7964(), level.method_30349());
        }
        else if (key.equals("icount")) {
            return IVariable.wrap(recipe.method_8110(level.method_30349()).method_7947(), level.method_30349());
        }
        else if (key.equals("iname")) {
            return IVariable.wrap(recipe.method_8110(level.method_30349()).method_7964().getString(), level.method_30349());
        }

        return null;
    }

}
