package handbook.client.book.template.variable;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_7225;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import handbook.api.IVariableSerializer;

public class GenericArrayVariableSerializer<T> implements IVariableSerializer<T[]> {
	protected final T[] empty;
	private final IVariableSerializer<T> inner;

	@SuppressWarnings("unchecked")
	public GenericArrayVariableSerializer(IVariableSerializer<T> inner, Class<T> type) {
		this.empty = (T[]) Array.newInstance(type, 0);
		this.inner = inner;
	}

	@Override
	public T[] fromJson(JsonElement json, class_7225.class_7874 registries) {
		if (json.isJsonArray()) {
			JsonArray array = json.getAsJsonArray();
			List<T> stacks = new ArrayList<>();
			for (JsonElement e : array) {
				stacks.add(inner.fromJson(e, registries));
			}
			return stacks.toArray(empty);
		}
		throw new IllegalArgumentException("Can't create an array of objects from a non-array JSON!");
	}

	@Override
	public JsonArray toJson(T[] array, class_7225.class_7874 registries) {
		JsonArray result = new JsonArray();
		for (T elem : array) {
			result.add(inner.toJson(elem, registries));
		}
		return result;
	}

}
