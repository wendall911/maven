package handbook.client.book.gui;

import java.util.Collection;
import java.util.stream.Collectors;
import net.minecraft.class_1074;
import net.minecraft.class_2561;
import handbook.client.base.PersistentData;
import handbook.client.base.PersistentData.BookData;
import handbook.client.book.BookEntry;
import handbook.common.book.Book;

public class GuiBookHistory extends GuiBookEntryList {

    public GuiBookHistory(Book book) {
        super(book, class_2561.method_43471("handbook.gui.lexicon.history"));
    }

    @Override
    protected String getDescriptionText() {
        return class_1074.method_4662("handbook.gui.lexicon.history.info");
    }

    @Override
    protected boolean shouldDrawProgressBar() {
        return false;
    }

    @Override
    protected boolean shouldSortEntryList() {
        return false;
    }

    @Override
    protected Collection<BookEntry> getEntries() {
        BookData data = PersistentData.data.getBookData(book);

        return data.history.stream()
                .map((res) -> book.getContents().entries.get(res))
                .filter((e) -> e != null && !e.isLocked())
                .collect(Collectors.toList());
    }

}
