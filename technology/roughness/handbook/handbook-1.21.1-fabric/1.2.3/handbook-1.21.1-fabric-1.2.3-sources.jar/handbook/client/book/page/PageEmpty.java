package handbook.client.book.page;

import com.google.gson.annotations.SerializedName;
import handbook.client.book.BookPage;
import handbook.client.book.gui.GuiBook;
import net.minecraft.class_332;

public class PageEmpty extends BookPage {

    @SerializedName("draw_filler") boolean filler = true;

    @Override
    public void render(class_332 graphics, int mouseX, int mouseY, float pticks) {
        if (filler) {
            GuiBook.drawPageFiller(graphics, book, 0, 0);
        }
    }

}
