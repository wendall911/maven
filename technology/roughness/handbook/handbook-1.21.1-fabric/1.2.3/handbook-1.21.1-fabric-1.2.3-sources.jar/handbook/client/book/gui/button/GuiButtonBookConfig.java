package handbook.client.book.gui.button;

import handbook.client.book.gui.GuiBook;
import net.minecraft.class_2561;
import net.minecraft.class_4185;

public class GuiButtonBookConfig extends GuiButtonBook {

	public GuiButtonBookConfig(GuiBook parent, int x, int y, class_4185.class_4241 onPress) {
		super(parent, x, y, 308, 20, 11, 11, onPress,
            class_2561.method_43471("handbook.gui.lexicon.button.config"));
	}

}
