package handbook.client.book.gui;

import java.util.Collection;
import net.minecraft.class_1074;
import net.minecraft.class_2561;
import handbook.client.book.BookEntry;
import handbook.common.book.Book;

public class GuiBookIndex extends GuiBookEntryList {

    public GuiBookIndex(Book book) {
        super(book, class_2561.method_43471("handbook.gui.lexicon.index"));
    }

    @Override
    protected String getDescriptionText() {
        return class_1074.method_4662("handbook.gui.lexicon.index.info");
    }

    @Override
    protected Collection<BookEntry> getEntries() {
        return book.getContents().entries.values();
    }

}
