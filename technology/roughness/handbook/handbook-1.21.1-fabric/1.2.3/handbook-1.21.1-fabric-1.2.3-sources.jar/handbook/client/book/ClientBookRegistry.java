package handbook.client.book;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3518;
import org.jetbrains.annotations.Nullable;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import handbook.api.HandbookAPI;
import handbook.client.book.page.PageBlasting;
import handbook.client.book.page.PageCampfireCooking;
import handbook.client.book.page.PageCrafting;
import handbook.client.book.page.PageEmpty;
import handbook.client.book.page.PageEntity;
import handbook.client.book.page.PageImage;
import handbook.client.book.page.PageLink;
import handbook.client.book.page.PageQuest;
import handbook.client.book.page.PageRelations;
import handbook.client.book.page.PageSmelting;
import handbook.client.book.page.PageSmithing;
import handbook.client.book.page.PageSmoking;
import handbook.client.book.page.PageSpotlight;
import handbook.client.book.page.PageStonecutting;
import handbook.client.book.page.PageTemplate;
import handbook.client.book.page.PageText;
import handbook.client.book.template.BookTemplate;
import handbook.client.book.template.TemplateComponent;
import handbook.common.base.HandbookSounds;
import handbook.common.book.Book;
import handbook.common.book.BookRegistry;
import handbook.common.util.SerializationUtil;

public class ClientBookRegistry {

    public final Map<class_2960, Class<? extends BookPage>> pageTypes = new HashMap<>();

    public final Gson gson = new GsonBuilder()
            .registerTypeHierarchyAdapter(BookPage.class, new LexiconPageAdapter())
            .registerTypeHierarchyAdapter(TemplateComponent.class, new TemplateComponentAdapter())
            .create();
    public String currentLang;

    public static final ClientBookRegistry INSTANCE = new ClientBookRegistry();

    private ClientBookRegistry() {}

    public void init() {
        addPageTypes();
    }

    private void addPageTypes() {
        pageTypes.put(HandbookAPI.prefix("text"), PageText.class);
        pageTypes.put(HandbookAPI.prefix("crafting"), PageCrafting.class);
        pageTypes.put(HandbookAPI.prefix("smelting"), PageSmelting.class);
        pageTypes.put(HandbookAPI.prefix("blasting"), PageBlasting.class);
        pageTypes.put(HandbookAPI.prefix("smoking"), PageSmoking.class);
        pageTypes.put(HandbookAPI.prefix("campfire"), PageCampfireCooking.class);
        pageTypes.put(HandbookAPI.prefix("smithing"), PageSmithing.class);
        pageTypes.put(HandbookAPI.prefix("stonecutting"), PageStonecutting.class);
        pageTypes.put(HandbookAPI.prefix("image"), PageImage.class);
        pageTypes.put(HandbookAPI.prefix("spotlight"), PageSpotlight.class);
        pageTypes.put(HandbookAPI.prefix("empty"), PageEmpty.class);
        pageTypes.put(HandbookAPI.prefix("link"), PageLink.class);
        pageTypes.put(HandbookAPI.prefix("relations"), PageRelations.class);
        pageTypes.put(HandbookAPI.prefix("entity"), PageEntity.class);
        pageTypes.put(HandbookAPI.prefix("quest"), PageQuest.class);
    }

    public void reload() {
        currentLang = class_310.method_1551().method_1526().method_4669();
        BookRegistry.INSTANCE.reloadContents(class_310.method_1551().field_1687);
    }

    public void reloadLocks(boolean suppressToasts) {
        BookRegistry.INSTANCE.books.values().forEach(b -> b.reloadLocks(suppressToasts));
    }

    /**
     * @param entryId Entry to force to the top of the stack
     * @param page    Zero-indexed page in the entry to force. Ignored if {@code entryId} is null.
     */
    public void displayBookGui(class_2960 bookStr, @Nullable class_2960 entryId, int page) {
        class_310 mc = class_310.method_1551();
        currentLang = mc.method_1526().method_4669();

        Book book = BookRegistry.INSTANCE.books.get(bookStr);

        if (book != null) {
            book.getContents().checkValidCurrentEntry();

            if (entryId != null) {
                book.getContents().setTopEntry(entryId, page);
            }

            book.getContents().openLexiconGui(book.getContents().getCurrentGui(), false);

            if (mc.field_1724 != null) {
                class_3414 sfx = HandbookSounds.getSound(book.openSound, HandbookSounds.BOOK_OPEN);
                mc.field_1724.method_5783(sfx, 1F, (float) (0.7 + Math.random() * 0.4));
            }
        }
    }

    public static class LexiconPageAdapter implements JsonDeserializer<BookPage> {

        @Override
        public BookPage deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            if (json instanceof JsonPrimitive prim && prim.isString()) {
                // Shortcut: make strings instead of objects shortcut to text pages
                PageText out = new PageText();

                out.setText(prim.getAsString());

                return out;
            }

            JsonObject obj = json.getAsJsonObject();
            String string = class_3518.method_15265(obj, "type");

            if (string.indexOf(':') < 0) {
                string = HandbookAPI.MODID + ":" + string;
            }

            class_2960 type = class_2960.method_12829(string);
            Class<? extends BookPage> clazz = ClientBookRegistry.INSTANCE.pageTypes.get(type);

            if (clazz == null) {
                clazz = PageTemplate.class;
            }

            BookPage page = SerializationUtil.RAW_GSON.fromJson(json, clazz);
            page.sourceObject = obj;

            return page;
        }

    }

    public static class TemplateComponentAdapter implements JsonDeserializer<TemplateComponent> {

        @Override
        public TemplateComponent deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            JsonObject obj = json.getAsJsonObject();
            JsonPrimitive prim = (JsonPrimitive) obj.get("type");
            class_2960 type = class_2960.method_12829(prim.getAsString());
            Class<? extends TemplateComponent> clazz = BookTemplate.componentTypes.get(type);

            if (clazz == null) {
                return null;
            }

            TemplateComponent component = SerializationUtil.RAW_GSON.fromJson(json, clazz);
            component.sourceObject = obj;

            return component;
        }

    }

}
