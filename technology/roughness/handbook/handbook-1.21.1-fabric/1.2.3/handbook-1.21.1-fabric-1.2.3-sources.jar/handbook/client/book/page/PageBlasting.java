package handbook.client.book.page;

import handbook.client.book.page.abstr.PageSimpleProcessingRecipe;
import net.minecraft.class_3859;
import net.minecraft.class_3956;

public class PageBlasting extends PageSimpleProcessingRecipe<class_3859> {

    public PageBlasting() {
        super(class_3956.field_17547);
    }

}
