package handbook.client.book.template;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import handbook.api.IVariable;
import handbook.api.IVariableProvider;
import net.minecraft.class_7225;

public final class JsonVariableWrapper implements IVariableProvider {

	private final JsonObject source;

	public JsonVariableWrapper(JsonObject source) {
		this.source = source;
	}

	@Override
	public IVariable get(String key, class_7225.class_7874 registries) {
		JsonElement prim = source.get(key);
		if (prim == null) {
			throw new IllegalArgumentException("Attempted to get variable " + key + " when it's not present");
		}

		return IVariable.wrap(prim, registries);
	}

	@Override
	public boolean has(String key) {
		return source.has(key);
	}

}
