package handbook.client.jei;

import java.util.Map;
import java.util.Objects;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.ingredients.subtypes.ISubtypeInterpreter;
import mezz.jei.api.ingredients.subtypes.UidContext;
import mezz.jei.api.recipe.IFocus;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.registration.ISubtypeRegistration;
import mezz.jei.api.runtime.IJeiRuntime;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import handbook.api.HandbookAPI;
import handbook.common.item.HandbookDataComponents;
import handbook.common.item.HandbookItems;
import handbook.mixin.client.AccessorKeyMapping;

@JeiPlugin
public class HandbookJeiPlugin implements IModPlugin {

    private static final class_2960 UID = class_2960.method_60655(HandbookAPI.MODID, HandbookAPI.MODID);

    private static class_304 showRecipe, showUses;

    private static IJeiRuntime jeiRuntime;

    static {
    }

    @NotNull
    @Override
    public class_2960 getPluginUid() {
        return UID;
    }

    @Override
    public void registerItemSubtypes(@NotNull ISubtypeRegistration registration) {
        ISubtypeInterpreter<class_1799> bookInterpreter = new ISubtypeInterpreter<>() {
            @Override
            public @Nullable Object getSubtypeData(@NotNull class_1799 stack, @NotNull UidContext context) {
                return stack.method_57824(HandbookDataComponents.BOOK);
            }

            @Override
            public @NotNull String getLegacyStringSubtypeInfo(@NotNull class_1799 stack, @NotNull UidContext context) {
                if (!stack.method_57826(HandbookDataComponents.BOOK)) {
                    return "";
                }

                return Objects.requireNonNull(stack.method_57824(HandbookDataComponents.BOOK)).toString();
            }
        };

        registration.registerSubtypeInterpreter(VanillaTypes.ITEM_STACK, HandbookItems.BOOK, bookInterpreter);
    }

    @Override
    public void onRuntimeAvailable(@NotNull IJeiRuntime jeiRuntime) {
        HandbookJeiPlugin.jeiRuntime = jeiRuntime;

        Map<String, class_304> allKeyMappings = AccessorKeyMapping.getAllKeyMappings();

        HandbookJeiPlugin.showRecipe = allKeyMappings.get("key.jei.showRecipe");
        HandbookJeiPlugin.showUses = allKeyMappings.get("key.jei.showUses");

        if (showRecipe == null || showUses == null) {
            HandbookAPI.LOGGER.warn("Could not locate JEI keybindings, lookups in books may not work");
        }
    }

    public static boolean handleRecipeKeybind(int keyCode, int scanCode, class_1799 stack) {
        IFocus<class_1799> focus;

        if (showRecipe != null && showRecipe.method_1417(keyCode, scanCode)) {
            focus = jeiRuntime.getJeiHelpers().getFocusFactory().createFocus(RecipeIngredientRole.OUTPUT, VanillaTypes.ITEM_STACK, stack);

            jeiRuntime.getRecipesGui().show(focus);

            return true;
        }
        else if (showUses != null && showUses.method_1417(keyCode, scanCode)) {
            focus = jeiRuntime.getJeiHelpers().getFocusFactory().createFocus(RecipeIngredientRole.INPUT, VanillaTypes.ITEM_STACK, stack);

            jeiRuntime.getRecipesGui().show(focus);

            return true;
        }

        return false;
    }

}
