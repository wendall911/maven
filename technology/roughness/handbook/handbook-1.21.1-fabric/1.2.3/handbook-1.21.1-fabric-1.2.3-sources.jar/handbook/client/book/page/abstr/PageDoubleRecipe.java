package handbook.client.book.page.abstr;

import com.google.gson.annotations.SerializedName;
import handbook.client.book.BookContentsBuilder;
import handbook.client.book.BookEntry;
import handbook.client.book.gui.GuiBook;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public abstract class PageDoubleRecipe<T> extends PageWithText {

    @SerializedName("recipe") class_2960 recipeId;
    @SerializedName("recipe2") class_2960 recipe2Id;
    @SerializedName("link_recipe") boolean linkRecipe = true;
    @SerializedName("link_recipe2") boolean linkRecipe2 = true;
    String title;

    protected transient T recipe1, recipe2;
    protected transient class_2561 title1, title2;

    @Override
    public void build(class_1937 level, BookEntry entry, BookContentsBuilder builder, int pageNum) {
        super.build(level, entry, builder, pageNum);

        recipe1 = loadRecipe(level, builder, entry, recipeId, linkRecipe);
        recipe2 = loadRecipe(level, builder, entry, recipe2Id, linkRecipe2);

        if (recipe1 == null && recipe2 != null) {
            recipe1 = recipe2;
            recipe2 = null;
        }

        boolean customTitle = title != null && !title.isEmpty();
        title1 = !customTitle ? getRecipeOutput(level, recipe1).method_7964() : i18nText(title);
        title2 = class_2561.method_43470("-");
        if (recipe2 != null) {
            title2 = !customTitle ? getRecipeOutput(level, recipe2).method_7964() : class_2561.method_43473();
            if (title1.equals(title2)) {
                title2 = class_2561.method_43473();
            }
        }
    }

    @Override
    public void render(class_332 graphics, int mouseX, int mouseY, float pticks) {
        if (recipe1 != null) {
            int recipeX = getX();
            int recipeY = getY();
            drawRecipe(graphics, recipe1, recipeX, recipeY, mouseX, mouseY, false);

            if (recipe2 != null) {
                drawRecipe(graphics, recipe2, recipeX, recipeY + getRecipeHeight() - (title2.getString().isEmpty() ? 10 : 0), mouseX, mouseY, true);
            }
        }

        super.render(graphics, mouseX, mouseY, pticks);
    }

    @Override
    public int getTextHeight() {
        return getY() + getRecipeHeight() * (recipe2 == null ? 1 : 2) - (title2.getString().isEmpty() ? 23 : 13);
    }

    @Override
    public boolean shouldRenderText() {
        return getTextHeight() + 10 < GuiBook.PAGE_HEIGHT;
    }

    protected abstract void drawRecipe(class_332 graphics, T recipe, int recipeX, int recipeY, int mouseX, int mouseY, boolean second);
    protected abstract T loadRecipe(class_1937 level, BookContentsBuilder builder, BookEntry entry, class_2960 loc, boolean linkRecipe);
    protected abstract class_1799 getRecipeOutput(class_1937 level, T recipe);
    protected abstract int getRecipeHeight();

    protected int getX() {
        return GuiBook.PAGE_WIDTH / 2 - 49;
    }

    protected int getY() {
        return 4;
    }

    protected class_2561 getTitle(boolean second) {
        return second ? title2 : title1;
    }

}
