package handbook.client.book.page;

import handbook.client.book.page.abstr.PageSimpleProcessingRecipe;
import net.minecraft.class_3862;
import net.minecraft.class_3956;

public class PageSmoking extends PageSimpleProcessingRecipe<class_3862> {

    public PageSmoking() {
        super(class_3956.field_17548);
    }

}
