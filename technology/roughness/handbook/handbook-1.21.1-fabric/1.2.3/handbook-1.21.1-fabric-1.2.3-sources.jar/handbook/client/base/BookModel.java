package handbook.client.base;

import java.util.Collections;
import java.util.List;
import java.util.function.Function;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1100;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4730;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_777;
import net.minecraft.class_7775;
import net.minecraft.class_806;
import net.minecraft.class_809;
import net.minecraft.client.resources.model.*;
import handbook.common.book.Book;
import handbook.common.item.HandbookBook;

public class BookModel implements class_1087 {

	private final class_1087 original;
	private final class_806 itemHandler;

	public BookModel(class_1087 original, Function<class_2960, class_1087> modelGetter) {
		this.original = original;

		this.itemHandler = new class_806(DummyModelBaker.INSTANCE, null, Collections.emptyList()) {
			@Override
			public class_1087 method_3495(@NotNull class_1087 original, @NotNull class_1799 stack,
					@Nullable class_638 world, @Nullable class_1309 entity, int seed) {
				Book book = HandbookBook.getBook(stack);
				if (book != null) {
					return modelGetter.apply(book.model);
				}
				return original;
			}
		};
	}

	@NotNull
	@Override
	public class_806 method_4710() {
		return itemHandler;
	}

	@NotNull
	@Override
	public List<class_777> method_4707(@Nullable class_2680 state, @Nullable class_2350 side, @NotNull class_5819 rand) {
		return original.method_4707(state, side, rand);
	}

	@Override
	public boolean method_4708() {
		return original.method_4708();
	}

	@Override
	public boolean method_4712() {
		return original.method_4712();
	}

	@Override
	public boolean method_24304() {
		return original.method_24304();
	}

	@Override
	public boolean method_4713() {
		return original.method_4713();
	}

	@NotNull
	@Override
	public class_1058 method_4711() {
		return original.method_4711();
	}

	@Override
	public class_809 method_4709() {
		return original.method_4709();
	}

	private static class DummyModelBaker implements class_7775 {
		static class_7775 INSTANCE = new DummyModelBaker();

		// soft implement IModelBakerExtension
		public Function<class_4730, class_1058> getModelTextureGetter() {
			return null;
		}

		// soft implement IModelBakerExtension
		public class_1087 bake(class_2960 location, class_3665 state, Function<class_4730, class_1058> sprites) {
			return null;
		}

		// soft implement IModelBakerExtension
		public class_1087 bakeUncached(class_1100 model, class_3665 state, Function<class_4730, class_1058> sprites) {
			return null;
		}

		// soft implement IModelBakerExtension
		public class_1100 getTopLevelModel(class_1091 location) {
			return null;
		}

		@Override
		public class_1100 method_45872(class_2960 resourceLocation) {
			return null;
		}

		@Nullable
		@Override
		public class_1087 method_45873(class_2960 resourceLocation, class_3665 modelState) {
			return null;
		}
	}

}
