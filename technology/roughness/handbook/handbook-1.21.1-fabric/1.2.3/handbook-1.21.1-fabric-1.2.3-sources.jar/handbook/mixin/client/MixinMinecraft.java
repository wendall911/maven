package handbook.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import handbook.client.base.ClientAdvancements;
import net.minecraft.class_310;
import net.minecraft.class_437;

@Mixin(class_310.class)
public class MixinMinecraft {

    @Inject(at = @At("HEAD"), method = "disconnect(Lnet/minecraft/client/gui/screens/Screen;)V")
    public void handbook$onLogout(class_437 screen, CallbackInfo info) {
        ClientAdvancements.playerLogout();
    }


}
