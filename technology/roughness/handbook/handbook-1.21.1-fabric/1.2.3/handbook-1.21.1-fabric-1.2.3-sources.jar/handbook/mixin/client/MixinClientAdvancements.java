package handbook.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import handbook.client.base.ClientAdvancements;
import net.minecraft.class_2779;

@Mixin(net.minecraft.class_632.class)
public abstract class MixinClientAdvancements {

    @Inject(at = @At("RETURN"), method = "update")
    public void handbook$onSync(class_2779 packet, CallbackInfo info) {
        ClientAdvancements.onClientPacket();
    }

}
