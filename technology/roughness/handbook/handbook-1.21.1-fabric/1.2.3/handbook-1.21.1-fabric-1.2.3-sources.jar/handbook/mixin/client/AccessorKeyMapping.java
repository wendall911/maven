package handbook.mixin.client;

import java.util.Map;
import net.minecraft.class_304;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_304.class)
public interface AccessorKeyMapping {

    @Accessor("ALL")
    static Map<String, class_304> getAllKeyMappings() {
        throw new IllegalStateException();
    }

}
