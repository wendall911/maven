package handbook.mixin;

import net.minecraft.class_1856;
import net.minecraft.class_8060;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_8060.class)
public interface AccessorSmithingTransformRecipe {

    @Accessor
    class_1856 getTemplate();

    @Accessor
    class_1856 getBase();

    @Accessor
    class_1856 getAddition();

}
