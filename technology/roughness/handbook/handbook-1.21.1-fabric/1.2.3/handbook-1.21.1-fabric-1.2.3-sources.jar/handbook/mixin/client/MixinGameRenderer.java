package handbook.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import handbook.client.base.ClientTicker;
import net.minecraft.class_757;
import net.minecraft.class_9779;

@Mixin(class_757.class)
public class MixinGameRenderer {

    @Inject(at = @At("HEAD"), method = "render(Lnet/minecraft/client/DeltaTracker;Z)V")
    public void handbook$renderStart(class_9779 deltaTracker, boolean tick, CallbackInfo info) {
        ClientTicker.renderTickStart(deltaTracker.method_60637(false));
    }

    @Inject(at = @At("RETURN"), method = "render(Lnet/minecraft/client/DeltaTracker;Z)V")
    public void handbook$renderEnd(class_9779 deltaTracker, boolean tick, CallbackInfo info) {
        ClientTicker.renderTickEnd();
    }

}
