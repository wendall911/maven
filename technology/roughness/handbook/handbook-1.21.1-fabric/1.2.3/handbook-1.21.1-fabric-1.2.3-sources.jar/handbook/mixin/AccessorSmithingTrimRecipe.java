package handbook.mixin;

import net.minecraft.class_1856;
import net.minecraft.class_8062;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_8062.class)
public interface AccessorSmithingTrimRecipe {

    @Accessor
    class_1856 getTemplate();

    @Accessor
    class_1856 getBase();

    @Accessor
    class_1856 getAddition();

}
