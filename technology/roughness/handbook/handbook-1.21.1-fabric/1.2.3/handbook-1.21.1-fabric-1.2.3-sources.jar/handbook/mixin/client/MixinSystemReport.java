package handbook.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import handbook.client.handler.BookCrashHandler;
import net.minecraft.class_6396;

@Mixin(class_6396.class)
public class MixinSystemReport {

    @Inject(at = @At("RETURN"), method = "<init>")
    private void handbook$addContext(CallbackInfo ci) {
        BookCrashHandler.appendToCrashReport((class_6396) (Object) this);
    }

}
