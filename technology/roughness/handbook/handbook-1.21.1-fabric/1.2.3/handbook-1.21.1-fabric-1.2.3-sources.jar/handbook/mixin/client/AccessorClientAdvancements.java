package handbook.mixin.client;

import java.util.Map;
import net.minecraft.class_167;
import net.minecraft.class_632;
import net.minecraft.class_8779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_632.class)
public interface AccessorClientAdvancements {

    @Accessor("progress")
    Map<class_8779, class_167> getProgress();

}
