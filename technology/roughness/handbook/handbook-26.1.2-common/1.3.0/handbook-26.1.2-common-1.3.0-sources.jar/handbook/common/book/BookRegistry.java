package handbook.common.book;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.stream.Stream;

import org.jspecify.annotations.NonNull;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import net.minecraft.resources.Identifier;
import net.minecraft.world.level.Level;

import org.apache.commons.lang3.tuple.Pair;

import handbook.Handbook;
import handbook.api.HandbookAPI;
import handbook.client.book.ClientBookRegistry;
import handbook.common.CommonModContainer;
import handbook.common.util.SerializationUtil.IdentifierSerializer;
import handbook.config.HandbookConfig;
import handbook.platform.Services;

public class BookRegistry {

    public static final BookRegistry INSTANCE = new BookRegistry();
    public static final String BOOKS_LOCATION = HandbookAPI.MODID + "_books";

    public final Map<Identifier, Book> books = new HashMap<>();
    public static final Gson GSON = new GsonBuilder()
        .registerTypeAdapter(Identifier.class, new IdentifierSerializer()).create();

    private BookRegistry() {}

    public void init() {
        Collection<CommonModContainer> mods = Services.BOOK_HELPER.getAllMods();
        Map<Pair<CommonModContainer, Identifier>, String> foundBooks = new HashMap<>();

        HandbookAPI.LOGGER.warn("Found {} mods", mods.size());

        mods.forEach(mod -> {
            String id = mod.getId();
            HandbookAPI.LOGGER.warn("Found Mod ID: " + id);
            findFiles(mod, String.format("data/%s/%s", id, BOOKS_LOCATION), Files::exists,
                    (path, file) -> {
                        if (Files.isRegularFile(file)
                                && file.getFileName().toString().equals("book.json")) {
                            String fileStr = file.toString().replaceAll("\\\\", "/");
                            String relPath = fileStr
                                    .substring(fileStr.indexOf(BOOKS_LOCATION) + BOOKS_LOCATION.length() + 1);
                            String bookName = relPath.substring(0, relPath.indexOf("/"));

                            if (bookName.contains("/")) {
                                HandbookAPI.LOGGER.warn("Ignored book.json @ {}", file);
                                return true;
                            }

                            String assetPath = fileStr.substring(fileStr.indexOf("data/"));
                            Identifier bookId = Identifier.fromNamespaceAndPath(id, bookName);
                            foundBooks.put(Pair.of(mod, bookId), assetPath);
                        }

                        return true;
                    }, true, 2);
        });
        HandbookAPI.LOGGER.warn("Found XX {} books", foundBooks.size());

        foundBooks.forEach((pair, file) -> {
            CommonModContainer mod = pair.getLeft();
            Identifier res = pair.getRight();

            try (InputStream stream = Files.newInputStream(mod.getPath(file))) {
                loadBook(mod, res, stream);
            }
            catch (Exception e) {
                HandbookAPI.LOGGER.error("Failed to load book {} defined by mod {}, skipping",
                        res, mod.getId(), e);
            }
        });
    }

    public void loadBook(CommonModContainer mod, Identifier res, InputStream stream) {
        Reader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        JsonObject tree = GSON.fromJson(reader, JsonObject.class);

        books.put(res, new Book(tree, mod, res));
    }

    /**
     * Must only be called on client
     */
    public void reloadContents(Level level) {
        HandbookConfig.reloadBuiltinFlags();

        for (Book book : books.values()) {
            book.reloadContents(level, false);
        }

        ClientBookRegistry.INSTANCE.reloadLocks(false);
    }

    public static void findFiles(CommonModContainer mod, String base, Predicate<Path> rootFilter,
            BiFunction<Path, Path, Boolean> processor, boolean visitAllFiles, int maxDepth) {
        if (mod.getId().equals("minecraft")) {
            return;
        }

        try {
            for (Path root : mod.getRootPaths()) {
                walk(root.resolve(base), rootFilter, processor, visitAllFiles, maxDepth);
            }
        }
        catch (IOException ex) {
            throw new UncheckedIOException(ex);
        }
    }

    private static void walk(Path root, Predicate<Path> rootFilter, BiFunction<Path, Path, Boolean> processor,
            boolean visitAllFiles, int maxDepth) throws IOException {
        if (root == null || !Files.exists(root) || !rootFilter.test(root)) {
            return;
        }

        if (processor != null) {
            try (Stream<@NonNull Path> stream = Files.walk(root, maxDepth)) {
                Iterator<Path> itr = stream.iterator();

                while (itr.hasNext()) {
                    boolean keepGoing = processor.apply(root, itr.next());

                    if (!visitAllFiles && !keepGoing) {
                        return;
                    }
                }
            }
        }
    }

}
