package handbook.client.book.gui;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.jetbrains.annotations.NotNull;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.Component;

import org.lwjgl.glfw.GLFW;

import handbook.client.book.BookEntry;
import handbook.client.book.gui.button.GuiButtonCategory;
import handbook.client.book.gui.button.GuiButtonEntry;
import handbook.common.book.Book;
import handbook.common.util.ColorHelper.HandbookColors;

public abstract class GuiBookEntryList extends GuiBook {

    public static final int ENTRIES_PER_PAGE = 13;
    public static final int ENTRIES_IN_FIRST_PAGE = 11;

    private BookTextRenderer text;

    protected final List<Button> entryButtons = new ArrayList<>();
    private List<BookEntry> allEntries;
    private final List<BookEntry> visibleEntries = new ArrayList<>();

    private EditBox searchField;

    public GuiBookEntryList(Book book, Component title) {
        super(book, title);
    }

    @Override
    public void init() {
        super.init();

        text = new BookTextRenderer(this, Component.literal(getDescriptionText()), LEFT_PAGE_X, TOP_PADDING + 22);

        allEntries = new ArrayList<>(getEntries());
        allEntries.removeIf(BookEntry::shouldHide);
        if (shouldSortEntryList()) {
            Collections.sort(allEntries);
        }

        this.searchField = createSearchBar();
        buildEntryButtons();
    }

    protected EditBox createSearchBar() {
        EditBox field = new EditBox(font, 160, 170, 90, 12, Component.empty());
        field.setMaxLength(32);
        field.setBordered(false);
        field.setCanLoseFocus(false);
        field.setFocused(true);
        return field;
    }

    protected abstract String getDescriptionText();
    protected abstract Collection<BookEntry> getEntries();

    protected boolean doesEntryCountForProgress(BookEntry entry) {
        return true;
    }

    protected boolean shouldDrawProgressBar() {
        return true;
    }

    protected boolean shouldSortEntryList() {
        return true;
    }

    protected void addSubcategoryButtons() {
        // NO-OP
    }

    @Override
    void drawForegroundElements(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
        super.drawForegroundElements(guiGraphics, mouseX, mouseY, partialTicks);

        if (spread == 0) {
            drawCenteredStringNoShadow(guiGraphics, getTitle().getVisualOrderText(), LEFT_PAGE_X + PAGE_WIDTH / 2, TOP_PADDING, book.headerColor);
            drawCenteredStringNoShadow(guiGraphics, getChapterListTitle(), RIGHT_PAGE_X + PAGE_WIDTH / 2, TOP_PADDING, book.headerColor);

            drawSeparator(guiGraphics, book, LEFT_PAGE_X, TOP_PADDING + 12);
            drawSeparator(guiGraphics, book, RIGHT_PAGE_X, TOP_PADDING + 12);

            text.extractRenderState(guiGraphics, mouseX, mouseY, partialTicks);
            if (shouldDrawProgressBar()) {
                drawProgressBar(guiGraphics, book, mouseX, mouseY, this::doesEntryCountForProgress);
            }
        }
        else if (spread % 2 == 1 && spread == maxSpreads - 1 && entryButtons.size() <= ENTRIES_PER_PAGE) {
            drawPageFiller(guiGraphics, book);
        }

        if (!searchField.getValue().isEmpty()) {
            drawFromTexture(guiGraphics, book, searchField.getX() - 8, searchField.getY(), 140, 183, 99, 14);
            Component toDraw = Component.literal(searchField.getValue()).setStyle(book.getFontStyle());
            guiGraphics.text(font, toDraw, searchField.getX() + 7, searchField.getY() + 1, book.textColor, false);
        }

        if (visibleEntries.isEmpty()) {
            if (!searchField.getValue().isEmpty()) {
                drawCenteredStringNoShadow(
                    guiGraphics,
                    I18n.get("handbook.gui.lexicon.no_results"),
                    GuiBook.RIGHT_PAGE_X + GuiBook.PAGE_WIDTH / 2, 80,
                    HandbookColors.HEADER.toColor()
                );
                guiGraphics.pose().scale(2F, 2F);
                drawCenteredStringNoShadow(
                    guiGraphics,
                    I18n.get("handbook.gui.lexicon.sad"),
                    GuiBook.RIGHT_PAGE_X / 2 + GuiBook.PAGE_WIDTH / 4,
                    47,
                    HandbookColors.LEXICON_SAD.toColor()
                );
                guiGraphics.pose().scale(0.5F, 0.5F);
            }
            else {
                drawCenteredStringNoShadow(
                    guiGraphics,
                    getNoEntryMessage(),
                    GuiBook.RIGHT_PAGE_X + GuiBook.PAGE_WIDTH / 2,
                    80,
                    HandbookColors.HEADER.toColor()
                );
            }
        }
    }

    protected String getChapterListTitle() {
        return I18n.get("handbook.gui.lexicon.chapters");
    }

    protected String getNoEntryMessage() {
        return I18n.get("handbook.gui.lexicon.no_entries");
    }

    @Override
    public boolean mouseClickedScaled(MouseButtonEvent mouseButtonEvent, boolean isDoubleClick) {
        MouseButtonEvent searchButtonEvent = new MouseButtonEvent(
            mouseButtonEvent.x() - bookLeft,
            mouseButtonEvent.y() - bookTop,
            mouseButtonEvent.buttonInfo()
        );

        return text.click(mouseButtonEvent)
            || searchField.mouseClicked(searchButtonEvent, isDoubleClick)
            || super.mouseClickedScaled(mouseButtonEvent, isDoubleClick);
    }

    @Override
    public boolean charTyped(@NotNull CharacterEvent charEvent) {
        String currQuery = searchField.getValue();
        if (searchField.charTyped(charEvent)) {
            if (!searchField.getValue().equals(currQuery)) {
                buildEntryButtons();
            }

            return true;
        }

        return super.charTyped(charEvent);
    }

    @Override
    public boolean keyPressed(@NotNull KeyEvent keyEvent) {
        int key = keyEvent.key();
        String currQuery = searchField.getValue();

        if (key == GLFW.GLFW_KEY_ENTER) {
            if (visibleEntries.size() == 1) {
                displayLexiconGui(new GuiBookEntry(book, visibleEntries.getFirst()), true);

                return true;
            }
        } else if (searchField.keyPressed(keyEvent)) {
            if (!searchField.getValue().equals(currQuery)) {
                buildEntryButtons();
            }

            return true;
        }

        return super.keyPressed(keyEvent);
    }

    public void handleButtonCategory(Button button) {
        GuiButtonCategory guiButtonCategory = (GuiButtonCategory) button;

        if (guiButtonCategory.getCategory() != null) {
            displayLexiconGui(new GuiBookCategory(book, guiButtonCategory.getCategory()), true);
        }
    }

    public void handleButtonEntry(Button button) {
        GuiBookEntry.displayOrBookmark(this, ((GuiButtonEntry) button).getEntry());
    }

    @Override
    void onPageChanged() {
        buildEntryButtons();
    }

    void buildEntryButtons() {
        removeDrawablesIn(entryButtons);
        entryButtons.clear();
        visibleEntries.clear();

        String query = searchField.getValue().toLowerCase();
        allEntries.stream().filter((e) -> e.isFoundByQuery(query)).forEach(visibleEntries::add);

        maxSpreads = 1;
        int count = visibleEntries.size();
        count -= ENTRIES_IN_FIRST_PAGE;
        if (count > 0) {
            maxSpreads += (int) Math.ceil((float) count / (ENTRIES_PER_PAGE * 2));
        }

        while (getEntryCountStart() > visibleEntries.size()) {
            spread--;
        }

        if (spread == 0) {
            addEntryButtons(RIGHT_PAGE_X, TOP_PADDING + 20, 0, ENTRIES_IN_FIRST_PAGE);
            addSubcategoryButtons();
        } else {
            int start = getEntryCountStart();
            addEntryButtons(LEFT_PAGE_X, TOP_PADDING, start, ENTRIES_PER_PAGE);
            addEntryButtons(RIGHT_PAGE_X, TOP_PADDING, start + ENTRIES_PER_PAGE, ENTRIES_PER_PAGE);
        }
    }

    int getEntryCountStart() {
        if (spread == 0) {
            return 0;
        }

        int start = ENTRIES_IN_FIRST_PAGE;
        start += (ENTRIES_PER_PAGE * 2) * (spread - 1);
        return start;
    }

    void addEntryButtons(int x, int y, int start, int count) {
        for (int i = 0; i < count && (i + start) < visibleEntries.size(); i++) {
            Button button = new GuiButtonEntry(this, bookLeft + x, bookTop + y + i * 11, visibleEntries.get(start + i), this::handleButtonEntry);
            addRenderableWidget(button);
            entryButtons.add(button);
        }
    }

    public String getSearchQuery() {
        return searchField.getValue();
    }

}
