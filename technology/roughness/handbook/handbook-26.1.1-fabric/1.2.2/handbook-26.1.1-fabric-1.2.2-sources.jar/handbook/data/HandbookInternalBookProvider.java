package handbook.data;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.data.PackOutput;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.Items;

import handbook.api.HandbookAPI;
import handbook.api.data.BookBuilder;
import handbook.common.item.HandbookItems;

public class HandbookInternalBookProvider extends handbook.api.data.HandbookBookProvider {

    public static final String INTRO_BOOK_TRANSLATION_KEY = "book." + HandbookAPI.MODID + ".intro_book";
    private int categorySortNum = -1;
    private int entrySortNum = -1;

    public HandbookInternalBookProvider(PackOutput packOutput, CompletableFuture<Provider> registries) {
        super(packOutput, HandbookAPI.MODID, "en_us", registries);
    }

    @Override
    protected void addBooks(Consumer<BookBuilder> consumer, Provider provider) {
        ItemStackTemplate book = new ItemStackTemplate(HandbookItems.BOOK);
        ItemStackTemplate writeableBook = new ItemStackTemplate(Items.WRITABLE_BOOK);

        BookBuilder bookBuilder = createBookBuilder(HandbookItems.BOOK, INTRO_BOOK_TRANSLATION_KEY, prefix("landing"))
            .setSubtitle(prefix("subtitle"))
            .setCreativeTab("minecraft:tools_and_utilities")
            .setShowProgress(true)
            .setI18n(true)
            .addCategory(
                "introduction",
                prefix("introduction.name"),
                prefix("introduction.description"),
                book
            )
            .setSortnum(categorySortNum++)
            .addEntry(
                "introduction/welcome",
                prefix("introduction.welcome.name"),
                writeableBook
            ).setSortnum(entrySortNum++)
            .addTextPage(prefix("introduction.welcome.intro"))
            .build().build().build();

        bookBuilder.build(consumer);
    }

    private String prefix(String name) {
        return INTRO_BOOK_TRANSLATION_KEY + "." + name;
    }

}
