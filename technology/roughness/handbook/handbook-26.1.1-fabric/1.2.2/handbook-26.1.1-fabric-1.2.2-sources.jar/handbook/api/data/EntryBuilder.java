package handbook.api.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStackTemplate;

import handbook.api.data.page.BlastingPageBuilder;
import handbook.api.data.page.CampfirePageBuilder;
import handbook.api.data.page.CraftingPageBuilder;
import handbook.api.data.page.CustomPageBuilder;
import handbook.api.data.page.EmptyPageBuilder;
import handbook.api.data.page.EntityPageBuilder;
import handbook.api.data.page.FormattedTextPageBuilder;
import handbook.api.data.page.ImagePageBuilder;
import handbook.api.data.page.LinkPageBuilder;
import handbook.api.data.page.QuestPageBuilder;
import handbook.api.data.page.RelationsPageBuilder;
import handbook.api.data.page.SmeltingPageBuilder;
import handbook.api.data.page.SmithingPageBuilder;
import handbook.api.data.page.SmokingPageBuilder;
import handbook.api.data.page.SpotlightPageBuilder;
import handbook.api.data.page.StonecuttingPageBuilder;
import handbook.api.data.page.TextPageBuilder;
import handbook.api.data.util.ItemStackHelper;
import handbook.api.data.util.TagKeyHelper;

public class EntryBuilder {

    private final CategoryBuilder parent;
    private final Identifier id;
    private final String name;
    private final String category;
    private final String icon;
    private final List<AbstractPageBuilder<?>> pages = new ArrayList<>();
    private String advancement;
    private String flag;
    private Boolean priority;
    private Boolean secret;
    private Boolean readByDefault;
    private Integer sortnum;
    private String turnin;
    private Map<ItemStackTemplate, Integer> extraRecipeMappings;
    private Map<TagKey<Item>, Integer> extraRecipeMappingTags;

    protected EntryBuilder(String id, String name, String icon, CategoryBuilder parent) {
        this.id = Identifier.fromNamespaceAndPath(parent.getId().getNamespace(), id);
        this.name = name;
        this.category = parent.getId().toString();
        this.icon = icon;
        this.parent = parent;
    }

    protected EntryBuilder(String id, String name, ItemStackTemplate icon, CategoryBuilder parent) {
        this(id, name, ItemStackHelper.serializeStack(icon), parent);
    }

    JsonObject toJson() {
        JsonObject json = new JsonObject();
        json.addProperty("name", name);
        json.addProperty("category", category);
        json.addProperty("icon", icon);
        JsonArray pages = new JsonArray();

        for (AbstractPageBuilder<?> page : this.pages) {
            pages.add(page.toJson());
        }

        json.add("pages", pages);

        if (advancement != null) {
            json.addProperty("advancement", advancement);
        }
        if (flag != null) {
            json.addProperty("flag", flag);
        }
        if (priority != null) {
            json.addProperty("priority", priority);
        }
        if (secret != null) {
            json.addProperty("secret", secret);
        }
        if (readByDefault != null) {
            json.addProperty("read_by_default", readByDefault);
        }
        if (sortnum != null) {
            json.addProperty("sortnum", sortnum);
        }
        if (turnin != null) {
            json.addProperty("turnin", turnin);
        }
        if (extraRecipeMappings != null || extraRecipeMappingTags != null) {
            JsonObject mappings = new JsonObject();

            if (extraRecipeMappingTags != null) {
                for (Map.Entry<TagKey<Item>, Integer> entry : extraRecipeMappingTags.entrySet()) {
                    mappings.addProperty(TagKeyHelper.serializeTagKey(entry.getKey()), entry.getValue());
                }
            }
            if (extraRecipeMappings != null) {
                for (Map.Entry<ItemStackTemplate, Integer> entry : extraRecipeMappings.entrySet()) {
                    mappings.addProperty(ItemStackHelper.serializeStack(entry.getKey()), entry.getValue());
                }
            }

            json.add("extra_recipe_mappings", mappings);
        }

        return json;
    }

    public CategoryBuilder build() {
        return parent;
    }

    public EntryBuilder addSimpleTextPage(String text) {
        return addPage(new TextPageBuilder(text, this)).build();
    }

    public EntryBuilder addSimpleTextPage(String text, String title) {
        return addPage(new TextPageBuilder(text, title, this)).build();
    }

    public TextPageBuilder addTextPage(String text) {
        return addPage(new TextPageBuilder(text, this));
    }

    public TextPageBuilder addTextPage(String text, String title) {
        return addPage(new TextPageBuilder(text, title, this));
    }

    public FormattedTextPageBuilder addFormattedTextPage(String translate) {
        return addPage(new FormattedTextPageBuilder(translate, this));
    }

    public CustomPageBuilder addCustomPage(String template) {
        return addPage(new CustomPageBuilder(template, this));
    }

    public ImagePageBuilder addImagePage(Identifier image) {
        return addPage(new ImagePageBuilder(image, this));
    }

    public RelationsPageBuilder addRelationsPage() {
        return addPage(new RelationsPageBuilder(this));
    }

    public QuestPageBuilder addQuestPage() {
        return addPage(new QuestPageBuilder(this, null));
    }

    public QuestPageBuilder addQuestPage(Identifier trigger) {
        return addPage(new QuestPageBuilder(this, trigger));
    }

    public CraftingPageBuilder addCraftingPage(Identifier recipe) {
        return addPage(new CraftingPageBuilder(recipe, this));
    }

    public SmeltingPageBuilder addSmeltingPage(Identifier recipe) {
        return addPage(new SmeltingPageBuilder(recipe, this));
    }

    public BlastingPageBuilder addBlastingPage(Identifier recipe) {
        return addPage(new BlastingPageBuilder(recipe, this));
    }

    public SmokingPageBuilder addSmokingPage(Identifier recipe) {
        return addPage(new SmokingPageBuilder(recipe, this));
    }

    public CampfirePageBuilder addCampfirePage(Identifier recipe) {
        return addPage(new CampfirePageBuilder(recipe, this));
    }

    public SmithingPageBuilder addSmithingPage(Identifier recipe) {
        return addPage(new SmithingPageBuilder(recipe, this));
    }

    public StonecuttingPageBuilder addStonecuttingPage(Identifier recipe) {
        return addPage(new StonecuttingPageBuilder(recipe, this));
    }

    public EntityPageBuilder addEntityPage(String entity) {
        return addPage(new EntityPageBuilder(entity, this));
    }

    public EntityPageBuilder addEntityPage(Identifier entity) {
        return addEntityPage(entity.toString());
    }

    public SpotlightPageBuilder addSpotlightPage(ItemStackTemplate... stacks) {
        return addPage(new SpotlightPageBuilder(this, stacks));
    }

    @SafeVarargs
    public final SpotlightPageBuilder addSpotlightPage(TagKey<Item>... tags) {
        return addPage(new SpotlightPageBuilder(this, tags));
    }

    public LinkPageBuilder addLinkPage(String url, String linkText) {
        return addPage(new LinkPageBuilder(url, linkText, this));
    }

    public EmptyPageBuilder addEmptyPage() {
        return addPage(new EmptyPageBuilder(true, this));
    }

    public EmptyPageBuilder addEmptyPage(boolean drawFiller) {
        return addPage(new EmptyPageBuilder(drawFiller, this));
    }

    public <T extends AbstractPageBuilder<T>> T addPage(T builder) {
        pages.add(builder);

        return builder;
    }

    public EntryBuilder setAdvancement(String advancement) {
        this.advancement = advancement;

        return this;
    }

    public EntryBuilder setFlag(String flag) {
        this.flag = flag;

        return this;
    }

    public EntryBuilder setPriority(boolean priority) {
        this.priority = priority;

        return this;
    }

    public EntryBuilder setSecret(boolean secret) {
        this.secret = secret;

        return this;
    }

    public EntryBuilder setReadByDefault(boolean readByDefault) {
        this.readByDefault = readByDefault;

        return this;
    }

    public EntryBuilder setSortnum(int sortnum) {
        this.sortnum = sortnum;

        return this;
    }

    public EntryBuilder setTurnin(String turnin) {
        this.turnin = turnin;

        return this;
    }

    public EntryBuilder addExtraRecipeMapping(ItemStackTemplate stack, int index) {
        if (this.extraRecipeMappings == null) {
            this.extraRecipeMappings = new HashMap<>();
        }
        this.extraRecipeMappings.put(stack, index);

        return this;
    }

    public EntryBuilder addExtraRecipeMapping(TagKey<Item> tag, int index) {
        if (this.extraRecipeMappingTags == null) {
            this.extraRecipeMappingTags = new HashMap<>();
        }
        this.extraRecipeMappingTags.put(tag, index);

        return this;
    }

    protected Identifier getId() {
        return id;
    }

}
