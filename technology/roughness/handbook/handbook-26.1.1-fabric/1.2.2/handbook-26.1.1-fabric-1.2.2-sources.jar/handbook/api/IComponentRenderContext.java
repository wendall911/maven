package handbook.api;

import java.util.List;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;

/**
 * A context for a custom component's methods.
 */
public interface IComponentRenderContext {

    Screen getGui();

    Style getFontStyle();

    void renderItemStack(GuiGraphicsExtractor graphics, int x, int y, int mouseX, int mouseY, ItemStack stack);

    void renderIngredient(GuiGraphicsExtractor graphics, int x, int y, int mouseX, int mouseY, Ingredient ingredient);

    boolean isAreaHovered(int mouseX, int mouseY, int x, int y, int w, int h);

    boolean navigateToEntry(Identifier entry, int page, boolean push);

    @Deprecated // use setHoverTooltipComponents
    void setHoverTooltip(List<String> tooltip);

    void setHoverTooltipComponents(List<Component> tooltip);

    @Deprecated(forRemoval = true) // use addWidget
    void registerButton(Button button, int pageNum, Runnable onClick);

    void addWidget(AbstractWidget button, int pageNum);

    Identifier getBookTexture();

    Identifier getCraftingTexture();

    int getTextColor();

    int getHeaderColor();

    int getTicksInBook();

}
