package handbook.api.data;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

import org.jspecify.annotations.NonNull;

import com.google.gson.JsonObject;

import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStackTemplate;

public abstract class HandbookBookProvider implements DataProvider {

    protected final PackOutput.PathProvider datapackProvider;
    protected final PackOutput.PathProvider assetsProvider;

    private final String locale;
    private final String modid;
    private final CompletableFuture<HolderLookup.Provider> registries;

    public HandbookBookProvider(PackOutput packOutput, String modid, String locale, CompletableFuture<HolderLookup.Provider> registries) {
        this.datapackProvider = packOutput.createPathProvider(PackOutput.Target.DATA_PACK, "handbook_books");
        this.assetsProvider = packOutput.createPathProvider(PackOutput.Target.RESOURCE_PACK, "handbook_books");
        this.modid = modid;
        this.locale = locale;
        this.registries = registries;
    }

    /**
     * Performs this provider's action.
     *
     * @param cache the cache
     * @return the completable future
     */
    @Override
    public @NonNull CompletableFuture<?> run(@NonNull CachedOutput cache) {
        return this.registries.thenCompose(provider -> {
            List<CompletableFuture<?>> list = new ArrayList<>();

            this.addBooks(book -> {
                list.add(saveBook(cache, book.toJson(), book.getId()));

                for (CategoryBuilder category : book.getCategories()) {
                    list.add(saveCategory(cache, category.toJson(), book.getId(), category.getId()));

                    for (EntryBuilder entry : category.getEntries()) {
                        list.add(saveEntry(cache, entry.toJson(), book.getId(), entry.getId()));
                    }
                }
                for (TemplateBuilder template : book.getTemplates()) {
                    list.add(saveTemplate(cache, template.toJson(), book.getId(), template.getId()));
                }
            }, provider);

            return CompletableFuture.allOf(list.toArray(CompletableFuture[]::new));
        });
    }

    protected abstract void addBooks(Consumer<BookBuilder> consumer, HolderLookup.Provider provider);

    private CompletableFuture<?> saveEntry(CachedOutput cache, JsonObject json, Identifier bookId, Identifier id) {
        String pathSuffix = bookId.getPath() + "/" + locale + "/entries/" + id.getPath();

        return DataProvider.saveStable(cache, json, assetsProvider.json(Identifier.fromNamespaceAndPath(bookId.getNamespace(), pathSuffix)));
    }

    private CompletableFuture<?> saveCategory(CachedOutput cache, JsonObject json, Identifier bookId, Identifier id) {
        String pathSuffix = bookId.getPath() + "/" + locale + "/categories/" + id.getPath();

        return DataProvider.saveStable(cache, json, assetsProvider.json(Identifier.fromNamespaceAndPath(bookId.getNamespace(), pathSuffix)));
    }

    private CompletableFuture<?> saveTemplate(CachedOutput cache, JsonObject json, Identifier bookId, Identifier id) {
        String pathSuffix = bookId.getPath() + "/" + locale + "/templates/" + id.getPath();

        return DataProvider.saveStable(cache, json, assetsProvider.json(Identifier.fromNamespaceAndPath(bookId.getNamespace(), pathSuffix)));
    }

    private CompletableFuture<?> saveBook(CachedOutput cache, JsonObject json, Identifier bookId) {
        String pathSuffix = bookId.getPath() + "/book";

        return DataProvider.saveStable(cache, json, datapackProvider.json(Identifier.fromNamespaceAndPath(bookId.getNamespace(), pathSuffix)));
    }

    public BookBuilder createBookBuilder(String id, String name, String landingText) {
        return new BookBuilder(modid, id, name, landingText);
    }

    /**
     * Creates a BookBuilder for a book with the given item.
     * The item is used both as the book item and to derive the book ID and model.
     */
    public BookBuilder createBookBuilder(Item item, String name, String landingText) {
        ItemStackTemplate bookItem = new ItemStackTemplate(item);
        Identifier itemId = BuiltInRegistries.ITEM.getKey(bookItem.item().value());

        return new BookBuilder(itemId, name, landingText)
            .setModel(itemId)
            .setCustomBookItem(bookItem);
    }

    /**
     * Gets a name for this provider, to use in logging.
     */
    @NonNull
    @Override
    public String getName() {
        return "Handbook Book Provider";
    }

}
