package technology.roughness.whitenoise.util;

import java.util.Map;

import io.netty.buffer.ByteBuf;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamEncoder;

public class WhiteNoiseByteBuf extends FriendlyByteBuf {

    public WhiteNoiseByteBuf(ByteBuf buf) {
        super(buf);
    }

    public <K, V> void writeMap(Map<K, V> map, StreamEncoder<? super FriendlyByteBuf, K> keyEncoder, StreamEncoder<? super FriendlyByteBuf, V> valueEncoder) {
        this.writeVarInt(map.size());
        map.forEach((k, v) -> {
            keyEncoder.encode(this, (K)k);
            valueEncoder.encode(this, (V)v);
        });
    }

}
