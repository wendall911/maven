/*
 * Derived from Spectrelib
 * https://github.com/illusivesoulworks/spectrelib
 * Copyright (C) 2022 Illusive Soulworks
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; you
 * may only use version 2.1 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library. If not, see <https://www.gnu.org/licenses/>.
 */

package technology.roughness.whitenoise.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import org.apache.commons.lang3.tuple.Pair;

import com.electronwill.nightconfig.core.CommentedConfig;
import com.electronwill.nightconfig.core.Config;
import com.electronwill.nightconfig.core.ConfigSpec;
import com.electronwill.nightconfig.core.EnumGetMethod;
import com.electronwill.nightconfig.core.InMemoryCommentedFormat;
import com.electronwill.nightconfig.core.UnmodifiableConfig;
import com.electronwill.nightconfig.core.file.FileConfig;

import com.google.common.base.Joiner;
import com.google.common.base.Preconditions;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.common.collect.ObjectArrays;

import technology.roughness.whitenoise.WhiteNoise;

import static com.electronwill.nightconfig.core.ConfigSpec.CorrectionAction.ADD;
import static com.electronwill.nightconfig.core.ConfigSpec.CorrectionAction.REMOVE;
import static com.electronwill.nightconfig.core.ConfigSpec.CorrectionAction.REPLACE;

import static technology.roughness.whitenoise.config.WhiteNoiseConfigLoader.CONFIG;

public class WhiteNoiseConfigSpec {

    private final Map<List<String>, String> levelComments;
    private final Map<List<String>, String> levelLocalizationKeys;
    private final UnmodifiableConfig values;
    private final UnmodifiableConfig spec;

    private Config config;
    private boolean isCorrecting = false;

    private static final Joiner LINE_JOINER = Joiner.on("\n");
    private static final Joiner DOT_JOINER = Joiner.on(".");
    private static final Splitter DOT_SPLITTER = Splitter.on(".");

    private static List<String> split(String path) {
        return Lists.newArrayList(DOT_SPLITTER.split(path));
    }

    private WhiteNoiseConfigSpec(UnmodifiableConfig spec, UnmodifiableConfig values,
            Map<List<String>, String> levelComments,
            Map<List<String>, String> levelLocalizationKeys) {
        this.spec = spec;
        this.values = values;
        this.levelComments = levelComments;
        this.levelLocalizationKeys = levelLocalizationKeys;
    }

    public String getLevelComment(List<String> path) {
        return this.levelComments.get(path);
    }

    public String getLevelLocalizationKey(List<String> path) {
        return this.levelLocalizationKeys.get(path);
    }

    public UnmodifiableConfig getValues() {
        return this.values;
    }

    public UnmodifiableConfig getSpec() {
        return this.spec;
    }

    public void setConfigData(final CommentedConfig configData, boolean create) {
        this.config = configData;
        boolean shouldLog = !create;

        if (configData != null && !isCorrect(configData)) {
            String configName =
                    configData instanceof FileConfig ? ((FileConfig) configData).getNioPath().toString() :
                            configData.toString();

            if (shouldLog) {
                WhiteNoise.LOGGER.warn(CONFIG, "Configuration file {} is not correct. Correcting",
                        configName);
            }
            this.correct(configData, shouldLog);

            if (configData instanceof FileConfig) {
                ((FileConfig) configData).save();
            }
        }

        this.afterReload();
    }

    public boolean isCorrecting() {
        return isCorrecting;
    }

    public boolean isLoaded() {
        return config != null;
    }

    public void save() {
        Preconditions.checkNotNull(config,
                "Cannot save config value without assigned Config object present");

        if (config instanceof FileConfig) {
            ((FileConfig) config).save();
        }
    }

    @SuppressWarnings("deprecation")
    public void afterReload() {
        this.resetCaches(getValues().valueMap().values());
    }

    @SuppressWarnings("deprecation")
    private void resetCaches(final Iterable<Object> configValues) {
        configValues.forEach(value -> {
            if (value instanceof final ConfigValue<?> configValue) {
                configValue.clearCache();
            }
            else if (value instanceof final Config innerConfig) {
                this.resetCaches(innerConfig.valueMap().values());
            }
        });
    }

    public synchronized boolean isCorrect(CommentedConfig config) {
        LinkedList<String> parentPath = new LinkedList<>();

        return this.correct(this.spec, config, null, parentPath,
            Collections.unmodifiableList(parentPath),
            (a, b, c, d) -> {}, null, true) == 0;
    }

    public synchronized void correct(CommentedConfig config, boolean shouldLog) {
        LinkedList<String> parentPath = new LinkedList<>();
        try {
            isCorrecting = true;
            Map<String, Object> defaultMap = null;

            if (config instanceof FileConfig fileConfig) {
                defaultMap = WhiteNoiseConfigTracker.INSTANCE.getDefaultConfigs()
                        .get(fileConfig.getNioPath().getFileName().toString().intern());
            }
            this.correct(this.spec, config, defaultMap, parentPath,
                Collections.unmodifiableList(parentPath),
                (action, path, incorrectValue, correctedValue) -> {
                    if (shouldLog) {
                        WhiteNoise.LOGGER.warn(CONFIG,
                            "Incorrect key {} was corrected from {} to its default, {}. {}",
                            DOT_JOINER.join(path), incorrectValue, correctedValue,
                            incorrectValue == correctedValue ? "This seems to be an error." : "");
                    }
                },
                (action, path, incorrectValue, correctedValue) -> {
                    if (shouldLog) {
                        WhiteNoise.LOGGER.debug(CONFIG,
                            "The comment on key {} does not match the spec. This may create a backup.",
                            DOT_JOINER.join(path));
                    }
                }, false);
        }
        finally {
            isCorrecting = false;
        }
    }

    @SuppressWarnings("deprecation")
    private int correct(UnmodifiableConfig spec, CommentedConfig config,
            @Nullable Map<String, Object> defaultValues,
            LinkedList<String> parentPath, List<String> parentPathUnmodifiable,
            ConfigSpec.CorrectionListener listener,
            ConfigSpec.CorrectionListener commentListener, boolean dryRun) {
        int count = 0;
        Map<String, Object> specMap = spec.valueMap();
        Map<String, Object> configMap = config.valueMap();

        for (Map.Entry<String, Object> specEntry : specMap.entrySet()) {
            final String key = specEntry.getKey();
            final Object specValue = specEntry.getValue();
            final Object configValue = configMap.get(key);
            final ConfigSpec.CorrectionAction action = configValue == null ? ADD : REPLACE;
            parentPath.addLast(key);

            if (specValue instanceof Config) {
                Map<String, Object> map =
                    defaultValues != null && defaultValues.get(key) instanceof Config defaultConfig ?
                        defaultConfig.valueMap() : null;

                if (configValue instanceof CommentedConfig) {
                    count += this.correct((Config) specValue, (CommentedConfig) configValue, map, parentPath,
                        parentPathUnmodifiable, listener, commentListener, dryRun);

                    if (count > 0 && dryRun) {
                        return count;
                    }
                }
                else if (dryRun) {
                    return 1;
                }
                else {
                    CommentedConfig newValue = config.createSubConfig();
                    configMap.put(key, newValue);
                    listener.onCorrect(action, parentPathUnmodifiable, configValue, newValue);
                    count++;
                    count +=
                        this.correct((Config) specValue, newValue, map, parentPath, parentPathUnmodifiable,
                            listener, commentListener, dryRun);
                }
                String newComment = levelComments.get(parentPath);
                String oldComment = config.getComment(key);

                if (!this.stringsMatchIgnoringNewlines(oldComment, newComment)) {
                    if (commentListener != null) {
                        commentListener.onCorrect(action, parentPathUnmodifiable, oldComment, newComment);
                    }
                    if (dryRun) {
                        return 1;
                    }
                    config.setComment(key, newComment);
                }
            }
            else {
                ValueSpec valueSpec = (ValueSpec) specValue;

                if (!valueSpec.test(configValue)) {

                    if (dryRun) {
                        return 1;
                    }
                    Object newValue;

                    if (defaultValues != null && defaultValues.containsKey(key)) {
                        newValue = defaultValues.get(key);

                        if (!valueSpec.test(newValue)) {
                            newValue = valueSpec.correct(configValue);
                        }
                    }
                    else {
                        newValue = valueSpec.correct(configValue);
                    }
                    configMap.put(key, newValue);
                    listener.onCorrect(action, parentPathUnmodifiable, configValue, newValue);
                    count++;
                }
                String oldComment = config.getComment(key);

                if (!this.stringsMatchIgnoringNewlines(oldComment, valueSpec.getComment())) {

                    if (commentListener != null) {
                        commentListener.onCorrect(action, parentPathUnmodifiable, oldComment,
                                valueSpec.getComment());
                    }

                    if (dryRun) {
                        return 1;
                    }
                    config.setComment(key, valueSpec.getComment());
                }
            }

            parentPath.removeLast();
        }

        for (Iterator<Map.Entry<String, Object>> ittr = configMap.entrySet().iterator();
                 ittr.hasNext(); ) {
            Map.Entry<String, Object> entry = ittr.next();

            if (!specMap.containsKey(entry.getKey())) {
                if (dryRun) {
                    return 1;
                }
                ittr.remove();
                parentPath.addLast(entry.getKey());
                listener.onCorrect(REMOVE, parentPathUnmodifiable, entry.getValue(), null);
                parentPath.removeLast();
                count++;
            }
        }

        return count;
    }

    private boolean stringsMatchIgnoringNewlines(@Nullable Object obj1, @Nullable Object obj2) {
        if (obj1 instanceof String string1 && obj2 instanceof String string2) {
            if (!string1.isEmpty() && !string2.isEmpty()) {
                return string1.replaceAll("\r\n", "\n").equals(string2.replaceAll("\r\n", "\n"));
            }
        }

        return Objects.equals(obj1, obj2);
    }

    public String getLevelTranslationKey(ArrayList<String> strings) {
        return this.levelLocalizationKeys.get(strings);
    }

    public static class Builder {

        private final Config storage =
                Config.of(LinkedHashMap::new, InMemoryCommentedFormat.withUniversalSupport());
        private final Map<List<String>, String> levelComments = new HashMap<>();
        private final Map<List<String>, String> levelTranslationKeys = new HashMap<>();
        private final List<String> currentPath = new ArrayList<>();
        private final List<ConfigValue<?>> values = new ArrayList<>();

        private BuilderContext context = new BuilderContext();
        private boolean hasInvalidComment = false;

        // Object
        public <T> ConfigValue<T> define(String path, T defaultValue) {
            return define(split(path), defaultValue);
        }

        public <T> ConfigValue<T> define(List<String> path, T defaultValue) {
            return define(path, defaultValue,
                    o -> o != null && defaultValue.getClass().isAssignableFrom(o.getClass()));
        }

        public <T> ConfigValue<T> define(String path, T defaultValue, Predicate<Object> validator) {
            return define(split(path), defaultValue, validator);
        }

        public <T> ConfigValue<T> define(List<String> path, T defaultValue,
                Predicate<Object> validator) {
            Objects.requireNonNull(defaultValue, "Default value can not be null");
            return define(path, () -> defaultValue, validator);
        }

        public <T> ConfigValue<T> define(String path, Supplier<T> defaultSupplier,
                Predicate<Object> validator) {
            return define(split(path), defaultSupplier, validator);
        }

        public <T> ConfigValue<T> define(List<String> path, Supplier<T> defaultSupplier,
                Predicate<Object> validator) {
            return define(path, defaultSupplier, validator, Object.class);
        }

        public <T> ConfigValue<T> define(List<String> path, Supplier<T> defaultSupplier,
                Predicate<Object> validator, Class<?> clazz) {
            context.setClazz(clazz);
            return define(path, new ValueSpec(defaultSupplier, validator, context), defaultSupplier);
        }

        public <T> ConfigValue<T> define(List<String> path, ValueSpec value,
                    Supplier<T> defaultSupplier) {
            if (!currentPath.isEmpty()) {
                List<String> tmp = new ArrayList<>(currentPath.size() + path.size());
                tmp.addAll(currentPath);
                tmp.addAll(path);
                path = tmp;
            }
            storage.set(path, value);
            checkComment(path);
            context = new BuilderContext();
            return new ConfigValue<>(this, path, defaultSupplier);
        }

        public <T, I> TransformableValue<T, I> define(String path, Supplier<T> defaultSupplier,
                Predicate<Object> validator,
                Function<T, I> transformer) {
            return define(split(path), defaultSupplier, validator, transformer);
        }

        public <T, I> TransformableValue<T, I> define(List<String> path, Supplier<T> defaultSupplier,
                Predicate<Object> validator,
                Function<T, I> transformer) {
            return define(path, defaultSupplier, validator, Object.class, transformer);
        }

        public <T, I> TransformableValue<T, I> define(List<String> path, Supplier<T> defaultSupplier,
                Predicate<Object> validator, Class<?> clazz,
                Function<T, I> transformer) {
            context.setClazz(clazz);
            return define(path, new ValueSpec(defaultSupplier, validator, context), defaultSupplier,
                    transformer);
        }

        public <T, I> TransformableValue<T, I> define(List<String> path, ValueSpec value,
                Supplier<T> defaultSupplier, Function<T, I> transformer) {
            if (!currentPath.isEmpty()) {
                List<String> tmp = new ArrayList<>(currentPath.size() + path.size());
                tmp.addAll(currentPath);
                tmp.addAll(path);
                path = tmp;
            }

            storage.set(path, value);
            checkComment(path);
            context = new BuilderContext();

            return new TransformableValue<>(this, path, defaultSupplier, transformer);
        }

        public <V extends Comparable<? super V>> ConfigValue<V> defineInRange(String path,
                V defaultValue, V min, V max, Class<V> clazz) {
            return defineInRange(split(path), defaultValue, min, max, clazz);
        }

        public <V extends Comparable<? super V>> ConfigValue<V> defineInRange(List<String> path,
                V defaultValue, V min, V max, Class<V> clazz) {
            return defineInRange(path, (Supplier<V>) () -> defaultValue, min, max, clazz);
        }

        public <V extends Comparable<? super V>> ConfigValue<V> defineInRange(String path,
                Supplier<V> defaultSupplier, V min, V max, Class<V> clazz) {
            return defineInRange(split(path), defaultSupplier, min, max, clazz);
        }

        public <V extends Comparable<? super V>> ConfigValue<V> defineInRange(List<String> path,
                    Supplier<V> defaultSupplier, V min, V max, Class<V> clazz) {
            Range<V> range = new Range<>(clazz, min, max);

            context.setRange(range);
            context.setComment(ObjectArrays.concat(context.getComment(), "Range: " + range.toString()));

            if (min.compareTo(max) > 0) {
                throw new IllegalArgumentException("Range min most be less then max.");
            }

            return define(path, defaultSupplier, range);
        }

        public <T> ConfigValue<T> defineInList(String path, T defaultValue,
                Collection<? extends T> acceptableValues) {
            return defineInList(split(path), defaultValue, acceptableValues);
        }

        public <T> ConfigValue<T> defineInList(String path, Supplier<T> defaultSupplier,
                Collection<? extends T> acceptableValues) {
            return defineInList(split(path), defaultSupplier, acceptableValues);
        }

        public <T> ConfigValue<T> defineInList(List<String> path, T defaultValue,
                Collection<? extends T> acceptableValues) {
            return defineInList(path, () -> defaultValue, acceptableValues);
        }

        public <T> ConfigValue<T> defineInList(List<String> path, Supplier<T> defaultSupplier,
                Collection<? extends T> acceptableValues) {
            return define(path, defaultSupplier, acceptableValues::contains);
        }

        public <T> ConfigValue<List<? extends T>> defineList(String path,
                List<? extends T> defaultValue, Predicate<Object> elementValidator) {
            return defineList(split(path), defaultValue, elementValidator);
        }

        public <T> ConfigValue<List<? extends T>> defineList(String path,
                Supplier<List<? extends T>> defaultSupplier,
                Predicate<Object> elementValidator) {
            return defineList(split(path), defaultSupplier, elementValidator);
        }

        public <T> ConfigValue<List<? extends T>> defineList(List<String> path,
                List<? extends T> defaultValue,
                Predicate<Object> elementValidator) {
            return defineList(path, () -> defaultValue, elementValidator);
        }

        public <T> ConfigValue<List<? extends T>> defineList(List<String> path,
                Supplier<List<? extends T>> defaultSupplier,
                Predicate<Object> elementValidator) {
            context.setClazz(List.class);

            return define(path, new ValueSpec(defaultSupplier,
                    x -> x instanceof List && ((List<?>) x).stream().allMatch(elementValidator),
                    context) {
                @Override
                public Object correct(Object value) {
                    if (!(value instanceof List) || ((List<?>) value).isEmpty()) {
                        WhiteNoise.LOGGER.debug(CONFIG,
                            "List on key {} is deemed to need correction. It is null, not a list, or an empty list. Modders, consider defineListAllowEmpty?",
                            path.get(path.size() - 1));

                        return getDefault();
                    }

                    List<?> list = Lists.newArrayList((List<?>) value);
                    list.removeIf(elementValidator.negate());

                    if (list.isEmpty()) {
                        WhiteNoise.LOGGER.debug(CONFIG,
                            "List on key {} is deemed to need correction. It failed validation.",
                            path.get(path.size() - 1));

                        return getDefault();
                    }

                    return list;
                }
            }, defaultSupplier);
        }

        public <T> ConfigValue<List<? extends T>> defineListAllowEmpty(List<String> path,
                Supplier<List<? extends T>> defaultSupplier, Predicate<Object> elementValidator) {
            context.setClazz(List.class);

            return define(path, new ValueSpec(defaultSupplier,
                    x -> x instanceof List && ((List<?>) x).stream().allMatch(elementValidator),
                    context) {
                @Override
                public Object correct(Object value) {
                    if (!(value instanceof List)) {
                        WhiteNoise.LOGGER.debug(CONFIG,
                                "List on key {} is deemed to need correction, as it is null or not a list.",
                                path.get(path.size() - 1));
                        return getDefault();
                    }

                    List<?> list = Lists.newArrayList((List<?>) value);
                    list.removeIf(elementValidator.negate());

                    if (list.isEmpty()) {
                        WhiteNoise.LOGGER.debug(CONFIG,
                                "List on key {} is deemed to need correction. It failed validation.",
                                path.get(path.size() - 1));
                        return getDefault();
                    }

                    return list;
                }
            }, defaultSupplier);
        }

        public <T, I> TransformableValue<List<? extends T>, I> defineList(String path,
                List<? extends T> defaultValue, Predicate<Object> elementValidator,
                Function<List<? extends T>, I> transformer) {
            return defineList(split(path), defaultValue, elementValidator, transformer);
        }

        public <T, I> TransformableValue<List<? extends T>, I> defineList(String path,
                Supplier<List<? extends T>> defaultSupplier, Predicate<Object> elementValidator,
                Function<List<? extends T>, I> transformer) {
            return defineList(split(path), defaultSupplier, elementValidator, transformer);
        }

        public <T, I> TransformableValue<List<? extends T>, I> defineList(List<String> path,
                List<? extends T> defaultValue, Predicate<Object> elementValidator,
                Function<List<? extends T>, I> transformer) {
            return defineList(path, () -> defaultValue, elementValidator, transformer);
        }

        public <T, I> TransformableValue<List<? extends T>, I> defineList(List<String> path,
                Supplier<List<? extends T>> defaultSupplier, Predicate<Object> elementValidator,
                Function<List<? extends T>, I> transformer) {
            context.setClazz(List.class);

            return define(path, new ValueSpec(defaultSupplier,
                    x -> x instanceof List && ((List<?>) x).stream().allMatch(elementValidator), context) {
                @Override
                public Object correct(Object value) {
                    if (!(value instanceof List) || ((List<?>) value).isEmpty()) {
                        WhiteNoise.LOGGER.debug(CONFIG,
                            "List on key {} is deemed to need correction. It is null, not a list, or an empty list. Modders, consider defineListAllowEmpty?",
                            path.get(path.size() - 1));

                        return getDefault();
                    }

                    List<?> list = Lists.newArrayList((List<?>) value);
                    list.removeIf(elementValidator.negate());

                    if (list.isEmpty()) {
                        WhiteNoise.LOGGER.debug(CONFIG,
                            "List on key {} is deemed to need correction. It failed validation.",
                            path.get(path.size() - 1));

                        return getDefault();
                    }

                    return list;
                }
            }, defaultSupplier, transformer);
        }

        public <T, I> TransformableValue<List<? extends T>, I> defineListAllowEmpty(List<String> path,
                Supplier<List<? extends T>> defaultSupplier, Predicate<Object> elementValidator,
                Function<List<? extends T>, I> transformer) {
            context.setClazz(List.class);

            return define(path, new ValueSpec(defaultSupplier,
                    x -> x instanceof List && ((List<?>) x).stream().allMatch(elementValidator), context) {
                @Override
                public Object correct(Object value) {
                    if (!(value instanceof List)) {
                        WhiteNoise.LOGGER.debug(CONFIG,
                            "List on key {} is deemed to need correction, as it is null or not a list.",
                            path.get(path.size() - 1));

                        return getDefault();
                    }

                    List<?> list = Lists.newArrayList((List<?>) value);
                    list.removeIf(elementValidator.negate());

                    if (list.isEmpty()) {
                        WhiteNoise.LOGGER.debug(CONFIG,
                            "List on key {} is deemed to need correction. It failed validation.",
                            path.get(path.size() - 1));

                        return getDefault();
                    }

                    return list;
                }
            }, defaultSupplier, transformer);
        }

        //Enum
        public <V extends Enum<V>> EnumValue<V> defineEnum(String path, V defaultValue) {
            return defineEnum(split(path), defaultValue);
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(String path, V defaultValue,
                EnumGetMethod converter) {
            return defineEnum(split(path), defaultValue, converter);
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(List<String> path, V defaultValue) {
            return defineEnum(path, defaultValue, defaultValue.getDeclaringClass().getEnumConstants());
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(List<String> path, V defaultValue,
                EnumGetMethod converter) {
            return defineEnum(path, defaultValue, converter,
                    defaultValue.getDeclaringClass().getEnumConstants());
        }

        @SuppressWarnings("unchecked")
        public <V extends Enum<V>> EnumValue<V> defineEnum(String path, V defaultValue,
                V... acceptableValues) {
            return defineEnum(split(path), defaultValue, acceptableValues);
        }

        @SuppressWarnings("unchecked")
        public <V extends Enum<V>> EnumValue<V> defineEnum(String path, V defaultValue,
                EnumGetMethod converter, V... acceptableValues) {
            return defineEnum(split(path), defaultValue, converter, acceptableValues);
        }

        @SuppressWarnings("unchecked")
        public <V extends Enum<V>> EnumValue<V> defineEnum(List<String> path, V defaultValue,
                V... acceptableValues) {
            return defineEnum(path, defaultValue, Arrays.asList(acceptableValues));
        }

        @SuppressWarnings("unchecked")
        public <V extends Enum<V>> EnumValue<V> defineEnum(List<String> path, V defaultValue,
                EnumGetMethod converter, V... acceptableValues) {
            return defineEnum(path, defaultValue, converter, Arrays.asList(acceptableValues));
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(String path, V defaultValue,
                Collection<V> acceptableValues) {
            return defineEnum(split(path), defaultValue, acceptableValues);
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(String path, V defaultValue,
                EnumGetMethod converter, Collection<V> acceptableValues) {
            return defineEnum(split(path), defaultValue, converter, acceptableValues);
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(List<String> path, V defaultValue,
                Collection<V> acceptableValues) {
            return defineEnum(path, defaultValue, EnumGetMethod.NAME_IGNORECASE, acceptableValues);
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(List<String> path, V defaultValue,
                EnumGetMethod converter, Collection<V> acceptableValues) {
            return defineEnum(path, defaultValue, converter, obj -> {
                if (obj instanceof Enum) {
                    return acceptableValues.contains(obj);
                }
                if (obj == null) {
                    return false;
                }
                try {
                    return acceptableValues.contains(converter.get(obj, defaultValue.getDeclaringClass()));
                }
                catch (IllegalArgumentException | ClassCastException e) {
                    return false;
                }
            });
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(String path, V defaultValue,
                Predicate<Object> validator) {
            return defineEnum(split(path), defaultValue, validator);
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(String path, V defaultValue,
                EnumGetMethod converter, Predicate<Object> validator) {
            return defineEnum(split(path), defaultValue, converter, validator);
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(List<String> path, V defaultValue,
                Predicate<Object> validator) {
            return defineEnum(path, () -> defaultValue, validator, defaultValue.getDeclaringClass());
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(List<String> path, V defaultValue,
                EnumGetMethod converter, Predicate<Object> validator) {
            return defineEnum(path, () -> defaultValue, converter, validator,
                    defaultValue.getDeclaringClass());
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(String path, Supplier<V> defaultSupplier,
                Predicate<Object> validator, Class<V> clazz) {
            return defineEnum(split(path), defaultSupplier, validator, clazz);
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(String path, Supplier<V> defaultSupplier,
                EnumGetMethod converter, Predicate<Object> validator, Class<V> clazz) {
            return defineEnum(split(path), defaultSupplier, converter, validator, clazz);
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(List<String> path,
                Supplier<V> defaultSupplier, Predicate<Object> validator, Class<V> clazz) {
            return defineEnum(path, defaultSupplier, EnumGetMethod.NAME_IGNORECASE, validator, clazz);
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(List<String> path,
                Supplier<V> defaultSupplier, EnumGetMethod converter, Predicate<Object> validator,
                Class<V> clazz) {
            context.setClazz(clazz);
            V[] allowedValues = clazz.getEnumConstants();
            context.setComment(ObjectArrays.concat(context.getComment(), "Allowed Values: " +
                    Arrays.stream(allowedValues).filter(validator).map(Enum::name).collect(
                            Collectors.joining(", "))));

            return new EnumValue<V>(this, define(path, new ValueSpec(defaultSupplier, validator, context),
                    defaultSupplier).getPath(), defaultSupplier, converter, clazz);
        }

        //boolean
        public BooleanValue define(String path, boolean defaultValue) {
            return define(split(path), defaultValue);
        }

        public BooleanValue define(List<String> path, boolean defaultValue) {
            return define(path, (Supplier<Boolean>) () -> defaultValue);
        }

        public BooleanValue define(String path, Supplier<Boolean> defaultSupplier) {
            return define(split(path), defaultSupplier);
        }

        public BooleanValue define(List<String> path, Supplier<Boolean> defaultSupplier) {
            return new BooleanValue(this, define(path, defaultSupplier, o -> {
                if (o instanceof String) {
                    return ((String) o).equalsIgnoreCase("true") || ((String) o).equalsIgnoreCase("false");
                }
                return o instanceof Boolean;
            }, Boolean.class).getPath(), defaultSupplier);
        }

        //Double
        public DoubleValue defineInRange(String path, double defaultValue, double min, double max) {
            return defineInRange(split(path), defaultValue, min, max);
        }

        public DoubleValue defineInRange(List<String> path, double defaultValue, double min,
                double max) {
            return defineInRange(path, (Supplier<Double>) () -> defaultValue, min, max);
        }

        public DoubleValue defineInRange(String path, Supplier<Double> defaultSupplier, double min,
                                                                         double max) {
            return defineInRange(split(path), defaultSupplier, min, max);
        }

        public DoubleValue defineInRange(List<String> path, Supplier<Double> defaultSupplier,
                double min, double max) {
            return new DoubleValue(this,
                    defineInRange(path, defaultSupplier, min, max, Double.class).getPath(), defaultSupplier);
        }

        //Ints
        public IntValue defineInRange(String path, int defaultValue, int min, int max) {
            return defineInRange(split(path), defaultValue, min, max);
        }

        public IntValue defineInRange(List<String> path, int defaultValue, int min, int max) {
            return defineInRange(path, (Supplier<Integer>) () -> defaultValue, min, max);
        }

        public IntValue defineInRange(String path, Supplier<Integer> defaultSupplier, int min,
                int max) {
            return defineInRange(split(path), defaultSupplier, min, max);
        }

        public IntValue defineInRange(List<String> path, Supplier<Integer> defaultSupplier, int min,
                int max) {
            return new IntValue(this,
                    defineInRange(path, defaultSupplier, min, max, Integer.class).getPath(), defaultSupplier);
        }

        //Longs
        public LongValue defineInRange(String path, long defaultValue, long min, long max) {
            return defineInRange(split(path), defaultValue, min, max);
        }

        public LongValue defineInRange(List<String> path, long defaultValue, long min, long max) {
            return defineInRange(path, (Supplier<Long>) () -> defaultValue, min, max);
        }

        public LongValue defineInRange(String path, Supplier<Long> defaultSupplier, long min,
                long max) {
            return defineInRange(split(path), defaultSupplier, min, max);
        }

        public LongValue defineInRange(List<String> path, Supplier<Long> defaultSupplier, long min,
                long max) {
            return new LongValue(this,
                    defineInRange(path, defaultSupplier, min, max, Long.class).getPath(), defaultSupplier);
        }

        public Builder comment(String comment) {
            hasInvalidComment = comment == null || comment.isEmpty();

            if (hasInvalidComment) {
                comment = "No comment";
            }

            context.setComment(comment);

            return this;
        }

        public Builder comment(String... comment) {
            hasInvalidComment =
                    comment == null || comment.length < 1 || (comment.length == 1 && comment[0].isEmpty());

            if (hasInvalidComment) {
                comment = new String[] {"No comment"};
            }

            context.setComment(comment);

            return this;
        }

        public Builder translation(String translationKey) {
            context.setTranslationKey(translationKey);
            return this;
        }

        public Builder worldRestart() {
            context.worldRestart();
            return this;
        }

        public Builder clientRestart() {
            context.clientRestart();
            return this;
        }

        public Builder push(String path) {
            return push(split(path));
        }

        public Builder push(List<String> path) {
            currentPath.addAll(path);
            checkComment(currentPath);

            if (context.hasComment()) {
                levelComments.put(new ArrayList<String>(currentPath), context.buildComment());
                context.setComment(); // Set to empty
            }

            if (context.getTranslationKey() != null) {
                levelTranslationKeys.put(new ArrayList<String>(currentPath), context.getTranslationKey());
                context.setTranslationKey(null);
            }

            context.ensureEmpty();

            return this;
        }

        public Builder pop() {
            return pop(1);
        }

        public Builder pop(int count) {
            if (count > currentPath.size()) {
                throw new IllegalArgumentException(
                        "Attempted to pop " + count + " elements when we only had: " + currentPath);
            }
            for (int x = 0; x < count; x++) {
                currentPath.remove(currentPath.size() - 1);
            }

            return this;
        }

        public <T> Pair<T, WhiteNoiseConfigSpec> configure(Function<Builder, T> consumer) {
            T o = consumer.apply(this);

            return Pair.of(o, this.build());
        }

        @SuppressWarnings("deprecation")
        public WhiteNoiseConfigSpec build() {
            context.ensureEmpty();

            Config valueCfg = Config.of(Config.getDefaultMapCreator(true, true),
                    InMemoryCommentedFormat.withSupport(ConfigValue.class::isAssignableFrom));
            values.forEach(v -> valueCfg.set(v.getPath(), v));

            WhiteNoiseConfigSpec ret =
                    new WhiteNoiseConfigSpec(storage, valueCfg, levelComments, levelTranslationKeys);
            values.forEach(v -> v.spec = ret);

            return ret;
        }

        private void checkComment(List<String> path) {
            if (hasInvalidComment) {
                hasInvalidComment = false;
                WhiteNoise.LOGGER.error(CONFIG,
                        "Null comment for config option {}, this is invalid and may be disallowed in the future.",
                        DOT_JOINER.join(path));
            }
        }

        public interface BuilderConsumer {
            void accept(Builder builder);
        }

    }

    private static class BuilderContext {

        private @NotNull String[] comment = new String[0];
        private String langKey;
        private Range<?> range;
        private boolean worldRestart = false;
        private boolean clientRestart = false;
        private Class<?> clazz;

        public void setComment(String... value) {
            validate(value == null, "Passed in null value for comment");
            this.comment = value;
        }

        public boolean hasComment() {
            return this.comment.length > 0;
        }

        public String[] getComment() {
            return this.comment;
        }

        public String buildComment() {
            return LINE_JOINER.join(comment);
        }

        public void setTranslationKey(String value) {
            this.langKey = value;
        }

        public String getTranslationKey() {
            return this.langKey;
        }

        public <V extends Comparable<? super V>> void setRange(Range<V> value) {
            this.range = value;
            this.setClazz(value.getClazz());
        }

        @SuppressWarnings("unchecked")
        public <V extends Comparable<? super V>> Range<V> getRange() {
            return (Range<V>) this.range;
        }

        public void worldRestart() {
            this.worldRestart = true;
        }

        public boolean needsWorldRestart() {
            return this.worldRestart;
        }

        public void clientRestart() {
            this.clientRestart = true;
        }

        public boolean needsClientRestart() {
            return this.clientRestart;
        }

        public void setClazz(Class<?> clazz) {
            this.clazz = clazz;
        }

        public Class<?> getClazz() {
            return this.clazz;
        }

        public void ensureEmpty() {
            validate(hasComment(), "Non-empty comment when empty expected");
            validate(langKey, "Non-null translation key when null expected");
            validate(range, "Non-null range when null expected");
            validate(worldRestart, "Dangling world restart value set to true");
            validate(clientRestart, "Dangling client restart value set to true");
        }

        private void validate(Object value, String message) {
            if (value != null) {
                throw new IllegalStateException(message);
            }
        }

        private void validate(boolean value, String message) {
            if (value) {
                throw new IllegalStateException(message);
            }
        }

    }

    @SuppressWarnings("unused")
    public static class Range<V extends Comparable<? super V>> implements Predicate<Object> {
        
        private final Class<? extends V> clazz;
        private final V min;
        private final V max;

        private Range(Class<V> clazz, V min, V max) {
            this.clazz = clazz;
            this.min = min;
            this.max = max;
        }

        public static Range<Integer> of(int minValue, int maxValue) {
            return new Range<>(Integer.class, minValue, maxValue);
        }

        public Class<? extends V> getClazz() {
            return clazz;
        }

        public V getMin() {
            return min;
        }

        public V getMax() {
            return max;
        }

        private boolean isNumber(Object other) {
            return Number.class.isAssignableFrom(clazz) && other instanceof Number;
        }

        @Override
        public boolean test(Object t) {
            if (isNumber(t)) {
                Number n = (Number) t;
                boolean result = ((Number) min).doubleValue() <= n.doubleValue() &&
                        n.doubleValue() <= ((Number) max).doubleValue();

                if (!result) {
                    WhiteNoise.LOGGER.debug(CONFIG, "Range value {} is not within its bounds {}-{}",
                            n.doubleValue(),
                            ((Number) min).doubleValue(), ((Number) max).doubleValue());
                }

                return result;
            }

            if (!clazz.isInstance(t)) {
                return false;
            }

            V c = clazz.cast(t);

            boolean result = c.compareTo(min) >= 0 && c.compareTo(max) <= 0;

            if (!result) {
                WhiteNoise.LOGGER.debug(CONFIG, "Range value {} is not within its bounds {}-{}", c, min,
                        max);
            }

            return result;
        }

        public Object correct(Object value, Object def) {
            if (isNumber(value)) {
                Number n = (Number) value;

                return n.doubleValue() < ((Number) min).doubleValue() ? min :
                        n.doubleValue() > ((Number) max).doubleValue() ? max : value;
            }

            if (!clazz.isInstance(value)) {
                return def;
            }

            V c = clazz.cast(value);

            return c.compareTo(min) < 0 ? min : c.compareTo(max) > 0 ? max : value;
        }

        @Override
        public String toString() {
            if (clazz == Integer.class) {
                if (max.equals(Integer.MAX_VALUE)) {
                    return "> " + min;
                }
                else if (min.equals(Integer.MIN_VALUE)) {
                    return "< " + max;
                }
            }

            return min + " ~ " + max;
        }

    }

    public static class ValueSpec {

        private final String comment;
        private final String langKey;
        private final Range<?> range;
        private final boolean worldRestart;
        private final Class<?> clazz;
        private final Supplier<?> supplier;
        private final Predicate<Object> validator;
        private Object _default = null;

        private ValueSpec(Supplier<?> supplier, Predicate<Object> validator, BuilderContext context) {
            Objects.requireNonNull(supplier, "Default supplier can not be null");
            Objects.requireNonNull(validator, "Validator can not be null");
            this.comment = context.hasComment() ? context.buildComment() : null;
            this.langKey = context.getTranslationKey();
            this.range = context.getRange();
            this.worldRestart = context.needsWorldRestart();
            this.clazz = context.getClazz();
            this.supplier = supplier;
            this.validator = validator;
        }

        public String getComment() {
            return comment;
        }

        public String getLocalizationKey() {
            return langKey;
        }

        @SuppressWarnings("unchecked")
        public <V extends Comparable<? super V>> Range<V> getRange() {
            return (Range<V>) this.range;
        }

        public boolean needsWorldRestart() {
            return this.worldRestart;
        }

        public Class<?> getClazz() {
            return this.clazz;
        }

        public boolean test(Object value) {
            return validator.test(value);
        }

        public Object correct(Object value) {
            return range == null ? getDefault() : range.correct(value, getDefault());
        }

        public Object getDefault() {
            if (_default == null) {
                _default = supplier.get();
            }

            return _default;
        }

        public String getTranslationKey() {
            return langKey;
        }

        public RestartType restartType() {
            if (needsWorldRestart()) {
                return RestartType.WORLD;
            }

            return RestartType.NONE;
        }

        /*
         * Used in the UI to add new elements to a list config.
         * Here we are assuming that if the supplier returns a List, it is a list of strings.
         */
        public Supplier<?> getNewElementSupplier() {
            if (supplier.get() instanceof List<?>) {;
                    return () -> "";
            }

            return supplier;
        }

        public Range<Integer> getSizeRange() {
            return Range.of(0, Integer.MAX_VALUE);
        }

    }

    public static class ListValueSpec extends ValueSpec {
        private static final Range<Integer> MAX_ELEMENTS = Range.of(0, Integer.MAX_VALUE);
        private static final Range<Integer> NON_EMPTY = Range.of(1, Integer.MAX_VALUE);

        @Nullable
        private final Supplier<?> newElementSupplier;
        @Nullable
        private final Range<Integer> sizeRange;
        private final Predicate<Object> elementValidator;

        private ListValueSpec(Supplier<?> supplier, @Nullable Supplier<?> newElementSupplier, Predicate<Object> listValidator, Predicate<Object> elementValidator, BuilderContext context, @Nullable Range<Integer> sizeRange) {
            super(supplier, listValidator, context);
            Objects.requireNonNull(elementValidator, "ElementValidator can not be null");

            this.newElementSupplier = newElementSupplier;
            this.elementValidator = elementValidator;
            this.sizeRange = Objects.requireNonNullElse(sizeRange, MAX_ELEMENTS);
        }

        /**
         * Creates a new empty element that can be added to the end of the list or null if the list doesn't support adding elements.<p>
         *
         * The element does not need to validate with either {@link #test(Object)} or {@link #testElement(Object)}, but it should give the user a good starting point for their edit.<p>
         *
         * Only used by the UI!
         */
        @Nullable
        public Supplier<?> getNewElementSupplier() {
            return newElementSupplier;
        }

        /**
         * Determines if a given object can be part of the list.<p>
         *
         * Note that the list-level validator overrules this.<p>
         *
         * Only used by the UI!
         */
        public boolean testElement(Object value) {
            return elementValidator.test(value);
        }

        /**
         * The allowable range of the size of the list.
         * <p>
         * Note that the validator overrules this.
         * <p>
         * Only used by the UI!
         */
        public @Nullable Range<Integer> getSizeRange() {
            return sizeRange;
        }
    }

    public static class ConfigValue<T> implements Supplier<T> {

        private final Builder parent;
        private final List<String> path;
        private final Supplier<T> defaultSupplier;

        private T cachedValue = null;
        private WhiteNoiseConfigSpec spec;

        ConfigValue(Builder parent, List<String> path, Supplier<T> defaultSupplier) {
            this.parent = parent;
            this.path = path;
            this.defaultSupplier = defaultSupplier;
            this.parent.values.add(this);
        }

        public List<String> getPath() {
            return Lists.newArrayList(path);
        }

        @Override
        public T get() {
            Preconditions.checkNotNull(spec, "Cannot get config value before spec is built");
            Preconditions.checkState(spec.config != null,
                    "Cannot get config value before config is loaded");

            if (cachedValue == null) {
                cachedValue = getRaw(spec.config, path, defaultSupplier);
            }
            return cachedValue;
        }

        protected T getRaw(Config config, List<String> path, Supplier<T> defaultSupplier) {
            return config.getOrElse(path, defaultSupplier);
        }

        /*
         * Gets the raw value from the config, bypassing any caching. Used for editing the value.
         */
        public T getRaw() {
            return getRaw(spec.config, path, defaultSupplier);
        }

        public T getDefault() {
            return defaultSupplier.get();
        }

        public Builder next() {
            return parent;
        }

        public void save() {
            Preconditions.checkNotNull(spec, "Cannot save config value before spec is built");
            Preconditions.checkNotNull(spec.config,
                    "Cannot save config value without assigned Config object present");
            spec.save();
        }

        public void set(T value) {
            Preconditions.checkNotNull(spec, "Cannot set config value before spec is built");
            Preconditions.checkNotNull(spec.config,
                    "Cannot set config value without assigned Config object present");
            spec.config.set(path, value);
            this.cachedValue = value;
        }

        public void clearCache() {
            this.cachedValue = null;
        }

    }

    public static class TransformableValue<T, I> extends ConfigValue<T> {

        private final Function<T, I> transformer;

        private I transformedValue = null;

        TransformableValue(Builder parent, List<String> path, Supplier<T> defaultSupplier,
                                             Function<T, I> transformer) {
            super(parent, path, defaultSupplier);
            this.transformer = transformer;
        }

        public I getTransformed() {
            T val = this.get();

            if (transformedValue == null) {
                transformedValue = transformer.apply(val);
            }
            return transformedValue;
        }

        public void clearCache() {
            super.clearCache();
            transformedValue = null;
        }

    }

    public static class BooleanValue extends ConfigValue<Boolean> {

        BooleanValue(Builder parent, List<String> path, Supplier<Boolean> defaultSupplier) {
            super(parent, path, defaultSupplier);
        }
    }

    public static class IntValue extends ConfigValue<Integer> {

        IntValue(Builder parent, List<String> path, Supplier<Integer> defaultSupplier) {
            super(parent, path, defaultSupplier);
        }

        @Override
        protected Integer getRaw(Config config, List<String> path, Supplier<Integer> defaultSupplier) {
            return config.getIntOrElse(path, defaultSupplier::get);
        }

    }

    public static class LongValue extends ConfigValue<Long> {

        LongValue(Builder parent, List<String> path, Supplier<Long> defaultSupplier) {
            super(parent, path, defaultSupplier);
        }

        @Override
        protected Long getRaw(Config config, List<String> path, Supplier<Long> defaultSupplier) {
            return config.getLongOrElse(path, defaultSupplier::get);
        }

    }

    public static class DoubleValue extends ConfigValue<Double> {

        DoubleValue(Builder parent, List<String> path, Supplier<Double> defaultSupplier) {
            super(parent, path, defaultSupplier);
        }

        @Override
        protected Double getRaw(Config config, List<String> path, Supplier<Double> defaultSupplier) {
            Number num = config.get(path);
            return num == null ? defaultSupplier.get() : num.doubleValue();
        }

    }

    public static class EnumValue<T extends Enum<T>> extends ConfigValue<T> {

        private final EnumGetMethod converter;
        private final Class<T> clazz;

        EnumValue(Builder parent, List<String> path, Supplier<T> defaultSupplier,
                            EnumGetMethod converter, Class<T> clazz) {
            super(parent, path, defaultSupplier);
            this.converter = converter;
            this.clazz = clazz;
        }

        public Class<T> getEnumClass() {
            return this.clazz;
        }

        @Override
        protected T getRaw(Config config, List<String> path, Supplier<T> defaultSupplier) {
            return config.getEnumOrElse(path, clazz, converter, defaultSupplier);
        }

    }

    public enum RestartType {
        NONE,
        WORLD,
        GAME(WhiteNoiseConfig.Type.SERVER);

        private final Set<WhiteNoiseConfig.Type> invalidTypes;

        RestartType(WhiteNoiseConfig.Type... invalidTypes) {
            this.invalidTypes = EnumSet.noneOf(WhiteNoiseConfig.Type.class);
            this.invalidTypes.addAll(Arrays.asList(invalidTypes));
        }

        private boolean isValid(WhiteNoiseConfig.Type type) {
            return !invalidTypes.contains(type);
        }

        public RestartType with(RestartType other) {
            return other == NONE ? this : (other == GAME || this == GAME) ? GAME : WORLD;
        }
    }

}

