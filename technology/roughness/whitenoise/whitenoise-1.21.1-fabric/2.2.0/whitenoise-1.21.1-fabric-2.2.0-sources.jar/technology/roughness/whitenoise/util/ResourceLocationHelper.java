package technology.roughness.whitenoise.util;

import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ResourceLocationHelper {

    public static class_2960 loc(String modid, String path) {
        return class_2960.method_60655(modid, path);
    }

    public static class_2960 parse(String path) {
        return class_2960.method_60654(path);
    }

    public static class_2960 tryParse(String path) {
        return class_2960.method_12829(path);
    }

    public static class_2960 getItemStackId(class_1799 stack) {
        return class_7923.field_41178.method_10221(stack.method_7909());
    }

    public static class_2960 getBlockId(class_2248 block) {
        return class_7923.field_41175.method_10221(block);
    }

    public static String getModId(class_1799 stack) {
        return getItemStackId(stack).method_12836();
    }

    public static String getModId(class_2248 block) {
        return getBlockId(block).method_12836();
    }

}
