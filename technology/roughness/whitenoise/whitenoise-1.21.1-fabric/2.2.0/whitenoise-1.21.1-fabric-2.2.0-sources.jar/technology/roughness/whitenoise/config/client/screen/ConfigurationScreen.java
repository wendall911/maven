/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 * Based on https://github.com/neoforged/NeoForge/blob/1.21.x/src/client/java/net/neoforged/neoforge/client/gui/ConfigurationScreen.java
 * Based on commit: faa6bf4578c9809a6788fee355651c558094a462 0ct 3, 2025
 * Migrating to Minecraft 1.21.9+ may require changes to this file to stay in sync with NeoForge bug fixes.
 */

package technology.roughness.whitenoise.config.client.screen;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_424;
import net.minecraft.class_4325;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_4667;
import net.minecraft.class_500;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_5676;
import net.minecraft.class_6382;
import net.minecraft.class_642;
import net.minecraft.class_7172;
import net.minecraft.class_7842;
import net.minecraft.class_7919;
import net.minecraft.class_8667;
import net.minecraft.class_9017;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.electronwill.nightconfig.core.ConfigSpec;
import com.electronwill.nightconfig.core.UnmodifiableConfig;
import com.electronwill.nightconfig.core.UnmodifiableConfig.Entry;

import com.google.common.collect.ImmutableList;

import com.mojang.datafixers.util.Function4;
import com.mojang.serialization.Codec;

import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import technology.roughness.whitenoise.common.WhiteNoiseModContainer;
import technology.roughness.whitenoise.config.WhiteNoiseConfig;
import technology.roughness.whitenoise.config.WhiteNoiseConfig.Type;
import technology.roughness.whitenoise.config.WhiteNoiseConfigSpec;
import technology.roughness.whitenoise.config.WhiteNoiseConfigSpec.ConfigValue;
import technology.roughness.whitenoise.config.WhiteNoiseConfigSpec.ListValueSpec;
import technology.roughness.whitenoise.config.WhiteNoiseConfigSpec.Range;
import technology.roughness.whitenoise.config.WhiteNoiseConfigSpec.RestartType;
import technology.roughness.whitenoise.config.WhiteNoiseConfigSpec.ValueSpec;
import technology.roughness.whitenoise.config.WhiteNoiseConfigTracker;
import technology.roughness.whitenoise.util.ColorHelper;
import technology.roughness.whitenoise.util.TranslationUtil;

public final class ConfigurationScreen extends class_4667 {
    private static final class TooltipConfirmScreen extends class_410 {
        boolean seenYes = false;

        private TooltipConfirmScreen(BooleanConsumer callback, class_2561 title, class_2561 message,
                class_2561 yesButton, class_2561 noButton) {
            super(callback, title, message, yesButton, noButton);
        }

        @Override
        protected void method_25426() {
            seenYes = false;
            super.method_25426();
        }

        @Override
        protected void method_37052(@NotNull class_4185 button) {
            if (seenYes) {
                button.method_47400(class_7919.method_47407(RESTART_NO_TOOLTIP));
            }
            else {
                seenYes = true;
            }
            super.method_37052(button);
        }
    }

    // Ideally this should not be static, but we need it in the construtor's super() call
    private static final TranslationUtil translationUtil = new TranslationUtil();

    /**
     * Prefix for static keys the configuration screens use internally.
     */
    private static final String LANG_PREFIX = "whitenoise.configuration.uitext.";
    /**
     * A wrapper for the spec type of config.
     */
    private static final String SPEC_PREFIX = LANG_PREFIX + "type.";
    /**
     * A wrapper for the labels of buttons that open a new screen. Default: "%s..."
     */
    private static final String SECTION = LANG_PREFIX + "section";
    /**
     * Key for title
     */
    private static final String TITLE = LANG_PREFIX + "title";
    /**
     * A default for the labels of buttons that open a new screen. Default: "Edit"
     */
    private static final String SECTION_TEXT = LANG_PREFIX + "sectiontext";
    /**
     * The breadcrumb separator. Default: "%s > %s"
     */
    public static final class_2561 CRUMB_SEPARATOR =
        translationUtil.translatable(LANG_PREFIX + "breadcrumb.separator", class_124.field_1065, class_124.field_1067);
    private static final String CRUMB = LANG_PREFIX + "breadcrumb.order";
    /**
     * The label of list elements. Will be supplied the index into the list. Default: "%s:"
     */
    private static final String LIST_ELEMENT = LANG_PREFIX + "listelement";
    /**
     * How the range will be added to the tooltip when using translated
     * tooltips. Mimics what the comment does in WhiteNoiseConfigSpec.
     */
    private static final String RANGE_TOOLTIP = LANG_PREFIX + "rangetooltip";
    private static final class_124 RANGE_TOOLTIP_STYLE = class_124.field_1060;
    /**
     * How the range will be added to the tooltip when using translated
     * tooltips. Mimics what the comment does in WhiteNoiseConfigSpec.
     */
    private static final String ALLOWED_TOOLTIP = LANG_PREFIX + "allowedtooltip";
    private static final class_124 ALLOWED_TOOLTIP_STYLE = class_124.field_1060;
    /**
     * How the filename will be added to the tooltip.
     */
    private static final String FILENAME_TOOLTIP = LANG_PREFIX + "filenametooltip";
    private static final class_124 FILENAME_TOOLTIP_STYLE = class_124.field_1080;
    /**
     * A literal to create an empty line in a tooltip.
     */
    private static final class_5250 EMPTY_LINE = class_2561.method_43470("\n\n");
    private static final class_5250 NEW_LINE = class_2561.method_43470("\n");

    public static final class_2561 TOOLTIP_CANNOT_EDIT_THIS_WHILE_ONLINE =
        translationUtil.translatable(LANG_PREFIX + "notonline", class_124.field_1061);
    public static final class_2561 TOOLTIP_CANNOT_EDIT_THIS_WHILE_OPEN_TO_LAN =
        translationUtil.translatable(LANG_PREFIX + "notlan", class_124.field_1061);
    public static final class_2561 TOOLTIP_CANNOT_EDIT_NOT_LOADED =
        translationUtil.translatable(LANG_PREFIX + "notloaded", class_124.field_1061);
    public static final class_2561 NEW_LIST_ELEMENT =
        translationUtil.translatable(LANG_PREFIX + "newlistelement");
    public static final class_2561 MOVE_LIST_ELEMENT_UP =
        translationUtil.translatable(LANG_PREFIX + "listelementup");
    public static final class_2561 MOVE_LIST_ELEMENT_DOWN =
        translationUtil.translatable(LANG_PREFIX + "listelementdown");
    public static final class_2561 REMOVE_LIST_ELEMENT =
        translationUtil.translatable(LANG_PREFIX + "listelementremove");
    public static final class_2561 UNSUPPORTED_ELEMENT =
        translationUtil.translatable(LANG_PREFIX + "unsupportedelement", class_124.field_1061);
    public static final class_2561 LONG_STRING =
        translationUtil.translatable(LANG_PREFIX + "longstring", class_124.field_1061);
    public static final class_2561 GAME_RESTART_TITLE =
        translationUtil.translatable(LANG_PREFIX + "restart.game.title");
    public static final class_2561 GAME_RESTART_MESSAGE =
        translationUtil.translatable(LANG_PREFIX + "restart.game.text");
    public static final class_2561 GAME_RESTART_YES =
        translationUtil.translatable("menu.quit"); // TitleScreen.init() et.al.
    public static final class_2561 SERVER_RESTART_TITLE =
        translationUtil.translatable(LANG_PREFIX + "restart.server.title");
    public static final class_2561 SERVER_RESTART_MESSAGE =
        translationUtil.translatable(LANG_PREFIX + "restart.server.text");
    public static final class_2561 SAVING_LEVEL = class_2561.method_43471("menu.savingLevel"); // PauseScreen.SAVING_LEVEL
    public static final class_2561 RETURN_TO_MENU =
        translationUtil.translatable("menu.returnToMenu"); // PauseScreen.RETURN_TO_MENU
    public static final class_2561 RESTART_NO =
        translationUtil.translatable(LANG_PREFIX + "restart.return");
    public static final class_2561 RESTART_NO_TOOLTIP =
        translationUtil.translatable(LANG_PREFIX + "restart.return.tooltip", class_124.field_1061, class_124.field_1067);
    public static final class_2561 UNDO = translationUtil.translatable(LANG_PREFIX + "undo");
    public static final class_2561 UNDO_TOOLTIP = translationUtil.translatable(LANG_PREFIX + "undo.tooltip");
    public static final class_2561 RESET = translationUtil.translatable(LANG_PREFIX + "reset");
    public static final class_2561 RESET_TOOLTIP = translationUtil.translatable(LANG_PREFIX + "reset.tooltip");
    public static final int BIG_BUTTON_WIDTH = 310;

    private final WhiteNoiseModContainer mod;
    private final Function4<ConfigurationScreen, WhiteNoiseConfig.Type, WhiteNoiseConfig, class_2561, class_437> sectionScreen;

    public RestartType needsRestart = RestartType.NONE;
    private static final Set<String> changedFiles = new HashSet<>();
    // If there is only one config type (and it can be edited, we show that
    // instantly on the way "down" and want to close on the way "up".
    // But when returning from the restart/reload confirmation screens, we need to stay open.
    private boolean autoClose = false;

    public ConfigurationScreen(final WhiteNoiseModContainer mod, final class_437 parent) {
        this(mod, parent, ConfigurationSectionScreen::new);
    }

    public ConfigurationScreen(final WhiteNoiseModContainer mod, final class_437 parent,
               Function4<ConfigurationScreen, WhiteNoiseConfig.Type, WhiteNoiseConfig, class_2561, class_437> sectionScreen) {
        super(
            parent,
            class_310.method_1551().field_1690,
            translationUtil.exists(mod.modId() + ".configuration.title") ?
                translationUtil.translatable(mod.modId() + ".configuration.title", mod.displayName()) :
                translationUtil.translatable(TITLE, mod.displayName())
        );
        this.mod = mod;
        this.sectionScreen = sectionScreen;
    }

    @Override
    protected void method_60325() {
        class_4185 btn = null;
        int count = 0;
        class_5250 modName =
            translationUtil.getWithLiteralFallback(mod.modId() + ".configuration.title", mod.displayName());
        class_310 mc = class_310.method_1551();

        for (final Type type : WhiteNoiseConfig.Type.values()) {
            boolean headerAdded = false;
            Set<WhiteNoiseConfig> configSet = mod.getConfigSet(type);

            if (configSet.isEmpty()) {
                continue;
            }

            for (final WhiteNoiseConfig modConfig : configSet) {
                if (modConfig != null && modConfig.getModId().equals(mod.modId())) {
                    class_5250 tooltip = class_2561.method_43473();
                    final String configTypeString = type.name().toLowerCase(Locale.ROOT);

                    if (!headerAdded && field_51824 != null) {
                        field_51824.method_20407(
                            new class_7842(
                                BIG_BUTTON_WIDTH,
                                class_4185.field_39501,
                                translationUtil.translatable(
                                    LANG_PREFIX + type.name().toLowerCase(Locale.ENGLISH),
                                    class_124.field_1073
                                ),
                                field_22793
                            ),
                            null
                        );
                        headerAdded = true;
                    }

                    btn = class_4185.method_46430(
                        translationUtil.translatable(SPEC_PREFIX + configTypeString),
                        button -> mc.method_1507(
                            sectionScreen.apply(
                                this,
                                type,
                                modConfig,
                                translationUtil.translatable(TITLE + "." + configTypeString, modName)
                            )
                        )
                    ).method_46432(BIG_BUTTON_WIDTH).method_46431();

                    if (!modConfig.getSpec().isLoaded()) {
                        tooltip.method_10852(TOOLTIP_CANNOT_EDIT_NOT_LOADED).method_10852(EMPTY_LINE);
                        btn.field_22763 = false;
                        count = 99; // prevent autoClose
                    }
                    else if (type == Type.SERVER && mc.method_1558() != null && !mc.method_47392()) {
                        tooltip.method_10852(TOOLTIP_CANNOT_EDIT_THIS_WHILE_ONLINE).method_10852(EMPTY_LINE);
                        btn.field_22763 = false;
                        count = 99; // prevent autoClose
                    }
                    else if (type == Type.SERVER
                            && mc.method_1496()
                            && mc.method_1576() != null
                            && mc.method_1576().method_3860()) {
                        tooltip.method_10852(TOOLTIP_CANNOT_EDIT_THIS_WHILE_OPEN_TO_LAN).method_10852(EMPTY_LINE);
                        btn.field_22763 = false;
                        count = 99; // prevent autoClose
                    }
                    tooltip.method_10852(
                        class_2561.method_43469(FILENAME_TOOLTIP, modConfig.getFileName()).method_27692(FILENAME_TOOLTIP_STYLE)
                    );
                    btn.method_47400(class_7919.method_47407(tooltip));
                    field_51824.method_20407(btn, null);
                    count++;
                }
            }
        }
        if (count == 1) {
            autoClose = true;
            btn.method_25306();
        }
    }

    @Override
    public void method_49589() {
        super.method_49589();
        if (autoClose) {
            autoClose = false;
            method_25419();
        }
    }

    @SuppressWarnings("incomplete-switch")
    @Override
    public void method_25419() {
        class_310 mc = class_310.method_1551();

        translationUtil.finish();

        if (!changedFiles.isEmpty()) {
            for (String filename : changedFiles) {
                WhiteNoiseConfig config = WhiteNoiseConfigTracker.INSTANCE.getConfig(filename);

                if (config != null) {
                    config.fireLoad(true);
                }
            }
        }

        switch (needsRestart) {
            case GAME -> {
                mc.method_1507(new TooltipConfirmScreen(b -> {
                    if (b) {
                        mc.method_1592();
                    } else {
                        super.method_25419();
                    }
                }, GAME_RESTART_TITLE, GAME_RESTART_MESSAGE, GAME_RESTART_YES, RESTART_NO));
                return;
            }
            case WORLD -> {
                if (mc.field_1687 != null) {
                    mc.method_1507(
                        new TooltipConfirmScreen(
                            b -> {
                                if (b) {
                                    // when changing server configs from the client is
                                    // added, this is where we tell the server to restart and activate the new config.
                                    // also needs a different text in MP ("server will restart/exit, yada yada") than in SP
                                    onDisconnect();
                                }
                                else {
                                    super.method_25419();
                                }
                            },
                            SERVER_RESTART_TITLE,
                            SERVER_RESTART_MESSAGE,
                            mc.method_1542() ? RETURN_TO_MENU : class_5244.field_45692,
                            RESTART_NO
                        )
                    );

                    return;
                }
            }
        }
        super.method_25419();
    }

    // direct copy from PauseScreen (which has the best implementation), sadly it's not really accessible
    private void onDisconnect() {
        class_310 mc = class_310.method_1551();
        boolean flag = mc.method_1542();
        class_642 serverdata = mc.method_1558();
        class_442 titlescreen = new class_442();

        if (mc.field_1687 != null) {
            mc.field_1687.method_8525();
        }

        if (flag) {
            mc.method_56134(new class_424(SAVING_LEVEL));
        }
        else {
            mc.method_18099();
        }

        if (flag) {
            mc.method_1507(titlescreen);
        }
        else if (serverdata != null && serverdata.method_52811()) {
            mc.method_1507(new class_4325(titlescreen));
        }
        else {
            mc.method_1507(new class_500(titlescreen));
        }
    }

    /**
     * A UI screen that presents a single section of configuration values and
     allows the user to edit them, including an unlimited undo system and reset to default.<p>
     *
     * This class is automatically used if you use NeoForge's generic configuration UI, see {@link ConfigurationScreen}.<p>
     *
     * If you have special needs, you can subclass this class to achieve the desired behaviour. For example:<ul>
     *
     * Note: This class subclasses vanilla's {@link class_4667} and
     * inherits some behaviour that is not needed. For example, we need to pass the vanilla
     * <code>options</code> to our superclass' constructor.
     */
    public static class ConfigurationSectionScreen extends class_4667 {
        protected static final long MAX_SLIDER_SIZE = 256L;

        public record Context(String modId, class_437 parent, WhiteNoiseConfig modConfig, WhiteNoiseConfigSpec modSpec,
                Set<? extends Entry> entries, Map<String, Object> valueSpecs, List<String> keylist, Filter filter) {
            @ApiStatus.Internal
            public Context {}

            @SuppressWarnings("deprecation")
            public static Context top(final String modId, final class_437 parent,
                    final WhiteNoiseConfig modConfig, Filter filter) {
                return new Context(modId, parent, modConfig, modConfig.getSpec(),
                    modConfig.getSpec().getValues().entrySet(), modConfig.getSpec().getSpec().valueMap(), List.of(), filter);
            }

            public static Context section(final Context parentContext, final class_437 parent,
                      final Set<? extends Entry> entries, final Map<String, Object> valueSpecs, final String key) {
                return new Context(parentContext.modId, parent, parentContext.modConfig, parentContext.modSpec,
                    entries, valueSpecs, parentContext.makeKeyList(key), parentContext.filter);
            }

            public static Context list(final Context parentContext, final class_437 parent) {
                return new Context(parentContext.modId, parent, parentContext.modConfig, parentContext.modSpec,
                    parentContext.entries, parentContext.valueSpecs, parentContext.keylist, null);
            }

            private ArrayList<String> makeKeyList(final String key) {
                final ArrayList<String> result = new ArrayList<>(keylist);
                result.add(key);
                return result;
            }
        }

        public record Element(@Nullable class_2561 name, @Nullable class_2561 tooltip, @Nullable class_339 widget,
                  @Nullable class_7172<?> option, boolean undoable) {
            @ApiStatus.Internal
            public Element {}

            public Element(@Nullable final class_2561 name, @Nullable final class_2561 tooltip,
                   final class_339 widget) {
                this(name, tooltip, widget, null, true);
            }

            public Element(@Nullable final class_2561 name, @Nullable final class_2561 tooltip,
                   final class_339 widget, boolean undoable) {
                this(name, tooltip, widget, null, undoable);
            }

            public Element(final class_2561 name, final class_2561 tooltip, final class_7172<?> option) {
                this(name, tooltip, null, option, true);
            }

            public Element(final class_2561 name, final class_2561 tooltip, final class_7172<?> option,
                   boolean undoable) {
                this(name, tooltip, null, option, undoable);
            }

            public class_339 getWidget(final class_315 options) {
                if (widget != null) {
                    return widget;
                }
                else if (option != null) {
                    return option.method_57701(options);
                }

                return null;
            }

            @Nullable
            public Object any() {
                return widget != null ? widget : option;
            }
        }

        /**
         * A filter callback to suppress certain elements from being shown in the configuration UI.
         * <p>
         * Return null to suppress the element or return a modified Element.
         */
        public interface Filter {
            @Nullable
            Element filterEntry(Context context, String key, Element original);
        }

        protected final Context context;
        protected boolean changed = false;
        protected RestartType needsRestart = RestartType.NONE;
        protected final Map<String, ConfigurationSectionScreen> sectionCache = new HashMap<>();
        @Nullable
        // must not be changed after creation unless the reference inside the layout also is replaced
        protected class_4185 undoButton, resetButton;
        protected final class_4185 doneButton = class_4185.method_46430(
            class_5244.field_24334,
            button -> method_25419()
        ).method_46432(class_4185.field_39499).method_46431();
        protected final UndoManager undoManager = new UndoManager();

        /**
         * Constructs a new section screen for the top-most section in a {@link WhiteNoiseConfig}.
         *
         * @param parent    The screen to return to when the user presses escape or the "Done" button.
         *                  If this is a {@link ConfigurationScreen}, additional information is passed before closing.
         * @param type      The {@link Type} this configuration is for. Only used to generate the title of the screen.
         * @param modConfig The actual config to show and edit.
         */
        public ConfigurationSectionScreen(final class_437 parent, final WhiteNoiseConfig.Type type,
                final WhiteNoiseConfig modConfig, class_2561 title) {
            this(parent, type, modConfig, title, (c, k, e) -> e);
        }

        /**
         * Constructs a new section screen for the top-most section in a {@link WhiteNoiseConfig}.
         *
         * @param parent    The screen to return to when the user presses escape or the "Done" button.
         *                  If this is a {@link ConfigurationScreen}, additional information is passed before closing.
         * @param type      The {@link Type} this configuration is for. Only used to generate the title of the screen.
         * @param filter    The {@link Filter} to use.
         * @param modConfig The actual config to show and edit.
         */
        public ConfigurationSectionScreen(final class_437 parent, final WhiteNoiseConfig.Type type,
                final WhiteNoiseConfig modConfig, class_2561 title, Filter filter) {
            this(Context.top(modConfig.getModId(), parent, modConfig, filter), title);
            needsRestart = type == Type.STARTUP ? RestartType.GAME : RestartType.NONE;
        }

        /**
         * Constructs a new section screen for a sub-section of a config.
         *
         * @param parentContext The {@link Context} object of the parent.
         * @param parent        The screen to return to when the user presses escape or the "Done" button.
         *                      If this is a {@link ConfigurationSectionScreen}, additional information is passed before closing.
         * @param valueSpecs    The source for the {@link ValueSpec} objects for this section.
         * @param key           The key of the section.
         * @param entrySet      The source for the {@link ConfigValue} objects for this section.
         */
        public ConfigurationSectionScreen(final Context parentContext, final class_437 parent,
                final Map<String, Object> valueSpecs, final String key, final Set<? extends Entry> entrySet, class_2561 title) {
            this(
                Context.section(parentContext, parent, entrySet, valueSpecs, key),
                class_2561.method_43469(CRUMB, parent.method_25440(), CRUMB_SEPARATOR, title)
            );
        }

        protected ConfigurationSectionScreen(final Context context, final class_2561 title) {
            super(context.parent, class_310.method_1551().field_1690, title);
            this.context = context;
        }

        @Nullable
        protected ValueSpec getValueSpec(final String key) {
            final Object object = context.valueSpecs.get(key);
            if (object instanceof final ValueSpec vs) {
                return vs;
            } else {
                return null;
            }
        }

        protected String getTranslationKeyName(String key) {
            return getTranslationKeyName(key, getValueSpec(key), ".name");
        }

        protected String getTranslationKeyDescription(String key) {
            return getTranslationKeyName(key, getValueSpec(key), ".description");
        }

        protected String getTranslationKeyName(String key, ValueSpec valueSpec, String suffix) {
            final String result;
            final String retval;

            if (valueSpec != null) {
                result = valueSpec.getTranslationKey();
            }
            else {
                result = context.modSpec.getLevelTranslationKey(context.makeKeyList(key));
            }

            // Normalize the key to be used as a translation key
            key = key.replaceAll("[^a-zA-Z0-9]+", "").toLowerCase(Locale.ROOT);

            retval = result != null ? result + suffix : context.modId + ".configuration." + key + suffix;
            translationUtil.exists(retval); // for logging missing keys

            return retval;
        }

        protected class_5250 getTranslationComponent(final String key, final ValueSpec valueSpec) {
            return getTranslationComponent(key, valueSpec, false);
        }

        protected class_5250 getTranslationComponent(final String key, final ValueSpec valueSpec,
                boolean tooltip) {
            class_5250 component = class_2561.method_43473();

            if (valueSpec != null && valueSpec.getLocalizationKey() != null) {
                component.method_10852(
                    translationUtil.getWithLiteralFallback(valueSpec.getLocalizationKey() + ".name", key));
            }
            else if (valueSpec != null) {
                component.method_10852(translationUtil.getWithLiteralFallback(getTranslationKeyName(key), key));
            }
            else {
                component.method_10852(class_2561.method_43470(key));
            }

            if (tooltip) {
                component.method_27692(class_124.field_1054);
            }

            return component;
        }

        protected class_5250 getSectionTranslationComponent(final String key) {
            return getSectionTranslationComponent(key, false);
        }

        protected class_5250 getSectionTranslationComponent(final String key, boolean tooltip) {
            class_5250 component = class_2561.method_43473().method_10852(translationUtil.getWithLiteralFallback(getTranslationKeyName(key), key));

            if (tooltip) {
                component.method_27692(class_124.field_1054);
            }

            return component;
        }

        protected String getComment(final ValueSpec valueSpec) {
            if (valueSpec == null) {
                return "";
            }

            return valueSpec.getComment() != null ? valueSpec.getComment() : "";
        }

        protected <T> class_7172.class_7277<T> getTooltip(final String key, ValueSpec valueSpec) {
            return class_7172.method_42717(getTooltipComponent(key, valueSpec));
        }

        protected class_2561 getTooltipComponent(final String key, ValueSpec valueSpec) {
            final String tooltipKey = getTranslationKeyDescription(key);
            String comment = getComment(valueSpec);
            boolean hasDefaultComponent = valueSpec != null && valueSpec.getDefault() != null;
            String range = "";
            String allowed = "";
            final boolean hasTranslatedTooltip = translationUtil.exists(tooltipKey);

            class_5250 component = class_2561.method_43473();

            if (valueSpec != null) {
                component.method_10852(getTranslationComponent(key, valueSpec, true));
            }
            else {
                component.method_10852(getSectionTranslationComponent(key, true));
            }

            if (!comment.isBlank()) {
                int i = comment.indexOf("Range:");

                if (i != -1) {
                    range = comment.substring(i).replace("Range: ", "");
                    comment = comment.substring(0, i);
                }

                i = comment.indexOf("Allowed Values:");

                if (i != -1) {
                    allowed = comment.substring(i).replace("Allowed Values: ", "");
                    comment = comment.substring(0, i);
                }
            }

            if (hasTranslatedTooltip) {
                component = component.method_10852(NEW_LINE).method_10852(translationUtil.translatable(tooltipKey));
            }
            else if (!comment.isBlank()) {
                for (String s : comment.split("\n")) {
                    component.method_10852(NEW_LINE).method_10852(class_2561.method_43470(s));
                }
            }

            if (!range.isBlank()) {
                component.method_10852(NEW_LINE).method_10852(
                    class_2561.method_43469(RANGE_TOOLTIP, range).method_27692(RANGE_TOOLTIP_STYLE));
            }
            else if (!allowed.isBlank()) {
                component.method_10852(NEW_LINE).method_10852(
                    class_2561.method_43469(ALLOWED_TOOLTIP, allowed).method_27692(ALLOWED_TOOLTIP_STYLE));
            }

            if (hasDefaultComponent) {
                component.method_10852(NEW_LINE).method_10852(class_2561.method_43469("editGamerule.default",
                    class_2561.method_43470(valueSpec.getDefault().toString())).method_27692(class_124.field_1080));
            }

            return component;
        }

        /**
         * This is called whenever a value is changed and the change is submitted to the appropriate {@link ConfigSpec}.
         *
         * @param key The key of the changed configuration. To get an absolute key, use {@link Context#makeKeyList(String)}.
         */
        protected void onChanged(final String key) {
            final ValueSpec valueSpec = getValueSpec(key);

            changed = true;
            changedFiles.add(context.modConfig.getFileName());

            if (valueSpec != null) {
                needsRestart = needsRestart.with(valueSpec.restartType());
            }
        }

        @Override
        protected void method_60325() {
            rebuild();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        protected ConfigurationSectionScreen rebuild() {
            if (list != null) { // this may be called early, skip and wait for init() then
                list.children().clear();
                boolean hasUndoableElements = false;

                final List<@Nullable Element> elements = new ArrayList<>();
                for (final Entry entry : context.entries) {
                    final String key = entry.getKey();
                    final Object rawValue = entry.getRawValue();
                    switch (entry.getRawValue()) {
                        case ConfigValue cv -> {
                            var valueSpec = getValueSpec(key);
                            var element = switch (valueSpec) {
                                case ListValueSpec listValueSpec -> createList(key, listValueSpec, cv);
                                case ValueSpec spec when cv.getClass() == ConfigValue.class
                                    && spec.getDefault() instanceof List<?> -> createList(key, spec, cv);
                                case ValueSpec spec when cv.getClass() == ConfigValue.class
                                    && spec.getDefault() instanceof String ->
                                        createStringValue(key, valueSpec, valueSpec::test, () -> (String) cv.getRaw(), cv::set);
                                case ValueSpec spec when cv.getClass() == ConfigValue.class
                                    && spec.getDefault() instanceof Integer ->
                                        createIntegerValue(key, valueSpec, () -> (Integer) cv.getRaw(), cv::set);
                                case ValueSpec spec when cv.getClass() == ConfigValue.class
                                    && spec.getDefault() instanceof Long ->
                                        createLongValue(key, valueSpec, () -> (Long) cv.getRaw(), cv::set);
                                case ValueSpec spec when cv.getClass() == ConfigValue.class
                                    && spec.getDefault() instanceof Double ->
                                        createDoubleValue(key, valueSpec, () -> (Double) cv.getRaw(), cv::set);
                                case ValueSpec spec when cv.getClass() == ConfigValue.class
                                    && spec.getDefault() instanceof Enum<?> ->
                                        createEnumValue(key, valueSpec, (Supplier) cv::getRaw, (Consumer) cv::set);
                                case null -> null;

                                default -> switch (cv) {
                                    case WhiteNoiseConfigSpec.BooleanValue value ->
                                        createBooleanValue(key, valueSpec, value::getRaw, value::set);
                                    case WhiteNoiseConfigSpec.IntValue value ->
                                        createIntegerValue(key, valueSpec, value::getRaw, value::set);
                                    case WhiteNoiseConfigSpec.LongValue value ->
                                        createLongValue(key, valueSpec, value::getRaw, value::set);
                                    case WhiteNoiseConfigSpec.DoubleValue value ->
                                        createDoubleValue(key, valueSpec, value::getRaw, value::set);
                                    case WhiteNoiseConfigSpec.EnumValue value ->
                                        createEnumValue(key, valueSpec, (Supplier) value::getRaw, (Consumer) value::set);
                                    default -> createOtherValue(key, valueSpec, cv);
                                };
                            };
                            elements.add(context.filter.filterEntry(context, key, element));
                        }
                        case UnmodifiableConfig subsection when context.valueSpecs.get(key) instanceof UnmodifiableConfig subconfig ->
                            elements.add(createSection(key, getValueSpec(key), subconfig, subsection));
                        default -> elements.add(context.filter.filterEntry(context, key, createOtherSection(key, rawValue)));
                    }
                }
                elements.addAll(createSyntheticValues());

                for (final Element element : elements) {
                    if (element != null) {
                        if (element.name() == null) {
                            list.addSmall(
                                new StringWidget(
                                    Button.DEFAULT_WIDTH,
                                    Button.DEFAULT_HEIGHT,
                                    Component.empty(),
                                    font
                                ),
                                element.getWidget(options)
                            );
                        }
                        else {
                            final StringWidget label = new StringWidget(
                                Button.DEFAULT_WIDTH,
                                Button.DEFAULT_HEIGHT,
                                element.name,
                                font
                            );

                            if (element.tooltip() != null) {
                                label.setTooltip(Tooltip.create(element.tooltip));
                            }
                            list.addSmall(label, element.getWidget(options));
                        }
                        hasUndoableElements |= element.undoable;
                    }
                }

                if (hasUndoableElements && undoButton == null) {
                    createUndoButton();
                    createResetButton();
                }
            }
            return this;
        }

        /**
         * Override this to add additional configuration elements to the list.
         *
         * @return A collection of {@link Element}.
         */
        protected Collection<? extends Element> createSyntheticValues() {
            return Collections.emptyList();
        }

        protected boolean isNonDefault(ConfigValue<?> cv) {
            return !Objects.equals(cv.getRaw(), cv.getDefault());
        }

        protected boolean isAnyNondefault() {
            for (final Entry entry : context.entries) {
                if (entry.getRawValue() instanceof final ConfigValue<?> cv) {
                    if (!(getValueSpec(entry.getKey()) instanceof ListValueSpec) && isNonDefault(cv)) {
                        return true;
                    }
                }
            }
            return false;
        }

        @Nullable
        protected Element createStringValue(final String key, final ValueSpec spec, final Predicate<String> tester,
                final Supplier<String> source, final Consumer<String> target) {
            if (source.get().length() > 192) {
                // That's just too much for the UI
                final class_7842 label = new class_7842(
                    class_4185.field_39500,
                    class_4185.field_39501,
                    class_2561.method_43470(source.get().substring(0, 128)),
                    field_22793
                );
                label.method_47400(class_7919.method_47407(LONG_STRING));

                return new Element(getTranslationComponent(key, spec), getTooltipComponent(key, spec), label, false);
            }
            final class_342 box = new class_342(
                field_22793,
                class_4185.field_39500,
                class_4185.field_39501,
                getTranslationComponent(key, spec)
            );
            box.method_1888(true);
            // no filter or the user wouldn't be able to type
            box.method_47400(class_7919.method_47407(getTooltipComponent(key, spec)));
            box.method_1880(class_3532.method_15340(source.get().length() + 5, 128, 192));
            box.method_1852(source.get());
            box.method_1863(newValue -> {
                if (newValue != null && tester.test(newValue)) {
                    if (!newValue.equals(source.get())) {
                        undoManager.add(v -> {
                            target.accept(v);
                            onChanged(key);
                        }, newValue, v -> {
                            target.accept(v);
                            onChanged(key);
                        }, source.get());
                    }
                    box.method_1868(ColorHelper.Colors.OFFWHITE.toRGBA());
                    return;
                }
                box.method_1868(ColorHelper.Colors.ERROR_RED.toRGBA());
            });

            return new Element(getTranslationComponent(key, spec), getTooltipComponent(key, spec), box);
        }

        /**
         * Called when an entry is encountered that is neither a {@link ConfigValue} nor a section.
         * Override this to produce whatever UI elements are appropriate for this object.<p>
         *
         * Note that this case is unusual and shouldn't happen unless someone injected something into the config system.
         *
         * @param key   The key of the entry.
         * @param value The entry itself.
         * @return null if no UI element should be added or an {@link Element} to be added to the UI.
         */
        @Nullable
        protected Element createOtherSection(final String key, final Object value) {
            return null;
        }

        /**
         * Called when a {@link ConfigValue} is found that has an unknown data type.
         * Override this to produce whatever UI elements are appropriate for this object.<p>
         *
         * @param key   The key of the entry.
         * @param value The entry itself.
         * @return null if no UI element should be added or an {@link Element} to be added to the UI.
         */
        @Nullable
        protected Element createOtherValue(final String key, final ValueSpec spec, final ConfigValue<?> value) {
            final class_7842 label = new class_7842(
                class_4185.field_39500,
                class_4185.field_39501,
                class_2561.method_43470(Objects.toString(value.getRaw())),
                field_22793
            );
            label.method_47400(class_7919.method_47407(UNSUPPORTED_ELEMENT));
            return new Element(getTranslationComponent(key, spec), getTooltipComponent(key, spec), label, false);
        }

        /**
         * A custom variant of OptionsInstance.Enum that doesn't show the key on the button, just the value
         */
        public record Custom<T>(List<T> values) implements class_7172.class_7178<T> {
            @Override
            public @NotNull Function<class_7172<T>, class_339> method_41756(
                    class_7172.@NotNull class_7277<T> tooltip, @NotNull class_315 options, int x, int y,
                    int width, @NotNull Consumer<T> target) {
                return optionsInstance -> class_5676.method_32606(optionsInstance.field_37864)
                        .method_42729(class_5676.class_5680.method_32627(this.values))
                        .method_32618(tooltip)
                        .method_32616()
                        .method_32619(optionsInstance.method_41753())
                        .method_32617(x, y, width, 20, optionsInstance.field_38280, (source, newValue) -> {
                            optionsInstance.method_41748(newValue);
                            options.method_1640();
                            target.accept(newValue);
                        });
            }

            @Override
            public @NotNull Optional<T> method_41758(@NotNull T value) {
                return values.contains(value) ? Optional.of(value) : Optional.empty();
            }

            @Override
            public Codec<T> comp_675() {
                return null;
            }

            public static final Custom<Boolean> BOOLEAN_VALUES_NO_PREFIX =
                new Custom<>(ImmutableList.of(Boolean.TRUE, Boolean.FALSE));
        }

        @Nullable
        protected Element createBooleanValue(final String key, final ValueSpec spec,
                final Supplier<Boolean> source, final Consumer<Boolean> target) {
            return new Element(getTranslationComponent(key, spec), getTooltipComponent(key, spec),
                new class_7172<>(
                    getTranslationKeyName(key),
                    getTooltip(key, spec),
                    class_7172.field_41333,
                    Custom.BOOLEAN_VALUES_NO_PREFIX,
                    source.get(),
                    newValue -> {
                        // regarding change detection: new value always is different (cycle button)
                        undoManager.add(
                            v -> {
                                target.accept(v);
                                onChanged(key);
                            },
                            newValue,
                            v -> {
                                target.accept(v);
                                onChanged(key);
                            },
                            source.get()
                        );
                    }
                )
            );
        }

        @Nullable
        protected <T extends Enum<T>> Element createEnumValue(final String key,
                final ValueSpec spec, final Supplier<T> source, final Consumer<T> target) {
            @SuppressWarnings("unchecked")
            final Class<T> clazz = (Class<T>) spec.getClazz();
            assert clazz != null;

            final List<T> list = Arrays.stream(clazz.getEnumConstants()).filter(spec::test).toList();

            return new Element(
                    getTranslationComponent(key, spec),
                    getTooltipComponent(key, spec),
                    new class_7172<>(
                            getTranslationKeyName(key),
                            getTooltip(key, spec),
                            (caption, displayvalue) ->
                                    displayvalue instanceof TranslationUtil.TranslatableEnum tenum ?
                                            tenum.getTranslatedName() : class_2561.method_43470(displayvalue.name()),
                            new Custom<>(list),
                            source.get(),
                            newValue -> {
                                // regarding change detection: new value always is different (cycle button)
                                undoManager.add(
                                    v -> {
                                        target.accept(v);
                                        onChanged(key);
                                    },
                                    newValue,
                                    v -> {
                                        target.accept(v);
                                        onChanged(key);
                                    },
                                    source.get()
                                );
                            }
                    )
            );
        }

        @Nullable
        protected Element createIntegerValue(final String key, final ValueSpec spec,
                final Supplier<Integer> source, final Consumer<Integer> target) {
            final Range<Integer> range = spec.getRange();
            final int min = range != null ? range.getMin() : 0;
            final int max = range != null ? range.getMax() : Integer.MAX_VALUE;

            if ((long) max - (long) min < MAX_SLIDER_SIZE) {
                return createSlider(key, spec, source, target, range);
            }
            else {
                return createNumberBox(key, spec, source, target, null, Integer::decode, 0);
            }
        }

        @Nullable
        protected Element createSlider(final String key, final ValueSpec spec,
                final Supplier<Integer> source, final Consumer<Integer> target, final @Nullable Range<Integer> range) {
            return new Element(
                getTranslationComponent(key, spec),
                getTooltipComponent(key, spec),
                new class_7172<>(
                    getTranslationKeyName(key),
                    getTooltip(key, spec),
                    (caption, displayvalue) ->
                            class_2561.method_43470("" + displayvalue),
                            new class_7172.class_7174(range != null ?
                                    range.getMin() : 0, range != null ? range.getMax() : Integer.MAX_VALUE),
                    null,
                    source.get(),
                    newValue -> {
                        if (!newValue.equals(source.get())) {
                            undoManager.add(
                                v -> {
                                    target.accept(v);
                                    onChanged(key);
                                },
                                newValue,
                                v -> {
                                    target.accept(v);
                                    onChanged(key);
                                },
                                source.get()
                            );
                        }
                    }
                )
            );
        }

        @Nullable
        protected Element createLongValue(final String key, final ValueSpec spec,
                final Supplier<Long> source, final Consumer<Long> target) {
            return createNumberBox(key, spec, source, target, null, Long::decode, 0L);
        }

        // if someone knows how to get a proper zero inside...
        @Nullable
        protected <T extends Number & Comparable<? super T>> Element createNumberBox(
                final String key, final ValueSpec spec, final Supplier<T> source, final Consumer<T> target,
                @Nullable final Predicate<T> tester, final Function<String, T> parser, final T zero) {
            final Range<T> range = spec.getRange();
            final class_342 box = new class_342(field_22793, class_4185.field_39500, class_4185.field_39501, getTranslationComponent(key, spec));

            box.method_1888(true);
            box.method_1890(newValueString -> {
                try {
                    parser.apply(newValueString);
                    return true;
                }
                catch (final NumberFormatException e) {
                    return isPartialNumber(newValueString, (range == null || range.getMin().compareTo(zero) < 0));
                }
            });
            box.method_47400(class_7919.method_47407(getTooltipComponent(key, spec)));
            box.method_1852(source.get() + "");
            box.method_1863(newValueString -> {
                try {
                    final T newValue = parser.apply(newValueString);
                    if (tester != null ? tester.test(newValue) :
                            (newValue != null && (range == null || range.test(newValue)) && spec.test(newValue))) {
                        if (!newValue.equals(source.get())) {
                            undoManager.add(v -> {
                                target.accept(v);
                                onChanged(key);
                            }, newValue, v -> {
                                target.accept(v);
                                onChanged(key);
                            }, source.get());
                        }
                        box.method_1868(ColorHelper.Colors.OFFWHITE.toRGBA());
                        return;
                    }
                }
                catch (final NumberFormatException e) {
                    // field probably is just empty/partial, ignore that
                }

                box.method_1868(ColorHelper.Colors.ERROR_RED.toRGBA());
            });

            return new Element(getTranslationComponent(key, spec), getTooltipComponent(key, spec), box);
        }

        protected boolean isPartialNumber(String value, boolean allowNegative) {
            return switch (value) {
                case "" -> true;
                case "0" -> true;
                case "0x" -> true;
                case "0X" -> true;
                case "#" -> true; // not valid for doubles, but not worth making a special case
                case "-" -> allowNegative;
                case "-0" -> allowNegative;
                case "-0x" -> allowNegative;
                case "-0X" -> allowNegative;
                // case "-#" -> allowNegative; // Java allows this, but no thanks, that's just cursed.
                // doubles can also do NaN, inf, and 0e0. Again, not worth making a special case for those, I say.
                default -> false;
            };
        }

        @Nullable
        protected Element createDoubleValue(final String key, final ValueSpec spec,
                final Supplier<Double> source, final Consumer<Double> target) {
            return createNumberBox(key, spec, source, target, null, Double::parseDouble, 0.0);
        }

        @SuppressWarnings("deprecation")
        @Nullable
        protected Element createSection(final String key, final ValueSpec spec,
                final UnmodifiableConfig subconfig, final UnmodifiableConfig subsection) {
            class_310 mc = class_310.method_1551();

            if (subconfig.isEmpty()) {
                return null;
            }

            return new Element(
                class_2561.method_43469(SECTION, getSectionTranslationComponent(key)),
                getTooltipComponent(key, spec),
                class_4185.method_46430(
                    class_2561.method_43469(SECTION, class_2561.method_43471(SECTION_TEXT)),
                    button -> mc.method_1507(
                        sectionCache.computeIfAbsent(
                            key,
                            k -> new ConfigurationSectionScreen(
                                context,
                                this,
                                subconfig.valueMap(),
                                key,
                                subsection.entrySet(),
                                getSectionTranslationComponent(key)
                            ).rebuild()
                        )
                    )
                ).method_46436(class_7919.method_47407(getTooltipComponent(key, spec))).method_46432(class_4185.field_39500).method_46431(),
                false
            );
        }

        @Nullable
        protected <T> Element createList(final String key, final ValueSpec spec, final ConfigValue<List<T>> list) {
            class_310 mc = class_310.method_1551();

            return new Element(
                class_2561.method_43469(SECTION, getTranslationComponent(key, spec)),
                getTooltipComponent(key, spec),
                class_4185.method_46430(
                    class_2561.method_43469(SECTION, class_2561.method_43471(SECTION_TEXT)),
                    button -> mc.method_1507(
                        sectionCache.computeIfAbsent(
                            key,
                            k -> new ConfigurationListScreen<>(
                                Context.list(context, this),
                                key,
                                class_2561.method_43469(
                                    CRUMB,
                                    this.method_25440(),
                                    CRUMB_SEPARATOR,
                                    getTranslationComponent(key, spec)
                                ),
                                spec,
                                list
                            )
                        ).rebuild()
                    )
                ).method_46436(class_7919.method_47407(getTooltipComponent(key, spec))).method_46431(),
                false
            );
        }

        @Override
        public void method_25394(@NotNull class_332 graphics, int p_281550_, int p_282878_, float p_282465_) {
            setUndoButtonstate(undoManager.canUndo()); // in render()? Really? --- Yes! This is how vanilla does it.
            setResetButtonstate(isAnyNondefault());
            super.method_25394(graphics, p_281550_, p_282878_, p_282465_);
        }

        @Override
        protected void method_31387() {
            if (undoButton != null || resetButton != null) {
                class_8667 linearlayout = field_49503.method_48996(class_8667.method_52742().method_52735(8));
                if (undoButton != null) {
                    linearlayout.method_52736(undoButton);
                }
                if (resetButton != null) {
                    linearlayout.method_52736(resetButton);
                }
                linearlayout.method_52736(doneButton);
            } else {
                super.method_31387();
            }
        }

        protected void createUndoButton() {
            undoButton = class_4185.method_46430(UNDO, button -> {
                undoManager.undo();
                rebuild();
            }).method_46436(class_7919.method_47407(UNDO_TOOLTIP)).method_46432(class_4185.field_39499).method_46431();
            undoButton.field_22763 = false;
        }

        protected void setUndoButtonstate(boolean state) {
            if (undoButton != null) {
                undoButton.field_22763 = state;
            }
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        protected void createResetButton() {
            resetButton = class_4185.method_46430(RESET, button -> {
                List<UndoManager.Step<?>> list = new ArrayList<>();
                for (final Entry entry : context.entries) {
                    if (entry.getRawValue() instanceof final ConfigValue cv
                            && !(getValueSpec(entry.getKey()) instanceof ListValueSpec)
                            && isNonDefault(cv)) {
                        final String key = entry.getKey();
                        ValueSpec valueSpec = getValueSpec(key);

                        if (valueSpec == null) {
                            continue;
                        }
                        list.add(
                            undoManager.step(
                                v -> {
                                    cv.set(v);
                                    onChanged(key);
                                },
                                valueSpec.correct(null),
                                v -> {
                                    cv.set(v);
                                    onChanged(key);
                                },
                                cv.getRaw()
                            )
                        );
                    }
                }
                undoManager.add(list);
                rebuild();
            }).method_46436(class_7919.method_47407(RESET_TOOLTIP)).method_46432(class_4185.field_39499).method_46431();
        }

        protected void setResetButtonstate(boolean state) {
            if (resetButton != null) {
                resetButton.field_22763 = state;
            }
        }

        @Override
        public void method_25419() {
            if (changed) {
                if (field_21335 instanceof final ConfigurationSectionScreen parent) {
                    // "bubble up" the marker so the top-most section can change the WhiteNoiseConfig
                    parent.changed = true;
                } else {
                    // we are a top-level per-type config screen, i.e. one
                    // specific config file. Save the config and tell the mod to reload.
                    context.modSpec.save();
                }
                // the restart flag only matters when there were actual changes
                if (field_21335 instanceof final ConfigurationSectionScreen parent) {
                    parent.needsRestart = parent.needsRestart.with(needsRestart);
                } else if (field_21335 instanceof final ConfigurationScreen parent) {
                    parent.needsRestart = parent.needsRestart.with(needsRestart);
                }
            }
            super.method_25419();
        }
    }

    /**
     * A UI screen that presents a list-type configuration value and allows the
     * user to edit it, including an unlimited undo system and reset to default.<p>
     *
     * This class is automatically used if you use NeoForge's generic configuration UI, see {@link ConfigurationScreen}.<p>
     *
     */
    public static class ConfigurationListScreen<T> extends ConfigurationSectionScreen {
        protected final String key;
        protected final ValueSpec spec;

        // the original data
        protected final ConfigValue<List<T>> valueList;
        // the copy of the data we are working on
        protected List<T> cfgList;

        public ConfigurationListScreen(final Context context, final String key, final class_2561 title, final ValueSpec spec,
                final ConfigValue<List<T>> valueList) {
            super(context, title);
            this.key = key;
            this.spec = spec;
            this.valueList = valueList; // === (ListValueSpec)getValueSpec(key)
            this.cfgList = new ArrayList<>(valueList.getRaw());
        }

        @Override
        protected ConfigurationSectionScreen rebuild() {
            if (list != null) { // this may be called early, skip and wait for init() then
                list.children().clear();

                for (int idx = 0; idx < cfgList.size(); idx++) {
                    var entry = cfgList.get(idx);
                    var element = switch (entry) {
                        case null -> null;
                        case final Boolean value -> createBooleanListValue(idx, value);
                        case final Integer value -> createIntegerListValue(idx, value);
                        case final Long value -> createLongListValue(idx, value);
                        case final Double value -> createDoubleListValue(idx, value);
                        case final String value -> createStringListValue(idx, value);
                        default -> createOtherValue(idx, entry);
                    };

                    if (element != null) {
                        final AbstractWidget widget = element.getWidget(options);
                        if (widget instanceof EditBox box) {
                            // Force our responder to check content and set text colour.
                            // This is only needed on lists, as section cannot have new UI elements added with bad data.
                            // Here, this can happen when a new element is added to the list.
                            // As the new value is the old value, no undo record will be created.
                            box.setValue(box.getValue());
                        }
                        list.addSmall(createListLabel(idx), widget);
                    }
                }

                createAddElementButton();
                if (undoButton == null) {
                    createUndoButton();
                    createResetButton();
                }
            }
            return this;
        }

        protected boolean isAnyNondefault() {
            return !cfgList.equals(valueList.getDefault());
        }

        /**
         * Creates a button to add a new element to the end of the list and adds it to the UI.<p>
         *
         * Override this if you want a different button or want to add more elements.
         */
        @SuppressWarnings("unchecked")
        protected void createAddElementButton() {
            final Supplier<?> newElement = spec.getNewElementSupplier();
            final Range<Integer> sizeRange = spec.getSizeRange();

            if (newElement != null && field_51824 != null && sizeRange.test(cfgList.size() + 1)) {
                field_51824.method_20407(
                    new class_7842(
                        class_4185.field_39500,
                        class_4185.field_39501,
                        class_2561.method_43473(),
                        field_22793
                    ),
                    class_4185.method_46430(
                        NEW_LIST_ELEMENT,
                        button -> {
                            List<T> newValue = new ArrayList<>(cfgList);

                            newValue.add((T) newElement.get());
                            undoManager.add(
                                v -> {
                                    cfgList = v;
                                    onChanged(key);
                                },
                                newValue,
                                v -> {
                                    cfgList = v;
                                    onChanged(key);
                                },
                                cfgList
                            );
                            rebuild();
                        }
                    ).method_46431()
                );
            }
        }

        /**
         * Creates a new widget to label a list value and provide manipulation buttons for it.<p>
         *
         * Override this if you want different labels/buttons.
         *
         * @param idx The index into the list.
         * @return An {@link class_339} to be rendered in the left column of the options screen
         */
        protected class_339 createListLabel(int idx) {
            return new ListLabelWidget(
                0,
                0,
                class_4185.field_39500,
                class_4185.field_39501,
                class_2561.method_43469(LIST_ELEMENT, idx),
                idx
            );
        }

        /**
         * Called when a list element is found that has an unknown or unsupported data type. Override this to produce whatever
         * UI elements are appropriate for this object.<p>
         *
         * Note that all types of elements that can be read from the config file as part of a list are already supported. You
         * only need this if you manipulate the contents of the list after it has been loaded.<p>
         *
         * If this returns null, no row will be shown on the screen, but the up/down buttons will still see your element.
         * Which means that the user will see no change when moving another element over the hidden line. Consider returning
         * a {@link class_7842} as a placeholder instead.<p>
         *
         * Do <em>not</em> capture {@link #cfgList} here or in another create*Value() method. The undo/reset system will
         * replace the list, so you need to always access the field. You can (and should) capture the index.
         *
         * @param idx   The index into the list.
         * @param entry The entry itself.
         * @return null if this element should be skipped or an {@link Element} to be added to the UI.
         */
        @Nullable
        protected Element createOtherValue(final int idx, final T entry) {
            final class_7842 label = new class_7842(
                class_4185.field_39500,
                class_4185.field_39501,
                class_2561.method_43470(Objects.toString(entry)),
                field_22793
            );

            label.method_47400(class_7919.method_47407(UNSUPPORTED_ELEMENT));

            return new Element(
                getTranslationComponent(key, spec),
                getTooltipComponent(key, spec),
                label,
                false
            );
        }

        @SuppressWarnings("unchecked")
        @Nullable
        protected Element createStringListValue(final int idx, final String value) {
            return createStringValue(
                key,
                spec,
                v -> spec.test(List.of(v)),
                () -> value,
                newValue -> cfgList.set(idx, (T) newValue)
            );
        }

        @SuppressWarnings("unchecked")
        @Nullable
        protected Element createDoubleListValue(final int idx, final Double value) {
            return createNumberBox(
                key,
                spec,
                () -> value,
                newValue -> cfgList.set(idx, (T) newValue),
                v -> spec.test(List.of(v)),
                Double::parseDouble,
                0.0
            );
        }

        @SuppressWarnings("unchecked")
        @Nullable
        protected Element createLongListValue(final int idx, final Long value) {
            return createNumberBox(
                key,
                spec,
                () -> value,
                newValue -> cfgList.set(idx, (T) newValue),
                v -> spec.test(List.of(v)),
                Long::decode,
                0L
            );
        }

        @SuppressWarnings("unchecked")
        @Nullable
        protected Element createIntegerListValue(final int idx, final Integer value) {
            return createNumberBox(
                key,
                spec,
                () -> value,
                newValue -> cfgList.set(idx, (T) newValue),
                v -> spec.test(List.of(v)),
                Integer::decode,
                0
            );
        }

        @SuppressWarnings("unchecked")
        @Nullable
        protected Element createBooleanListValue(final int idx, final Boolean value) {
            return createBooleanValue(
                key,
                spec,
                () -> value,
                newValue -> cfgList.set(idx, (T) newValue)
            );
        }

        /**
         * Swap the given element with the next one. Should be called by the list label widget to manipulate the list.
         */
        protected boolean swap(final int idx, final boolean simulate) {
            final List<T> values = new ArrayList<>(cfgList);

            values.add(idx, values.remove(idx + 1));

            return addUndoListener(simulate, values);
        }

        /**
         * Remove the given element. Should be called by the list label widget to manipulate the list.
         */
        protected boolean del(final int idx, final boolean simulate) {
            final List<T> values = new ArrayList<>(cfgList);

            values.remove(idx);

            return addUndoListener(simulate, values);
        }

        private boolean addUndoListener(boolean simulate, List<T> values) {
            final boolean valid = spec.test(values);

            if (!simulate && valid) {
                undoManager.add(
                    v -> {
                        cfgList = v;
                        onChanged(key);
                    },
                    values,
                    v -> {
                        cfgList = v;
                        onChanged(key);
                    },
                    cfgList
                );
                rebuild();
            }

            return valid;
        }

        @Override
        public void method_25419() {
            if (changed && spec.test(cfgList)) {
                valueList.set(cfgList);
                if (context.parent instanceof ConfigurationSectionScreen parent) {
                    parent.onChanged(key);
                }
            }
            super.method_25419();
        }

        @Override
        public void method_25394(@NotNull class_332 graphics, int p_281550_, int p_282878_, float p_282465_) {
            doneButton.field_22763 = spec.test(cfgList);
            super.method_25394(graphics, p_281550_, p_282878_, p_282465_);
        }

        protected void onChanged(final String key) {
            changed = true;
            // parent's onChanged() will be fired when we actually assign the changed list. For now,
            // we've only changed our working copy.
        }

        @SuppressWarnings("unchecked")
        protected void createResetButton() {
            ValueSpec valueSpec = getValueSpec(key);

            if (valueSpec == null) {
                return;
            }
            resetButton = class_4185.method_46430(RESET, button -> {
                undoManager.add(
                    v -> {
                        cfgList = v;
                        onChanged(key);
                    },
                    new ArrayList<>((List<T>) valueSpec.correct(null)),
                    v -> {
                        cfgList = v;
                        onChanged(key);
                    },
                    cfgList
                );
                rebuild();
            }).method_46436(class_7919.method_47407(RESET_TOOLTIP)).method_46432(class_4185.field_39499).method_46431();
        }

        /**
         * A widget to be used as a label in a list of configuration values.<p>
         *
         * It includes buttons for "move element up", "move element down", and "delete element" as well as a label.
         *
         */
        public class ListLabelWidget extends class_9017 {
            protected final class_4185 upButton = class_4185.method_46430(MOVE_LIST_ELEMENT_UP, this::up).method_46431();
            protected final class_4185 downButton = class_4185.method_46430(MOVE_LIST_ELEMENT_DOWN, this::down).method_46431();
            protected final class_4185 delButton = class_4185.method_46430(REMOVE_LIST_ELEMENT, this::rem).method_46431();
            protected final class_7842 label = new class_7842(0, 0, 0, 0, class_2561.method_43473(), field_22793);
            protected final int idx;
            protected final boolean isFirst;
            protected final boolean isLast;

            public ListLabelWidget(final int x, final int y, final int width,
                    final int height, final class_2561 labelText, final int idx) {
                super(x, y, width, height, labelText);
                this.idx = idx;
                this.isFirst = idx == 0;
                this.isLast = idx + 1 == cfgList.size();
                label.method_25355(labelText);
                checkButtons();
                updateLayout();
            }

            @Override
            public void method_46421(final int pX) {
                super.method_46421(pX);
                updateLayout();
            }

            @Override
            public void method_46419(final int pY) {
                super.method_46419(pY);
                updateLayout();
            }

            @Override
            public void method_53533(final int pHeight) {
                super.method_53533(pHeight);
                updateLayout();
            }

            @Override
            public void method_25358(int pWidth) {
                super.method_25358(pWidth);
                updateLayout();
            }

            @Override
            public void method_55445(int pWidth, int pHeight) {
                super.method_55445(pWidth, pHeight);
                updateLayout();
            }

            protected void updateLayout() {
                upButton.method_46421(method_46426());
                downButton.method_46421(method_46426() + method_25364() + 2);
                delButton.method_46421(method_46426() + method_25368() - method_25364());
                label.method_46421(method_46426() + 2 * 22);

                upButton.method_46419(method_46427());
                downButton.method_46419(method_46427());
                delButton.method_46419(method_46427());
                label.method_46419(method_46427());

                upButton.method_53533(method_25364());
                downButton.method_53533(method_25364());
                delButton.method_53533(method_25364());
                label.method_53533(method_25364());

                upButton.method_25358(method_25364());
                downButton.method_25358(method_25364());
                delButton.method_25358(method_25364());
                label.method_25358(method_25368() - 3 * (method_25364() + 2));
            }

            void up(final class_4185 button) {
                swap(idx - 1, false);
            }

            void down(final class_4185 button) {
                swap(idx, false);
            }

            void rem(final class_4185 button) {
                del(idx, false);
            }

            @Override
            public @NotNull List<? extends class_364> method_25396() {
                return List.of(upButton, label, downButton, delButton);
            }

            @Override
            protected void method_48579(final @NotNull class_332 pGuiGraphics,
                    final int pMouseX, final int pMouseY, final float pPartialTick) {
                checkButtons();
                label.method_25394(pGuiGraphics, pMouseX, pMouseY, pPartialTick);
                if (!isFirst) {
                    upButton.method_25394(pGuiGraphics, pMouseX, pMouseY, pPartialTick);
                }
                if (!isLast) {
                    downButton.method_25394(pGuiGraphics, pMouseX, pMouseY, pPartialTick);
                }
                delButton.method_25394(pGuiGraphics, pMouseX, pMouseY, pPartialTick);
            }

            protected void checkButtons() {
                Range<Integer> sizeRange = spec.getSizeRange();

                upButton.field_22764 = !isFirst;
                upButton.field_22763 = !isFirst && swap(idx - 1, true);
                downButton.field_22764 = !isLast;
                downButton.field_22763 = !isLast && swap(idx, true);
                delButton.field_22763 = !cfgList.isEmpty()
                    && (sizeRange == null || sizeRange.test(cfgList.size() - 1)) && del(idx, true);
            }

            @Override
            protected void method_47399(final @NotNull class_6382 pNarrationElementOutput) {
                // TODO I have no idea. Help?
            }

        }

    }

}
