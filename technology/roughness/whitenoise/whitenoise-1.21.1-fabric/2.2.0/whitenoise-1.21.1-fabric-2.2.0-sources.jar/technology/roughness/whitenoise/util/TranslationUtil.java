package technology.roughness.whitenoise.util;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1074;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import org.jetbrains.annotations.Nullable;

import com.mojang.datafixers.util.Pair;
import technology.roughness.whitenoise.WhiteNoise;
import technology.roughness.whitenoise.config.ConfigHandler;

public class TranslationUtil {

    private final Set<String> untranslatables = new HashSet<>();
    private final Set<Pair<String, String>> untranslatablesWithFallback = new HashSet<>();

    public class_5250 getWithLiteralFallback(final String translationKey, final String fallback) {
        class_5250 component = class_2561.method_43473();

        if (class_1074.method_4663(translationKey)) {
            component.method_10852(class_2561.method_43471(translationKey));
        }
        else {
            untranslatablesWithFallback.add(Pair.of(translationKey, fallback));
            component.method_10852(class_2561.method_43470(fallback));
        }

        return component;
    }

    public class_2561 get(final String modTranslationKey, final String fallbackTranslationKey) {
        if (exists(modTranslationKey)) {
            return class_2561.method_43471(modTranslationKey);
        }
        else {
            return translatable(fallbackTranslationKey);
        }
    }

    public class_2561 translatable(final String translationKey, final class_5250 replacements, @Nullable class_124... formatting) {
        if (exists(translationKey)) {
            return class_2561.method_43469(translationKey, replacements).method_27695(formatting);
        }
        else {
            return class_2561.method_43470(translationKey).method_27695(formatting);
        }
    }

    public class_2561 translatable(final String translationKey, final String replacements, @Nullable class_124... formatting) {
        if (exists(translationKey)) {
            return class_2561.method_43469(translationKey, replacements).method_27695(formatting);
        }
        else {
            return class_2561.method_43470(translationKey).method_27695(formatting);
        }
    }

    public class_2561 translatable(final String translationKey, @Nullable class_124... formatting) {
        if (exists(translationKey)) {
            return class_2561.method_43471(translationKey).method_27695(formatting);
        }
        else {
            return class_2561.method_43470(translationKey).method_27695(formatting);
        }
    }

    public boolean exists(final String translationKey) {
        if (!class_1074.method_4663(translationKey)) {
            untranslatables.add(translationKey);

            return false;
        }

        return true;
    }

    public void finish() {
        if (ConfigHandler.Client.logTranslatableWarnings() && (!untranslatables.isEmpty() || !untranslatablesWithFallback.isEmpty())) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("""
                \nDev warning - Untranslated configuration keys encountered.
                Please translate your configuration keys so users can properly configure your mod.
            """);
            if (!untranslatables.isEmpty()) {
                stringBuilder.append("\nUntranslated keys:");
                for (String key : untranslatables) {
                    stringBuilder.append("\n  \"").append(key).append("\": \"\",");
                }
            }
            if (!untranslatablesWithFallback.isEmpty()) {
                stringBuilder.append("\nThe following keys have fallbacks. ")
                    .append("Please check if those are suitable, and translate them if they're not.");
                for (Pair<String, String> untranslatable : untranslatablesWithFallback) {
                    stringBuilder.append("\n  \"").append(untranslatable.getFirst())
                        .append("\": \"").append(untranslatable.getSecond()).append("\",");
                }
            }

            WhiteNoise.LOGGER.warn("{}", stringBuilder);
        }
        untranslatables.clear();
    }

    public interface TranslatableEnum {

        default class_2561 getTranslatedName() {
            return class_2561.method_43470(((Enum<?>) this).name());
        }

    }

}
