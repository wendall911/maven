package technology.roughness.whitenoise.event;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_6862;
import net.minecraft.class_9285;
import net.minecraft.class_9288;
import net.minecraft.class_9290;
import net.minecraft.class_9304;
import net.minecraft.class_9336;
import org.jetbrains.annotations.Nullable;

import io.netty.buffer.Unpooled;
import org.slf4j.helpers.MessageFormatter;

import technology.roughness.whitenoise.config.ConfigHandler;
import technology.roughness.whitenoise.util.PrettyPrinter;

public class AdvancedTooltipEventHandler {

    public static void onItemTooltip(class_1799 itemStack, List<class_2561> toolTip) {
        if (itemStack != null && !itemStack.method_7960()) {
            if (ConfigHandler.Client.showAdvancedTooltips() && class_310.method_1551().field_1690.field_1827) {
                if (itemStack.method_7936() != 0 && itemStack.method_7919() == 0) {
                    toolTip.add(
                        1,
                        class_2561.method_43469("tooltip.whitenoise.durability", itemStack.method_7936())
                            .method_27692(class_124.field_1080)
                    );
                }

                if (class_437.method_25441()) {
                    for (class_9336<?> typedDataComponent : itemStack.method_57353()) {
                        Object value = typedDataComponent.comp_2444();
                        String unformatted = MessageFormatter.format("{}", value).getMessage();
                        boolean showComponent = true;

                        if (value instanceof class_9290(List<Component> lines, List<Component> styledLines)) {
                            showComponent = !lines.isEmpty() || !styledLines.isEmpty();
                        }
                        else if (value instanceof class_9285 modifiers) {
                            showComponent = !modifiers.comp_2393().isEmpty();
                        }
                        else if (value instanceof class_9304 itemEnchantments) {
                            showComponent = !itemEnchantments.method_57534().isEmpty();
                        }
                        else if (value instanceof class_9288) {
                            showComponent = false;
                        }

                        if (showComponent) {
                            String prettyString = PrettyPrinter.format(unformatted);

                            if (!prettyString.isEmpty()) {
                                String componentString = String.format("%s: %s", typedDataComponent.comp_2443(), prettyString);
                                List<String> lines = Arrays.stream(componentString.split("\\n")).toList();

                                for (String tagString : lines) {
                                    toolTip.add(
                                        class_2561.method_43470(tagString).method_27692(class_124.field_1080)
                                    );
                                }
                            }
                        }
                    }
                }
                else {
                    toolTip.add(
                        class_2561.method_43469(
                            "tooltip.whitenoise.ctrl",
                                class_2561.method_43471("tooltip.whitenoise.ctrl_literal")
                                    .method_27692(class_124.field_1054)
                            ).method_27692(class_124.field_1080)
                    );
                }

                Collection<class_2960> tags = getTags(itemStack.method_40133());

                if (class_437.method_25442()) {
                    class_2248 block = class_2248.method_9503(itemStack.method_7909());

                    if (!tags.isEmpty()) {
                        toolTip.add(
                            class_2561.method_43471("tooltip.whitenoise.item_tags")
                                .method_27692(class_124.field_1063)
                        );
                        tags.forEach((tag) -> toolTip.add(
                            class_2561.method_43470("  #" + tag.toString()).method_27692(class_124.field_1080)));
                    }

                    if (block != class_2246.field_10124) {
                        tags = getTags(block.method_9564().method_40144());

                        if (!tags.isEmpty()) {
                            toolTip.add(
                                class_2561.method_43471("tooltip.whitenoise.block_tags")
                                    .method_27692(class_124.field_1063)
                            );
                            tags.forEach((tag) -> toolTip.add(
                                class_2561.method_43470("  #" + tag).method_27692(class_124.field_1080)));
                        }
                    }
                }
                else {
                    if (tags.isEmpty()) {
                        class_2248 block = class_2248.method_9503(itemStack.method_7909());

                        if (block != class_2246.field_10124) {
                            tags = getTags(block.method_9564().method_40144());
                        }
                    }

                    if (!tags.isEmpty()) {
                        toolTip.add(
                            class_2561.method_43469(
                                "tooltip.whitenoise.shift",
                                class_2561.method_43471("tooltip.whitenoise.shift_literal")
                                    .method_27692(class_124.field_1054)
                            ).method_27692(class_124.field_1080)
                        );
                    }
                }
            }

        }
    }

    private static int getNBTSize(@Nullable class_2487 nbt) {
        class_2540 buffer = new class_2540(Unpooled.buffer());

        buffer.method_10794(nbt);
        buffer.release();

        return buffer.writerIndex();
    }

    public static <T> Collection<class_2960> getTags(Stream<class_6862<T>> tags) {
        return tags.map(class_6862::comp_327).collect(Collectors.toUnmodifiableSet());
    }

}
