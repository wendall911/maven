package technology.roughness.whitenoise.platform.services;

import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_2960;

public interface IPlatform {

    class_2960 getResourceLocation(class_1792 item);

    boolean isModLoaded(String name);

    boolean isPhysicalClient();

    boolean isFakePlayer(class_1657 player);

}

