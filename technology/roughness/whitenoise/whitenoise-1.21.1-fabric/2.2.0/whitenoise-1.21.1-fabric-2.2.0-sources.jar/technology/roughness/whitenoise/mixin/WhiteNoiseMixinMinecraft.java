/*
 * Derived from Spectrelib
 * https://github.com/illusivesoulworks/spectrelib
 * Copyright (C) 2022 Illusive Soulworks
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; you
 * may only use version 2.1 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library. If not, see <https://www.gnu.org/licenses/>.
 */

package technology.roughness.whitenoise.mixin;

import net.minecraft.class_310;
import net.minecraft.class_542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import technology.roughness.whitenoise.WhiteNoiseClientFabric;

@Mixin(class_310.class)
public class WhiteNoiseMixinMinecraft {

    @Inject(at = @At(value = "INVOKE", target = "net/minecraft/network/chat/contents/KeybindResolver.setKeyResolver(Ljava/util/function/Function;)V"), method = "<init>")
    private void whitenoise$init(class_542 config, CallbackInfo ci) {
        WhiteNoiseClientFabric.prepareConfigs(config);
    }

}

