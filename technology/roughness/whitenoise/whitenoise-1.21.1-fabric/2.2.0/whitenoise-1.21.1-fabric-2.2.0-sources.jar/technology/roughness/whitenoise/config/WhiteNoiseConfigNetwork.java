/*
 * Derived from Spectrelib
 * https://github.com/illusivesoulworks/spectrelib
 * Copyright (C) 2022 Illusive Soulworks
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; you
 * may only use version 2.1 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library. If not, see <https://www.gnu.org/licenses/>.
 */

package technology.roughness.whitenoise.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2540;
import net.minecraft.class_310;
import io.netty.buffer.Unpooled;

public class WhiteNoiseConfigNetwork {

    public static List<WhiteNoiseConfigPayload> getConfigSync() {
        Map<String, byte[]> configData = WhiteNoiseConfigTracker.INSTANCE.getConfigSync();

        if (configData.isEmpty()) {
            return new ArrayList<>();
        }
        class_2540 buf = new class_2540(Unpooled.buffer());
        buf.method_34063(configData, class_2540::method_10814, (k, v) -> k.method_10813(v));
        return configData.entrySet().stream()
                .map(e -> new WhiteNoiseConfigPayload(e.getValue(), e.getKey()))
                .toList();
    }

    public static void acceptSyncedConfigs(byte[] data, String fileName) {
        if (!class_310.method_1551().method_1542()) {
            WhiteNoiseConfigTracker.INSTANCE.acceptSyncedConfigs(fileName, data);
        }
    }

}

