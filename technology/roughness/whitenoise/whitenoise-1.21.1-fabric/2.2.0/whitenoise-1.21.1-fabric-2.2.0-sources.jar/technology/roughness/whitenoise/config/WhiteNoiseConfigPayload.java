package technology.roughness.whitenoise.config;

import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;
import technology.roughness.whitenoise.WhiteNoise;

public class WhiteNoiseConfigPayload implements class_8710 {

    public static final class_9154<WhiteNoiseConfigPayload> TYPE =
            new class_9154<>(WhiteNoise.prefix("sync"));
    public static final class_9139<class_2540, WhiteNoiseConfigPayload> STREAM_CODEC = class_9139.method_56435(
        class_9135.field_48987,
        packet -> packet.contents,
        class_9135.field_48554,
        packet -> packet.fileName,
        WhiteNoiseConfigPayload::new
    );

    public final String fileName;
    public final byte[] contents;

    public WhiteNoiseConfigPayload(byte[] contents, String fileName) {
        this.fileName = fileName;
        this.contents = contents;
    }

    public WhiteNoiseConfigPayload(class_2540 buf) {
        this(buf.method_10795(), buf.method_19772());
    }

    @NotNull
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

}
