package technology.roughness.whitenoise.platform;

import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import technology.roughness.whitenoise.platform.services.IPlatform;

public class FabricPlatform implements IPlatform {

    @Override
    public class_2960 getResourceLocation(class_1792 item) {
        return class_7923.field_41178.method_10221(item);
    }

    @Override
    public boolean isModLoaded(String name) {
        return FabricLoader.getInstance().isModLoaded(name);
    }

    @Override
    public boolean isPhysicalClient() {
        return FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT;
    }

    @Override
    public boolean isFakePlayer(class_1657 player) {
        return player instanceof FakePlayer;
    }

}
