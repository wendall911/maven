/*
 * Derived from Spectrelib
 * https://github.com/illusivesoulworks/spectrelib
 * Copyright (C) 2022 Illusive Soulworks
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; you
 * may only use version 2.1 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library. If not, see <https://www.gnu.org/licenses/>.
 */

package technology.roughness.whitenoise.platform;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;
import technology.roughness.whitenoise.WhiteNoise;
import technology.roughness.whitenoise.mixin.WhiteNoiseMixinLevelResource;
import technology.roughness.whitenoise.platform.services.IConfigHelper;

public class FabricConfigHelper implements IConfigHelper {

    public static Path gameDir = new File(".").toPath();

    private static class_5218 SERVERCONFIG = null;

    @Override
    public Path getBackwardsCompatiblePath() {
        return gameDir.resolve("defaultconfigs");
    }

    @Override
    public Path getGlobalConfigPath() {
        return gameDir.resolve("config");
    }

    @Override
    public Path getServerConfigPath(MinecraftServer server) {
        if (SERVERCONFIG == null) {
            SERVERCONFIG = WhiteNoiseMixinLevelResource.whitenoise$create("serverconfig");
        }

        final Path serverConfig = server.method_27050(SERVERCONFIG);

        if (!Files.isDirectory(serverConfig)) {
            try {
                Files.createDirectory(serverConfig);
            }
            catch (IOException e) {
                WhiteNoise.LOGGER.error("Could not create serverconfig directory!");
                e.printStackTrace();
            }
        }

        return serverConfig;
    }

    @Override
    public boolean isDedicatedServer() {
        return FabricLoader.getInstance().getEnvironmentType() == EnvType.SERVER;
    }

}

